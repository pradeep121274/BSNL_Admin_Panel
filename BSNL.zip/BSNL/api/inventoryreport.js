function getcurrentdate() { 
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
  var yyyy = today.getFullYear();

  today = dd + "-" + mm + "-" + yyyy;
  //document.write(today);
 // console.log("---->today", today);
  $("#start_date").val(today);
  $("#end_date").val(today);
    
  var currentdt = 'From ' +today+'  To  '+today;
  $("#datecurrent").html(currentdt);
  ordersList();
}

function getcircledata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getCircles";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#circle_name").html("");
        $("#circle_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#circle_name").append(
          '<option value="' + val.circle_id + '">' + val.circle_name + "</option>"
          );
        });
      });
}

function getssadata(){
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getSites";
  let data = {
    "is_active":1
    };
  var response = saveData(url, data);
    response.then(function (returnData) { //console.log("returnData",returnData);
  $('.ajax-loader').css("visibility", "hidden");
      $("#ssa_name").html("");
      $("#ssa_name").append("<option>-- Please Select --</option>");
        $.each(returnData.data,function(key,val){
       $("#ssa_name").append(
        '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
        );
      });
    });
}

function getallInventoryName(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getInventoryName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returninvData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#inventory").html("");
        $("#inventory").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#inventory").append(
          '<option value="' + val.inventory_id + '">' + val.inventory_name + "</option>"
          );
        });
      });
}

function clearForm() {
  $("#start_date").val("");
  $("#end_date").val("");

  $("#allusers").html("");
  var tbody = "";
  tbody +=
    '<tr>\n\
    <td colspan="10" style="text-align: center;color: red;"> No data found to display.! </td></tr>';
  $("#allusers").html("");
  $("#allusers").append(tbody);
}
 
function ordersList() { 
  $("#allusers").html("");

  var startdate = $("#start_date").val();
  var enddate = $("#end_date").val();
  var ssa_name = $("#ssa_name").val();
  var inventory = $("#inventory").val();


   var currentdto = 'From ' +startdate+'  To  '+enddate;
   $("#datecurrent").html(currentdto);

  var ssaname,inventory;

  var date = startdate;
  var start_date = date.split("-").reverse().join("-");
  var date1 = enddate;
  var end_date = date1.split("-").reverse().join("-");

  if(ssa_name == "-- Please Select --" || ssa_name == "" || ssa_name == null || ssa_name == undefined){   
     ssaname = "";
  }
  else{ 
      ssaname = ssa_name;
    }
  if(inventory == "-- Please Select --" || inventory == "" || inventory == null || inventory == undefined){   
     inventory = "";
  }
  else{ 
      inventory = inventory;
  }

  if (startdate !== "" && enddate !== "") {
    var url = "api/getAllInventoryManagementcountReports";
    let data = {
      "startdate":start_date,
      "enddate":end_date,
      "ssa_id":ssaname,
      "inventory_id":inventory
    };
      console.log("data",data);


    var response = saveData(url, data);
    response.then(function (data) {
      console.log("inventorydata",data);

      var tbody = "";
      var i = 1;
      if (data.status == false) {
         tbody +=
           '<tr>\n\
    <td colspan="10" style="text-align: center;color: red;"> No Records found to display.! </td></tr>';
      } else {
          $.each(data.data, function (key, value) {   console.log("value",value);
   
            tbody +=
              "<tr>\n\
                <td>" +
              i +
              "</td>\n\
                <td>" +
              value.ssa_name +
              "</td>\n\
                <td>" +
              value.site_type +
              "</td>\n\
               <td>" +
              value.inventory_name +
              "</td>\n\
                <td>" +
              value.quantity +
              "</td>\n\
                <td>"+
               value.serial_number +
              "</td>\n\
              <td>"+
               value.remarks +
              "</td>\n\
              <td>"+
               value.bsnl_remarks +
              "</td>\n\
               </tr>";
          i++;
        });
      }
   
      $("#allusers").html("");
      $("#allusers").append(tbody);
    });
  } else {  
    var msg = "kindly select date.. !";
    var tbody = "";
    tbody +=
      '<tr>\n\
    <td colspan="10" style="text-align: center;color: red;"> No data found to display.! </td></tr>';
    $("#allusers").html("");
    $("#allusers").append(tbody);
    swal(msg);
  }
}