function getallzonedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getZoneName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnzoneData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#zone_name").html("");
        $("#zone_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#zone_name").append(
          '<option value="' + val.zone_id + '">' + val.zone_name + "</option>"
          );
        });
      });
}


function getcircledata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getCircles";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#circle_name").html("");
        $("#circle_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#circle_name").append(
          '<option value="' + val.circle_id + '">' + val.circle_name + "</option>"
          );
        });
      });
}


function getssadata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSites";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#ssa_name").html("");
        $("#ssa_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#ssa_name").append(
          '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
          );
        });
      });
}

function getsitetypes(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSiteTypes";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").html("");
        $("#site_type").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#site_type").append(
          '<option value="' + val.site_type_id + '">' + val.site_type + "</option>"
          );
        });
      });
}

function getallData(){
  $('.ajax-loader').css("visibility", "visible");
  var ssaId = $("#ssa_name").val();
    var url = "api/getIdFromSsaName";
    let data = {
      "ssa_id":ssaId
      };
    var response = saveData(url, data);
      response.then(function (returnData) {   //  console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").val(returnData.data.ref_site_type_id).trigger("change");
        $("#zone_name").val(returnData.data.ref_zone_id).trigger("change");
        $("#circle_name").val(returnData.data.ref_circle_id).trigger("change");

        $("#site_type").prop("disabled", true);  
         $("#zone_name").prop("disabled", true); 
          $("#circle_name").prop("disabled", true); 
      });
}


function getAllCentrallocation() {  
  $('.ajax-loader').css("visibility", "visible");
     //console.log("getall");
  var url = "api/getAllCentralLocationSites";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {    // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";
      tbody += "<td>" + value.complete_consignee_details + "</td>";


      tbody +=
        '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
        value.central_location_site_id +
        "," +
        value.is_active +
        ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp ';
        if(value.is_active  == 1){ 
           tbody += '<a onclick="activateDeactivateData(' +value.central_location_site_id +');" style="cursor:pointer;background-color: #027e61;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
          } else { 
           tbody += '<a onclick="activateDeactivateData(' +value.central_location_site_id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' }
           '</td></tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}




function save_submit() { 
  var ssa_name = $("#ssa_name").val();
  var site_name = $("#site_name").val();
  var consignee_details = $("#consignee_details").val();
  var centralid = $("#centralid").val();

  if (ssa_name == null || ssa_name == "" || ssa_name == undefined || ssa_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select SSA Name..",
    });
    return false;
  } 
      else if (site_name == null || site_name == "" || site_name == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Site Name..",
    });
    return false;
  } 
      else if (consignee_details == null || consignee_details == "" || consignee_details == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Consignee Details..",
    });
    return false;
  } 

  else 
  {
    if (centralid == "") 
    {  //console.log("save");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesCentralLocationSites";
      var myJsonString = 
      {
        "ref_ssa_id":ssa_name,
        "site_name":site_name,
        "complete_consignee_details":consignee_details
      };

      var response = saveData(url, myJsonString);
     //console.log(response,"response");
      response.then(function (data) {       console.log(data,"data");
    $('.ajax-loader').css("visibility", "hidden");

        if (data.status == true) {
          $("#ssa_name").val("");
          $("#site_name").val("");
          $("#consignee_details").val();
          swal({
            type: "success",
            title: "Great...",
            text: "Central Location Site Details has been Saved Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          }).then((result) => {
          $("#consignee_details").val("");
          });
        }
      });
    } //end if of submit
    else if (centralid !== "") { //console.log("update");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesCentralLocationSites";
      var myJsonString = 
      {
          "central_location_site_id": centralid,
          "ref_ssa_id":ssa_name,
          "site_name":site_name,
          "complete_consignee_details":consignee_details
      };
      var response = saveData(url, myJsonString);
      response.then(function (data) {           // console.log("data",data);
          $('.ajax-loader').css("visibility", "hidden");
        if (data.status == true) {
          $("#centralid").val("");
          $("#ssa_name").val("");
          $("#site_name").val("");
          $("#consignee_details").val();      
           swal({
            type: "success",
            title: "Great...",
            text: "Central Location Site Details has been updated Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: "Data Updation failed!",
          });
        }
      });
    } else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went Wrong..!",
      });
    }
  }
}

function editpopulate(id, isActive) {
  if (isActive == 0) {  //console.log("isn't active");
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else {    //console.log("is active");
    $("#centralloc_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");

    var url = "api/getIdCentralLocationSites";
    var myJsonString = 
      {
         "central_location_site_id":id    
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) { 
     console.log("editdata",returnData);
      $('.ajax-loader').css("visibility", "hidden");
      $("#ssa_name").val(returnData.data.ref_ssa_id).trigger("change");
      $("#site_type").val(returnData.data.site_type_id).trigger("change");
      $("#zone_name").val(returnData.data.zone_id).trigger("change");
      $("#circle_name").val(returnData.data.circle_id).trigger("change");
      $("#site_name").val(returnData.data.site_name);
      $("#consignee_details").val(returnData.data.complete_consignee_details);
      $("#centralid").val(returnData.data.central_location_site_id);


        $("#site_type").prop("disabled", true);  
        $("#zone_name").prop("disabled", true); 
        $("#circle_name").prop("disabled", true); 
    });
  }
}

function clearpge(){
  $("#zone_name option:first").prop("selected","true").trigger("change");
  $("#circle_name option:first").prop("selected","true").trigger("change");
  $("#ssa_name option:first").prop("selected","true").trigger("change");
  $("#site_type option:first").prop("selected","true").trigger("change");
  $("#site_name").val("");
  $("#consignee_details").val("");
  $("#centralid").val("");
}

function activateDeactivateData(id) {  //console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Enable / Disable this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/deleteCentralLocationSitesById";
      var myJsonString = {
        "central_location_site_id":id,
      }
       var response = saveData(url, myJsonString);
       
      response.then(function (data) { //console.log("data",data);
     $('.ajax-loader').css("visibility", "hidden");
        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}