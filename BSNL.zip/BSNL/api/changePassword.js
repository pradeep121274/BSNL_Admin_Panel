var base;
function changepass(baseurl){
    
    base = baseurl;

    var email = $("#email").val();
    var oldPass = $("#oldPassword").val();
    var newPass = $("#newPassword").val();
    var confirmPass = $("#confirmPassword").val();
   // console.log(email);
   // console.log(oldPass);
   // console.log(newPass);
   // console.log(confirmPass);
    
   var userid = localStorage.getItem("userid");
      if (email == null || email == "" || email == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Email..",
    });

    return false;
   }
    else if (oldPass == null || oldPass == "" || oldPass == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Current Password..",
    });

    return false;
   }
     else if (newPass == null || newPass == "" || newPass == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter New Password..",
    });

    return false;
   }

    else if (confirmPass == null || confirmPass == "" || confirmPass == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Confirm Password..",
    });

    return false;
   }

    else if (newPass != confirmPass) {
    swal({
      type: "error",
      title: "Oops...",
      text: "New Password and Confirm Password did not match..",
    });

    return false;
   }
   else{
        var url = "api/changeuserpassword";
        var jsonstrings = {
            "email":email,
            "currentpassword": oldPass,
            "newpassword": newPass
        }
        var response = saveData(url,jsonstrings);            
        console.log("response",response);

        response.then(function(data){
           console.log("data",data);
           
            if(data.status == true){
                 swal({
              type: "success",
              title: "Great...",
              text: data.message,
              allowOutsideClick: false,
              confirmButtonText: "OK",
            }).then(function () {
                    window.location=baseurl+"Home"; 
                });           
            }else{
                swal({
                    "type": "error",
                    "text": data.message,
                    "allowOutsideClick": false
                });
            } 
        });   
    }
}