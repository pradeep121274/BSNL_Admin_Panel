
function getallcircledata() {  
  $('.ajax-loader').css("visibility", "visible");
     //console.log("getall");
  var url = "api/getAllEmpDepartmentData";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      console.log("value",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.emp_name + "</td>";
      tbody += "<td>" + value.emp_designation + "</td>";

      tbody +=
        '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
        value.id +
        "," +
        value.is_active +
        ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp ';
        if(value.is_active  == 1){ 
           tbody += '<a onclick="activateDeactivateData(' +value.id +');" style="cursor:pointer;background-color: #027e61;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
          } else { 
           tbody += '<a onclick="activateDeactivateData(' +value.id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' }
           '</td></tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}


function save_submit() { 
  var emp_name = $("#emp_name").val();
  var emp_designation = $("#emp_designation").val();
  
  var circleid = $("#id").val();

    if (emp_name == null || emp_name == "" || emp_name == undefined || emp_name == "") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Emp Name..",
    });
    return false;
}
else if (emp_designation == null || emp_designation == "" || emp_designation == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Emp Designation..",
    });
    return false;
  }
  else 
  {
    if (id == "") 
    {  //console.log("save");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesEmpDepartment";
      var myJsonString = 
      {
      "emp_name":emp_name,
      "emp_designation":emp_designation,  
      };

      var response = saveData(url, myJsonString);
     console.log(response,"response");
      response.then(function (data) {       console.log(data,"data");
    $('.ajax-loader').css("visibility", "hidden");

        if (data.status == true) {
          $("#emp_name").val("");
          $("#emp_designation").val("");
        
          swal({
            type: "success",
            title: "Great...",
            text: "Emp Department has been Saved Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          }).then((result) => {
          $("#circle_name").val("");
          });
        }
      });
    } //end if of submit
    else if (id !== "") { //console.log("update");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesEmpDepartment";
      var myJsonString = 
      {
      "id":id,
      "emp_name":emp_name,
      "emp_designation":emp_designation
        
      };
      var response = saveData(url, myJsonString);
      response.then(function (data) {           // console.log("data",data);
          $('.ajax-loader').css("visibility", "hidden");
        if (data.status == true) {
          $("#id").val("");
          $("#emp_name").val("");
          $("#emp_designation").val("");
            
           swal({
            type: "success",
            title: "Great...",
            text: "Emp Department has been updated Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: "Data Updation failed!",
          });
        }
      });
    } else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went Wrong..!",
      });
    }
  }
}

function editpopulate(id, isActive) {
  if (isActive == 0) {  //console.log("isn't active");
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else {    //console.log("is active");
    $("#circle_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");

    var url = "api/getEmpDepartmentById";
    var myJsonString = 
      {
         "department_id":id    
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) { 
     // console.log("data",returnData);
      $('.ajax-loader').css("visibility", "hidden");
      $("#emp_name").val(returnData.data.emp_name);
    //   $("#zone_name").val(returnData.data.ref_zone_id).trigger("change");
      $("#emp_designation").val(returnData.data.emp_designation);
      $("#circleid").val(returnData.data.department_id);
    });
  }
}



function clearpge(){
  $("#zone_name option:first").prop("selected","true").trigger("change");
  $("#emp_name").val("");
  $("#emp_designation").val("");

}

function activateDeactivateData(id) {  //console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Enable / Disable this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/deletedEmpDepartmentById";
      var myJsonString = {
        "id":id,
      }
       var response = saveData(url, myJsonString);
       
      response.then(function (data) { //console.log("data",data);
     $('.ajax-loader').css("visibility", "hidden");
        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}