function getallzonedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getZoneName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnzoneData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#region").html("");
        $("#region").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#region").append(
          '<option value="' + val.zone_id + '">' + val.zone_name + "</option>"
          );
        });
      });
}

function getallssadata(){
  $('.ajax-loader').css("visibility","visible");
  var url = "api/getByStatusMaterialDelivered";
  let data = {
      "status":"Delivered"
  };
  var response = saveData(url, data);
  response.then( function(returnData) {
    $(".ajax-loader").css("visibility","hidden");
    $("#ssa_name").html("");
    $("#ssa_name").append("<option>-- Please Select --</option>");
    $.each(returnData.data,function(key,val){
        $("#ssa_name").append(
          '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
          );    
        });
  });
}

function getcircledata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getCircles";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#circle_name").html("");
        $("#circle_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#circle_name").append(
          '<option value="' + val.circle_id + '">' + val.circle_name + "</option>"
          );
        });
      });
}

function getallSiteTypedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSiteTypes";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").html("");
        $("#site_type").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#site_type").append(
          '<option value="' + val.site_type_id + '">' + val.site_type + "</option>"
          );
        });
      });
}

function getallData(){
  $('.ajax-loader').css("visibility", "visible");
  var ssaId = $("#ssa_name").val();
    var url = "api/getIdFromSsaName";
    let data = {
      "ssa_id":ssaId
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").val(returnData.data.ref_site_type_id).trigger("change");
        $("#region").val(returnData.data.ref_zone_id).trigger("change");
        $("#circle_name").val(returnData.data.ref_circle_id).trigger("change");

        $("#site_type").prop("disabled", true);  
         $("#region").prop("disabled", true); 
          $("#circle_name").prop("disabled", true); 
      });
}

function clearpge(){
  $("#region option:first").prop("selected", true).trigger("change");
  $("#circle_name option:first").prop("selected", true).trigger("change");
  $("#site_name").val("");
  $("#ssa_name option:first").prop("selected", true).trigger("change");
  $("#site_type option:first").prop("selected", true).trigger("change");
  $("#rdate").val("");
  $("#install_status option:first").prop("selected", true).trigger("change");
  $("#vdate").val("");
  $("#commission_status option:first").prop("selected", true).trigger("change");
  $("#mpls_status option:first").prop("selected", true).trigger("change");
  $("#vrdate").val("");
  $("#remarks").val("");
  $("#commissionid").val("");
}

function getallcommisiondata() {  
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllInstallCommissioning";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";


    if(roleid == '1')
    {  
            tbody += '<td><a onclick="enterBsnlRemarks(' +value.id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-placement="top" title="View" data-toggle="modal" data-target="#productsQuickView"  title="Enter Remarks">Remarks</a></td>';
    }
    else 
    {
          tbody +=
            '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
            value.id +
            "," +
            value.is_active +
            ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp <a data-toggle="tooltip" title="Delete" name="delete" id="delete" style="cursor:pointer; padding-left:5px;" onclick="activateDeactivateData(' +value.id +');"><i class="ti-trash" style="size:100%; color: #FF0000! important;"></i></a> &nbsp ';
        // if(value.is_active  == 1)
        // { 
        //   tbody += '<a onclick="activateDeactivateData(' +value.id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
        //   } 
        //   else 
        //   { 
        //    tbody += '<a onclick="activateDeactivateData(' +value.id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' 
        //   }
           tbody +='</td>';
      }
           tbody +='</tr>';

           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}

var commissingid;
function enterBsnlRemarks(id){
  commissingid = id;
}

function submitRemarks(){
  var bsnlremarks     =   $("#bsnlremarks").val();

  if(bsnlremarks == ""){
      swal({
          title: 'info',
          text: 'Please enter Remarks',
          timer: 2000
      });
      return;
  }else{

  $('.ajax-loader').css("visibility", "visible");
  var myJsonString = {
    "bsnl_remarks":bsnlremarks,
    "id":commissingid
  }
  var url  = "api/updateInstallCommissioningStatus"
  var response = saveData(url, myJsonString); console.log("response",response);
  response.then(function (data) { 
      $('.ajax-loader').css("visibility", "hidden");
      if(data.status == true){
        $('#productsQuickView').modal('hide');
        swal({
          type: "success",
          title: "Great...",
          text: "Remarks Submited Successfully ...!",
          allowOutsideClick: false,
          confirmButtonText: "OK",
        }).then((result) => {
          location.reload();
        });
      }else{
          swal({
              text: data.message,
              timer: 2000
          });
      }
      
  });
  }
}

function save_submit() 
{ 
  var ssa_name = $("#ssa_name").val();
  var site_name = $("#site_name").val();
  var rdate = $("#rdate").val();
  var install_status = $("#install_status").val();
  var vdate = $("#vdate").val();
  var commission_status = $("#commission_status").val();
  var mpls_status = $("#mpls_status").val();
  var vrdate = $("#vrdate").val();
  var remarks = $("#remarks").val();
  var commissionid = $("#commissionid").val();


if(rdate == "" || rdate == null || rdate == undefined)
{
  var newrdate="";
}
else
{
   newrdate = rdate.split("-").reverse().join("-");
}

if(vdate == "" || vdate == null || vdate == undefined)
{
  var newvdate="";
}
else
{
  var newvdate = vdate.split("-").reverse().join("-");
}

// if(vrdate == "" || vrdate == null || vrdate == undefined)
// {
//   var newvrdate="";
// }

{
    newvrdate = vrdate.split("-").reverse().join("-");
}


  if (ssa_name == null || ssa_name == "" || ssa_name == undefined || ssa_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select SSA..",
    });

    return false;
  }
  else if (site_name == null || site_name == "" || site_name == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Site Name..",
    });
    return false;
  } 
     else if (rdate == null || rdate == "" || rdate == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Installation Start Plan Date..",
    });
    return false;
  } 
     else if (install_status == null || install_status == "" || install_status == undefined || install_status == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Installation Status..",
    });
    return false;
  } 
      else if (vdate == null || vdate == "" || vdate == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Installation Date..",
    });
    return false;
  }

    else if (commission_status == null || commission_status == "" || commission_status == undefined || commission_status == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Config Completion Status..",
    });
    return false;
  } 
  //     else if (vrdate == null || vrdate == "" || vrdate == undefined) {
  //   swal({
  //     type: "error",
  //     title: "Oops...",
  //     text: "Please Select Config Completion Completion Date..",
  //   });
  //   return false;
  // } 
  else if (mpls_status == null || mpls_status == "" || mpls_status == undefined || mpls_status == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select MPLS reachability and basic configuration..",
    });
    return false;
  } 
  else 
  {
    if (commissionid == "") 
    {
      if(install_status == "Hold")
      {
        if(remarks == "" || remarks == undefined || remarks == null)
        {
        swal({
          type: "error",
          title: "Oops...",
          text: "Please Enter Remarks..",
        });
        return false;
        }
        else
        {
              $('.ajax-loader').css("visibility", "visible");
              var url = "api/saveUpdatesInstallCommissioning";

              var myJsonString = 
              {
                "ref_ssa_id":ssa_name,
                "site_name":site_name,
                "installation_plandate":newrdate,
                "installation_status":install_status,
                "installation_completeddate":newvdate,
                "comminssioning_status":commission_status,
                "comminssioning_date":newvrdate,
                "remarks":remarks,   
                "MPLS_reachability":mpls_status
              };

              console.log(myJsonString,"myJsonString");

              var response = saveData(url, myJsonString);
              //  console.log(response,"response");
               response.then(function (Data)
                {      console.log(Data,"Data");
                   $('.ajax-loader').css("visibility", "hidden");

                    if (Data.status == true) {
                        $("#region").val();
                        $("#circle_name").val();
                        $("#site_name").val();
                        $("#ssa_name").val();
                        $("#site_type").val();
                        $("#rdate").val();
                        $("#install_status").val();
                        $("#vdate").val();
                        $("#commission_status").val();
                        $("#vrdate").val();
                        $("#remarks").val();
                        $("#mpls_status").val();

                      swal({
                        type: "success",
                        title: "Great...",
                        text: "Installation and Config Completion Details has been Saved Successfully...!",
                        allowOutsideClick: false,
                        confirmButtonText: "OK",
                      }).then((result) => {
                        location.reload();
                      });
                    } 
                    else 
                    {
                      swal({
                        type: "error",
                        title: "Oops...",
                        text: "Data saving failed!",
                      });
                    }
                  });
        }
      }
      else
      {
          $('.ajax-loader').css("visibility", "visible");
            var url = "api/saveUpdatesInstallCommissioning";

            var myJsonString = 
            {
              "ref_ssa_id":ssa_name,
              "site_name":site_name,
              "installation_plandate":newrdate,
              "installation_status":install_status,
              "installation_completeddate":newvdate,
              "comminssioning_status":commission_status,
              "comminssioning_date":newvrdate,
              "remarks":remarks,   
              "MPLS_reachability":mpls_status
            };

            console.log(myJsonString,"myJsonString");

            var response = saveData(url, myJsonString);
             console.log(response,"response");
             response.then(function (Data) {      console.log(Data,"Data");
               $('.ajax-loader').css("visibility", "hidden");

              if (Data.status == true) {
                  $("#region").val();
                  $("#circle_name").val();
                  $("#site_name").val();
                  $("#ssa_name").val();
                  $("#site_type").val();
                  $("#rdate").val();
                  $("#install_status").val();
                  $("#vdate").val();
                  $("#commission_status").val();
                  $("#vrdate").val();
                  $("#remarks").val();
                  $("#mpls_status").val();

                swal({
                  type: "success",
                  title: "Great...",
                  text: "Installation and Config Completion Details has been Saved Successfully...!",
                  allowOutsideClick: false,
                  confirmButtonText: "OK",
                }).then((result) => {
                  location.reload();
                });
              } else {
                swal({
                  type: "error",
                  title: "Oops...",
                  text: "Data saving failed!",
                });
              }
            });
         }
    } //end if of submit
    else if (commissionid !== "")
    {  
      if(install_status == "Hold"){
        if(remarks == "" || remarks == undefined || remarks == null)
        {
          swal({
            type: "error",
            title: "Oops...",
            text: "Please Enter Remarks..",
          });
          return false;
        }
        else
        {
           $('.ajax-loader').css("visibility", "visible");
            var url = "api/saveUpdatesInstallCommissioning";
            var myJsonString = 
            {
              "id":commissionid,
              "site_name":site_name,
              "ref_ssa_id":ssa_name,
              "installation_plandate":newrdate,
              "installation_status":install_status,
              "installation_completeddate":newvdate,
              "comminssioning_status":commission_status,
              "comminssioning_date":newvrdate,
              "remarks":remarks,
              "MPLS_reachability":mpls_status
            };
             var response = saveData(url, myJsonString);
               response.then(function (Data) {           // console.log("dataUPDATE",data);
               $('.ajax-loader').css("visibility", "hidden");

                if (Data.status == true)
                 {
                    $("#commissionid").val();
                    $("#region").val();
                    $("#circle_name").val();
                    $("#site_name").val();
                    $("#ssa_name").val();
                    $("#site_type").val();
                    $("#rdate").val();
                    $("#install_status").val();
                    $("#vdate").val();
                    $("#commission_status").val();
                    $("#vrdate").val();
                    $("#remarks").val();
                    $("#mpls_status").val();

                    swal({
                      type: "success",
                      title: "Great...",
                      text: "Installation and Config Completion Details has been Updated Successfully...!",
                      allowOutsideClick: false,
                      confirmButtonText: "OK",
                    }).then((result) => {
                      location.reload();
                    });
                  } 
                  else 
                  {
                    swal({
                      type: "error",
                      title: "Oops...",
                      text: "Data Updation failed!",
                    });
                  }
               });
              }
             }
             else
             {
                $('.ajax-loader').css("visibility", "visible");

              var url = "api/saveUpdatesInstallCommissioning";
              var myJsonString = 
              {
                "id":commissionid,
                "site_name":site_name,
                "ref_ssa_id":ssa_name,
                "installation_plandate":newrdate,
                "installation_status":install_status,
                "installation_completeddate":newvdate,
                "comminssioning_status":commission_status,
                "comminssioning_date":newvrdate,
                "remarks":remarks,
                "MPLS_reachability":mpls_status
              };
               var response = saveData(url, myJsonString);
                response.then(function (Data) {           // console.log("dataUPDATE",data);
                $('.ajax-loader').css("visibility", "hidden");

                  if (Data.status == true) {
                            $("#commissionid").val();
                            $("#region").val();
                            $("#circle_name").val();
                            $("#site_name").val();
                            $("#ssa_name").val();
                            $("#site_type").val();
                            $("#rdate").val();
                            $("#install_status").val();
                            $("#vdate").val();
                            $("#commission_status").val();
                            $("#vrdate").val();
                            $("#remarks").val();
                            $("#mpls_status").val();

                          swal({
                            type: "success",
                            title: "Great...",
                            text: "Installation and Config Completion Details has been Updated Successfully...!",
                            allowOutsideClick: false,
                            confirmButtonText: "OK",
                          }).then((result) => {
                            location.reload();
                          });
                        } else {
                          swal({
                            type: "error",
                            title: "Oops...",
                            text: "Data Updation failed!",
                          });
                        }
                      });
                    }
                  }
                  else 
                  {
                    swal({
                      type: "error",
                      title: "Oops...",
                      text: "Something went wrong!",
                    });
                  }
  }
}

function editpopulate(id, isActive) {    //console.log("id",id);
  if (isActive == 0) {  //console.log("isn't active");
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else {           
    // console.log("id",id);
    $("#commission_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");

    var url = "api/getInstallCommissioningById";
    var myJsonString = 
      {
        "id":id
      };
      var response = saveData(url, myJsonString);
       response.then(function (returnData) {            //  console.log("editdata",returnData);
         $('.ajax-loader').css("visibility", "hidden");
      $("#ssa_name").val(returnData.data.ref_ssa_id).trigger("change");
      $("#site_type").val(returnData.data.site_type_id).trigger("change");
      $("#region").val(returnData.data.zone_id).trigger("change");
      $("#circle_name").val(returnData.data.circle_id).trigger("change");
      $("#site_name").val(returnData.data.site_name);

      var newplandt = returnData.data.installation_plandate;
        if(newplandt == null || newplandt == "" || newplandt == undefined)
         {
          var newrdate="";
         }
         else{
          newrdate = newplandt.split("-").reverse().join("-");
          $("#rdate").val(newrdate);     
        }


      $("#install_status").val(returnData.data.installation_status).trigger("change");


      var newvdate1 = returnData.data.installation_completeddate;
      if(newvdate1 == null || newvdate1 == "" || newvdate1 == undefined)
         {
          var newvdate="";
         }
         else{
           newvdate = newvdate1.split("-").reverse().join("-");
          $("#vdate").val(newvdate);   
        }

      $("#commission_status").val(returnData.data.comminssioning_status).trigger("change");

      var newvrdate1 = returnData.data.comminssioning_date;
      if(newvrdate1 == null || newvrdate1 == "" || newvrdate1 == undefined)
         {
           var newvrdate="";
         }
         else{
          newvrdate = newvrdate1.split("-").reverse().join("-");  
          $("#vrdate").val(newvrdate); 
        }

      $("#mpls_status").val(returnData.data.MPLS_reachability).trigger("change");
      $("#remarks").val(returnData.data.remarks);
      $("#commissionid").val(returnData.data.id);

        $("#site_type").prop("disabled", true);  
        $("#region").prop("disabled", true); 
        $("#circle_name").prop("disabled", true); 
    });
  }
}

function activateDeactivateData(id) {  //console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Delete this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");

      var url = "api/deletedInstallCommissioningById";
      var myJsonString = {
              "id":id    
             }
       var response = saveData(url, myJsonString);
      // console.log("response",response);
      response.then(function (data) {     //console.log("data",data);
       $('.ajax-loader').css("visibility", "hidden");
        swal({
          title: "Done...!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });
      });
    }
  });
}