var base;
function login(baseurl) {  
  $('.ajax-loader').css("visibility", "visible");
 
  base = baseurl;
  
  var emailid = $("#email").val();
  var password = $("#passWord").val();

  if (emailid == null || emailid == "" || emailid == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Username..",
    });
    return false;
   }

    else if (password == null || password == "" || password == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Password..",
    });
    return false;
   }

   else {
    var url = "api/userSignin";
        var jsonstring = {
      "username": emailid,
      "password": password
    };
    //console.log("jsonstring",jsonstring);

    var response = saveData(url, jsonstring);
    console.log("----->response", response);

    response.then(function (data) {
    $('.ajax-loader').css("visibility", "hidden");

      //  console.log("---->data", data);
      //    console.log("---->datamsg", data.message);
         // console.log("---->datauser", data.data.username);
        if (data.message == "Signed in successfully") {   
        window.localStorage.setItem("userid", data.data.user_id);
        window.localStorage.setItem("username", data.data.username);
        window.localStorage.setItem("roleid", data.data.ref_role_id);
        window.sessionStorage.setItem('id', data.user_id);
        var sid = window.sessionStorage.getItem('id');
        var userid = window.localStorage.getItem("userid"); 
        var username = window.localStorage.getItem("username"); 
        var roleid = window.localStorage.getItem("roleid"); 

        console.log("sid",sid);

        console.log("userid",userid);
        console.log("username",username);
        console.log("roleid",roleid);
        
         if(userid !== "" || userid !== null || userid !== undefined){
            window.location = baseurl + "dashboard";
         }
      } 
      else {  
            swal({
                    "type": "error",
                    "text": data.message,
                    "allowOutsideClick": false
                });
             }
   });  
   }
}

