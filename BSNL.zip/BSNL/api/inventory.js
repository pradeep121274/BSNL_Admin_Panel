function getallssadata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getByStatusMaterialDelivered";
    let data = {
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#ssa_name").html("");
        $("#ssa_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#ssa_name").append(
          '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
          );
        });
      });
}

function getallSiteTypedata(){
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getSiteTypes";
  let data = {
    "is_active":1
    };
  var response = saveData(url, data);
    response.then(function (returnData) {     //console.log("returnData",returnData);
  $('.ajax-loader').css("visibility", "hidden");
      $("#site_type").html("");
      $("#site_type").append("<option>-- Please Select --</option>");
        $.each(returnData.data,function(key,val){
       $("#site_type").append(
        '<option value="' + val.site_type_id + '">' + val.site_type + "</option>"
        );
      });
    });
}

function getallData(){
  $('.ajax-loader').css("visibility", "visible");
  var ssaId = $("#ssa_name").val();
    var url = "api/getIdFromSsaName";
    let data = {
      "ssa_id":ssaId
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").val(returnData.data.ref_site_type_id).trigger("change");

        $("#site_type").prop("disabled", true);  
      });
}

function getallInventoryName(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getInventoryName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { 
    $('.ajax-loader').css("visibility", "hidden");
        $("#inventory").html("");
        $("#inventory").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#inventory").append(
          '<option value="' + val.inventory_id + '">' + val.inventory_name + "</option>"
          );
        });
      });
   }

function getDynamicAllInventoryData(id,inventoryid){
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getInventoryName";
  let data = {
    "is_active":1
    };
  var response = saveData(url, data);
    response.then(function (returnData) { console.log(inventoryid);
  $('.ajax-loader').css("visibility", "hidden");
      $("#inventory"+id).html("");
      $("#inventory"+id).append("<option>-- Please Select --</option>");
        $.each(returnData.data,function(key,val){
       $("#inventory"+id).append(
        '<option value="' + val.inventory_id + '">' + val.inventory_name + "</option>"
        );
      });
      $("#inventory"+id).val(inventoryid).trigger('change');
    });
}

function getallinventorydata() {  
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllInventoryManagementData";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    //console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      console.log("values",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

      if(roleid == '1')
      { 
            tbody += '<td><a onclick="enterBsnlRemarks(' +value.inventory_management_id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-placement="top" title="View" data-toggle="modal" data-target="#productsQuickView"  title="Enter Remarks">Remarks</a></td>';
      } 
      else
      {
              tbody +=
                '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
                value.inventory_management_id + "," + value.is_active +')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp <a data-toggle="tooltip" title="Delete" name="delete" id="delete" style="cursor:pointer; padding-left:5px;" onclick="activateDeactivateData(' +value.inventory_management_id +');"><i class="ti-trash" style="size:100%; color: #FF0000! important;"></i></a> &nbsp ';
        // if(value.is_active  == 1)
        // { 
        //    tbody += '<a onclick="activateDeactivateData(' +value.inventory_management_id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
        // } 
        // else 
        // { 
        //    tbody += '<a onclick="activateDeactivateData(' +value.inventory_management_id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>'
        // }
            tbody +='</td>';

      }
            tbody +='</tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}


var inventorymanagementid;
function enterBsnlRemarks(id){
  inventorymanagementid = id;
}

function submitRemarks(){
  var bsnlremarks     =   $("#bsnlremarks").val();

  if(bsnlremarks == ""){
      swal({
          title: 'info',
          text: 'Please enter Remarks',
          timer: 2000
      });
      return;
  }else{

  $('.ajax-loader').css("visibility", "visible");
  var myJsonString = {
    "bsnl_remarks":bsnlremarks,
    "inventory_management_id":inventorymanagementid
  }
  var url  = "api/updateTrxInventoryManagementStatus"
  var response = saveData(url, myJsonString);
  response.then(function (data) {
      $('.ajax-loader').css("visibility", "hidden");
      if(data.status == true){
        $('#productsQuickView').modal('hide');
        swal({
          type: "success",
          title: "Great...",
          text: "Remarks Submited Successfully ...!",
          allowOutsideClick: false,
          confirmButtonText: "OK",
        }).then((result) => {
          location.reload();
        });
      }else{
          swal({
              text: data.message,
              timer: 2000
          });
      }
      
  });
  }
}

function save_submit() { 
  var ssa_name = $("#ssa_name").val();
  var inventory_management_id = $("#inventory_management_id").val();

  var x = document.getElementById('POITable');
  var len = (x.rows.length);
  var arrayOfinventorydata = [];
  
  if(inventory_management_id == ""){
  for(let i=0; i < len; i++){
    if(i == 0){
      var inventory = $("#inventory").val();
      var quantity = $("#quantity").val();
      var serial_number = $("#serial_number").val();
    }else{
      var inventory = $("#inventory"+i).val();
      var quantity = $("#quantity"+i).val();
      var serial_number = $("#serial_number"+i).val();
    }
    var specilarray = {
          "id":"",
          "ref_inventory_id":inventory,
          "quantity":quantity,  
          "serial_number":serial_number
    }
    arrayOfinventorydata.push(specilarray);
  }
}
  else if(inventory_management_id !== ""){
          for(let i=0; i < len; i++){
        if(i == 0){
          var id = $("#inventoryid").val();
          var inventory = $("#inventory").val();
          var quantity = $("#quantity").val();
          var serial_number = $("#serial_number").val();
        }else{
          var id = $("#inventoryid"+i).val();
          var inventory = $("#inventory"+i).val();
          var quantity = $("#quantity"+i).val();
          var serial_number = $("#serial_number"+i).val();
        }
        var specilarray = {
              "id":id,
              "ref_inventory_id":inventory,
              "quantity":quantity,  
              "serial_number":serial_number
        }
        arrayOfinventorydata.push(specilarray);
      }
  }

  if (ssa_name == null || ssa_name == "" || ssa_name == undefined || ssa_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select SSA..",
    });
    return false;
  }
  else if (arrayOfinventorydata.length == "0") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Add Inventory...",
    });
    return false;
  }else{
    if (inventory_management_id == "") 
    {
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpadtesInventoryManagement";

      var myJsonString = 
      {
        "inventory_management_id":"",
        "ref_ssa_id":ssa_name,
        "inventory_data":arrayOfinventorydata 
      };
      console.log("savemyJsonString",myJsonString);
      var response = saveData(url, myJsonString);
      response.then(function (data) {    
        $('.ajax-loader').css("visibility", "hidden");
        if (data.status == true) {
          $("#ssa").val("");

          swal({
            type: "success",
            title: "Great...",
            text: "Inventory Management has been Saved Successfully...!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
    } //end if of submit
    else if (inventory_management_id !== "") {  

      
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpadtesInventoryManagement";
      var myJsonString = 
      {
        "inventory_management_id":inventory_management_id,
        "ref_ssa_id":ssa_name,
        "inventory_data":arrayOfinventorydata 
      };

            console.log(myJsonString,"myJsonString");

      var response = saveData(url, myJsonString);
      response.then(function (data) {         
        $('.ajax-loader').css("visibility", "hidden"); 
      if (data.status == true) {
          $("#inventory_id").val("");
          $("#ssa").val("");
          $("#site_type").val("");
          $("#inventory").val("");
          $("#quantity").val("");
          $("#serial_number").val("");     
           swal({
            type: "success",
            title: "Great...",
            text: "Inventory Management has been updated Successfully...!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: "Data Updation failed!",
          });
        }
      });
    } else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went wrong!",
      });
    }
  }
}

function editpopulate(id, isActive) { //console.log("id",id);
  if (isActive == 0) {  
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else {
    $("#inventory_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getInventoryManagementDataById";
    var myJsonString = 
      {
          "inventory_management_id":id
      };
    var response = saveData(url, myJsonString);
    response.then(function (returnData) {            console.log("returnData",returnData);   
    $('.ajax-loader').css("visibility", "hidden"); 
    $("#inventory_management_id").val(returnData.data.inventorydata.inventory_management_id);
    $("#ssa_name").val(returnData.data.inventorydata.ref_ssa_id).trigger("change");
    

      var i = 0;
      $.each(returnData.data.managementdata, function (key, value) { console.log("value",value);
        if(i == 0){
          $("#inventory").val(value.ref_inventory_id).trigger("change");
          $("#quantity").val(value.quantity);
          $("#serial_number").val(value.serial_number);
          $("#inventoryid").val(value.id);
          i++;
        }else{
          getDynamicAllInventoryData(i,value.ref_inventory_id);
            var x = document.getElementById('POITable');
            var len = x.rows.length;
            var id = len;
            var html = '';
                html += '<tr>\n\
                  <td style="padding-right: 10px;">\n\
                      <div class="form-group">\n\
                          <label>Inventory Name*</label>\n\
                          <input type="hidden" name="inventoryid" id="inventoryid'+i+'" value="'+value.id+'" />\n\
                          <select id="inventory'+i+'" name="inventory" class="form-control select2" required>\n\
                          </select>\n\
                      </div>\n\
                  </td>\n\
                  <td style="padding-right: 10px;">\n\
                      <div class="form-group">\n\
                      <label>Qty*</label>\n\
                      <input type="text" class="form-control" id="quantity'+i+'" name="quantity" value="'+value.quantity+'" placeholder="Enter Quantity" value="" onblur="qty_validation()">\n\
                      </div>\n\
                  </td>\n\
                  <td style="padding-right: 10px;">\n\
                      <div class="form-group">\n\
                      <label>Serial Number*</label>\n\
                      <input type="text" class="form-control" id="serial_number'+i+'" name="serial_number" value="'+value.serial_number+'" placeholder="Enter Serial Number" value="" onblur="serialnm_validation()">\n\
                      </div>\n\
                  </td>\n\
                  <td style="width:200px;padding-top: 5px;">\n\
                      <input type="button" id="delPOIbutton" value="Delete" onclick="deleteRow(this)" style="color: #fff;background-color: #de0909;padding: 5px;border-radius: 10px;" />\n\
                      <input type="button" id="addmorePOIbutton" value="Add More" onclick="insRow()" style="color: #fff;background-color: #3c2ce4;padding: 5px;border-radius: 10px;" />\n\
                  </td>\n\
              </tr>';
                $('#POITable').append(html);
            i++;
        }
      });
     
    });
  }
}

function clearpge(){
  $("#ssa_name option:first").prop("selected",true).trigger("change");
  $("#site_type option:first").prop("selected",true).trigger("change");
  $("#inventory option:first").prop("selected",true).trigger("change");
  $("#quantity").val("");
  $("#serial_number").val("");
  $("#inventory_id").val("");
}

function activateDeactivateData(id) { 
  swal({   
    title: "Are you sure?",
    text: "Do you want to Delete this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/deletedInventoryManagementDataById";
      var myJsonString = {
        "inventory_management_id":id,
      }
       var response = saveData(url, myJsonString);
      response.then(function (data) {
      $('.ajax-loader').css("visibility", "hidden"); 
        swal({
          title: "Done...!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}