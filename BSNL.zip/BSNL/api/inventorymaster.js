function getallInventorydata() {  
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getAllInventory";
    let data = {
     };
    var response = saveData(url, data);
    response.then(function (returnData) {
      $('.ajax-loader').css("visibility", "hidden");
      //console.log("return",returnData);
      var tbody = "";
      var i = 1;
      $.each(returnData.data, function (key, value) {    

        tbody += "<tr><td>" + i + "</td>";
        tbody += "<td>" + value.inventory_name + "</td>";
  
        tbody +=
          '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
          value.inventory_id +
          "," +
          value.is_active +
          ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp ';
          if(value.is_active  == 1){ 
             tbody += '<a onclick="activateDeactivateData(' +value.inventory_id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
            } else { 
             tbody += '<a onclick="activateDeactivateData(' +value.inventory_id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' }
             '</td></tr>';
             i++;
      });
  
      $("#allusers").html("");
      $("#allusers").append(tbody);
      $("#example").DataTable({ pagingType: "full_numbers" });
    });
  }
  
  
  function save_submit() { 
    var inventory_name = $("#inventory_name").val();
    var inventory_id = $("#inventory_id").val();
  
  
    if (inventory_name == null || inventory_name == "" || inventory_name == undefined) {
      swal({
        type: "error",
        title: "Oops...",
        text: "Please Enter Inventory Name..",
      });
      return false;
    }
    else 
    {
      if (inventory_id == "") 
      {
    $('.ajax-loader').css("visibility", "visible");
        var url = "api/saveUpdatesInventory";
        var myJsonString = 
        {
          "inventory_name":inventory_name
        };
        var response = saveData(url, myJsonString);
        response.then(function (data) {   
          $('.ajax-loader').css("visibility", "hidden");
          if (data.status == true) {
            $("#inventory_name").val("");
            swal({
              type: "success",
              title: "Great...",
              text: "Inventory Details has been Saved Successfully....!",
              allowOutsideClick: false,
              confirmButtonText: "OK",
            }).then((result) => {
              location.reload();
            });
          } else {
            swal({
              type: "error",
              title: "Oops...",
              text: data.message,
            }).then((result) => {
            $("#inventory_name").val("");
            });
          }
        });
      } //end if of submit
      else if (inventory_id !== "") {  
          $('.ajax-loader').css("visibility", "visible");
        var url = "api/saveUpdatesInventory";
        var myJsonString = 
        {
          "inventory_name":inventory_name,
          "inventory_id":inventory_id
        };
        var response = saveData(url, myJsonString);
        response.then(function (data) {           // console.log("dataUPDATE",data);
          $('.ajax-loader').css("visibility", "hidden"); 
        if (data.status == true) {
            $("#inventory_name").val("");
            $("#inventory_id").val("");       
             swal({
              type: "success",
              title: "Great...",
              text: "Inventory Details has been updated Successfully....!",
              allowOutsideClick: false,
              confirmButtonText: "OK",
            }).then((result) => {
              location.reload();
            });
          } else {
            swal({
              type: "error",
              title: "Oops...",
              text: "Data Updation failed!",
            });
          }
        });
      } else {
        swal({
          type: "error",
          title: "Oops...",
          text: "Something went wrong!",
        });
      }
    }
  }
  
  function editpopulate(id, isActive) {
    if (isActive == 0) { 
      swal({
        text: "You are not allowed to edit. Data has been disabled."
          });
    } else {    
      $("#inventory_submit").val("Update");
      $("#clearpage").hide("");
      $("#pincodename").show("");
      $("#listhide").hide("");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/getInventoryById";
      var myJsonString = 
        {
           "inventory_id":id  
        };
        var response = saveData(url, myJsonString);
      response.then(function (returnData) {              
      $('.ajax-loader').css("visibility", "hidden"); 
      $("#inventory_name").val(returnData.data.inventory_name);
      $("#inventory_id").val(returnData.data.inventory_id);
      });
    }
  }
  
  function clearpge(){
    $("#inventory_name").val("");
    $("#inventory_id").val("");
  }
  
  function activateDeactivateData(id) {  //console.log("id",id);
    swal({   
      title: "Are you sure?",
      text: "Do you want to Enable / Disable this Record..?",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
      $('.ajax-loader').css("visibility", "visible");
        var url = "api/deletedInventoryById";
        var myJsonString = {
          "inventory_id":id,
        }
         var response = saveData(url, myJsonString);
        // console.log("response",response);
        response.then(function (data) { //console.log("data",data);
        $('.ajax-loader').css("visibility", "hidden"); 
          swal({
            title: "Done..!",
            text: data.message,
          }).then((result) => {
                location.reload();
              });;
        });
      }
    });
  }