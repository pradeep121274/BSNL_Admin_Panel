function getallzonedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getZoneName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnzoneData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#region").html("");
        $("#region").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#region").append(
          '<option value="' + val.zone_id + '">' + val.zone_name + "</option>"
          );
        });
      });
}

function getcircledata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getCircles";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#circle_name").html("");
        $("#circle_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#circle_name").append(
          '<option value="' + val.circle_id + '">' + val.circle_name + "</option>"
          );
        });
      });
}

function getallssadata(){
  $('.ajax-loader').css("visibility","visible");
  var url = "api/getByStatusMaterialDelivered";
  let data = {
      "status":"Delivered"
  };
  var response = saveData(url, data);
  response.then( function(returnData) {
    $(".ajax-loader").css("visibility","hidden");
    $("#ssa_name").html("");
    $("#ssa_name").append("<option>-- Please Select --</option>");
    $.each(returnData.data,function(key,val){
        $("#ssa_name").append(
          '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
          );    
        });
  });
}

function getallSiteTypedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSiteTypes";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").html("");
        $("#site_type").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#site_type").append(
          '<option value="' + val.site_type_id + '">' + val.site_type + "</option>"
          );
        });
      });
}

function getallData(){
  $('.ajax-loader').css("visibility", "visible");
  var ssaId = $("#ssa_name").val();
    var url = "api/getIdFromSsaName";
    let data = {
      "ssa_id":ssaId
      };
    var response = saveData(url, data);
      response.then(function (returnData) {    // console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").val(returnData.data.ref_site_type_id).trigger("change");
        $("#region").val(returnData.data.ref_zone_id).trigger("change");
        $("#circle_name").val(returnData.data.ref_circle_id).trigger("change");

        $("#site_type").prop("disabled", true);  
         $("#region").prop("disabled", true); 
          $("#circle_name").prop("disabled", true); 
      });
}

function clearpge(){
  $("#region option:first").prop("selected",true).trigger("change");
  $("#circle_name option:first").prop("selected",true).trigger("change");
  $("#site_name").val("");
  $("#ssa_name option:first").prop("selected",true).trigger("change");
  $("#site_type option:first").prop("selected",true).trigger("change");
  $("#atdate").val("");
  $("#prestatus option:first").prop("selected",true).trigger("change");
  $("#actdate").val("");
  $("#at_status option:first").prop("selected",true).trigger("change");
  $("#cer_issue option:first").prop("selected",true).trigger("change");
  $("#finalatdate").val("");
  $("#partial_dt").val("");
  $("#full_dt").val("");
  $("#files").val("");
  $("#remarks").val("");
  $("#acceptid").val("");
  $("#files").removeAttr("val");
  $("#blahs").removeAttr("src");
  $("#blahs").removeAttr("width");
  $("#blahs").removeAttr("height");
}


function getallacceptancedata() {  
  $('.ajax-loader').css("visibility", "visible");
 //console.log("getall");
  var url = "api/getAllAcceptanceTest";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var newvdate1 = value.at_plandate;
      if(newvdate1 == "" || newvdate1 == null || newvdate1 == undefined)
      {
       var newplandate = "<td></td>";
      }
      else
      {
         newplandate = newvdate1.split("-").reverse().join("-");
         tbody += "<td>" + newplandate + "</td>";
      }

      tbody += "<td>" + value.pre_at_status + "</td>";

      var newvdate2 = value.pre_at_completiondate;
      if(newvdate2 == "" || newvdate2 == null || newvdate2 == undefined)
      {
       var preatcompdt = "<td></td>";
      }
      else
      {
         preatcompdt = newvdate2.split("-").reverse().join("-");
         tbody += "<td>" + preatcompdt + "</td>";
      }


      tbody += "<td>" + value.final_at_status + "</td>";

      var newvdate3 = value.final_at_completiondate;
      if(newvdate3 == "" || newvdate3 == null || newvdate3 == undefined)
      {
       var finalatcompdt = "<td></td>";
      }
      else
      {
       finalatcompdt = newvdate3.split("-").reverse().join("-");
      tbody += "<td>" + finalatcompdt + "</td>";
      }

      var newvpartialdt = value.partial_migration_date;
      if(newvpartialdt == "" || newvpartialdt == null || newvpartialdt == undefined)
      {
       var finalpartialdt = "<td>null</td>";
       tbody += finalpartialdt;
      }
      else
      {
       finalpartialdt = newvpartialdt.split("-").reverse().join("-");
      tbody += "<td>" + finalpartialdt + "</td>";
      }

      var newvfulldt = value.full_migration_date;
      if(newvfulldt == "" || newvfulldt == null || newvfulldt == undefined)
      {
       var finalfulldt = "<td>null</td>";
       tbody += finalfulldt;
      }
      else
      {
       finalfulldt = newvfulldt.split("-").reverse().join("-");
      tbody += "<td>" + finalfulldt + "</td>";
      }

      tbody += "<td>" + value.acceptance_certificate_issued + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

      if(value.acceptance_certificate_path  == "")
      {
        tbody += "<td></td>";
      }
      else
      {
        tbody += '<td><a href="' +value.acceptance_certificate_path + '" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Download" target="_blank">Download</a> &nbsp</td>';
      }

      if(roleid == '1')
      {  
            tbody += '<td><a onclick="enterBsnlRemarks(' +value.id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-placement="top" title="View" data-toggle="modal" data-target="#productsQuickView"  title="Enter Remarks">Remarks</a></td>';
      } 
      else
      {
            tbody +=
              '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
              value.id +
              "," +
              value.is_active +
              ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp <a data-toggle="tooltip" title="Delete" name="delete" id="delete" style="cursor:pointer; padding-left:5px;" onclick="activateDeactivateData(' +value.id +');"><i class="ti-trash" style="size:100%; color: #FF0000! important;"></i></a> &nbsp';
          // if(value.is_active  == 1)
          // { 
          //  tbody += '<a onclick="activateDeactivateData(' +value.id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
          // } 
          // else 
          // { 
          //  tbody += '<a onclick="activateDeactivateData(' +value.id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' 
          // }         
           tbody +='</td>';
        }
           tbody +='</tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}


var acceptanceid;
function enterBsnlRemarks(id){
  acceptanceid = id;
}

function submitRemarks(){
  var bsnlremarks     =   $("#bsnlremarks").val();

  if(bsnlremarks == ""){
      swal({
          title: 'info',
          text: 'Please enter Remarks',
          timer: 2000
      });
      return;
  }else{

  $('.ajax-loader').css("visibility", "visible");
  var myJsonString = {
    "bsnl_remarks":bsnlremarks,
    "id":acceptanceid
  }
  var url  = "api/updateAcceptanceTestStatus"
  var response = saveData(url, myJsonString);
  response.then(function (data) {
      $('.ajax-loader').css("visibility", "hidden");
      if(data.status == true){
        $('#productsQuickView').modal('hide');
        swal({
          type: "success",
          title: "Great...",
          text: "Remarks Submitted Successfully ...!",
          allowOutsideClick: false,
          confirmButtonText: "OK",
        }).then((result) => {
          location.reload();
        });
      }else{
          swal({
              text: data.message,
              timer: 2000
          });
      }
      
  });
  }
}

// function getBase64(file) {
//     return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.readAsDataURL(file);
//       reader.onload = () => resolve(reader.result);
//       reader.onerror = error => reject(error);
//     });
// }

function save_submit() { 
  var ssa_name = $("#ssa_name").val();
  var site_name = $("#site_name").val();
  var atdate = $("#atdate").val();
  var prestatus = $("#prestatus").val();
  var actdate = $("#actdate").val();
  var at_status = $("#at_status").val();
  var partialmgdate = $("#partial_dt").val();
  var fullmggdate = $("#full_dt").val();
  var cer_issue = $("#cer_issue").val();
  var finalatdate = $("#finalatdate").val();
  var remarks = $("#remarks").val();
  var acceptid = $("#acceptid").val();
    
  // console.log(partialmgdate,"partialmgdate"); console.log(fullmggdate,"fullmggdate");exit();
    // var acceptance_imgs = document.getElementById('files');
    // var imgcont = acceptance_imgs.files.length;

if(atdate == "" || atdate == null || atdate == undefined)
{
  var newatdate="";
}
else
{
   newatdate = atdate.split("-").reverse().join("-");
}

if(actdate == "" || actdate == null || actdate == undefined)
{
  var newactdate="";
}
else
{
  var newactdate = actdate.split("-").reverse().join("-");
}

if( partialmgdate== "" || partialmgdate == null || partialmgdate == undefined)
{
  var newpartialdate="";
}
else
{
  var newpartialdate = partialmgdate.split("-").reverse().join("-");
}

if( fullmggdate== "" || fullmggdate == null || fullmggdate == undefined)
{
  var newfulldate="";
}
else
{
  var newfulldate = fullmggdate.split("-").reverse().join("-");
}

if(finalatdate == "" || finalatdate == null || finalatdate == undefined)
{
  var newfinalatdate="";
}
else
{
   newfinalatdate = finalatdate.split("-").reverse().join("-");
}


 if (ssa_name == null || ssa_name == "" || ssa_name == undefined || ssa_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select SSA..",
    });
    return false;
  } 
    else if (site_name == null || site_name == "" || site_name == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Site Name..",
    });
    return false;
  }
    else if (atdate == null || atdate == "" || atdate == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select AT Plan Date..",
    });

    return false;
  }
    else if (prestatus == null || prestatus == "" || prestatus == undefined || prestatus == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Pre-AT Status..",
    });
    return false;
  }
    else if (actdate == null || actdate == "" || actdate == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Pre-AT Completion Date..",
    });

    return false;
  }
   else if (at_status == null || at_status == "" || at_status == undefined || at_status == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Final AT Status..",
    });
    return false;
  }
  else if (finalatdate == null || finalatdate == "" || finalatdate == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Final AT Completion Date..",
    });

    return false;
  }
    else if (cer_issue == null || cer_issue == "" || cer_issue == undefined || cer_issue == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Acceptance Certificate Issued..",
    });
    return false;
  }
  else 

          var formData = new FormData();
          var uploadFile = document.getElementById("files");
          console.log("uploadFile",uploadFile.files[0]);
          formData.append("acceptance_certificate_path", uploadFile.files[0]);
  {
    if (acceptid == "") 
    {  
     // console.log("save");
      // result = getBase64(acceptance_imgs.files[0]).then( function (data) {      
        //console.log("base64",data); 

      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesAcceptanceTest";
      // var myJsonString = 
      // {
      //   "ref_ssa_id":ssa_name,
      //   "site_name":site_name,
      //   "at_plandate":newatdate,
      //   "pre_at_status":prestatus,
      //   "pre_at_completiondate":newactdate,
      //   "final_at_status":at_status,
      //   "final_at_completiondate":newfinalatdate,
      //   "acceptance_certificate_issued":cer_issue,
      //   "acceptance_certificate_path":"",
      //   "remarks":remarks
      // };
      // console.log(JSON.stringify(myJsonString));
      // var response = saveData(url, myJsonString);
// console.log(newpartialdate,"newpartialdate"); console.log(newfulldate,"newfulldate");exit();
     formData.append("ref_ssa_id", ssa_name);
     formData.append("site_name", site_name);
     formData.append("at_plandate", newatdate);
     formData.append("pre_at_status", prestatus);
     formData.append("pre_at_completiondate", newactdate);
     formData.append("final_at_status", at_status);
     formData.append("final_at_completiondate", newfinalatdate);
     formData.append("partial_migration_date", newpartialdate);
     formData.append("full_migration_date", newfulldate);
     formData.append("acceptance_certificate_issued", cer_issue);
     formData.append("remarks", remarks);

    	var response = saveFormData(url, formData); 

      response.then(function (data) {   
      $('.ajax-loader').css("visibility", "hidden");

        if (data.status == true) {
          $("#region").val();
          $("#circle_name").val();
          $("#site_name").val();
          $("#ssa_name").val();
          $("#site_type").val();
          $("#atdate").val();
          $("#prestatus").val();
          $("#actdate").val();
          $("#at_status").val();
          $("#partial_dt").val();
          $("#full_dt").val();
          $("#cer_issue").val();
          $("#finalatdate").val();
          $("#remarks").val();
          $("#files").val();
          swal({
            type: "success",
            title: "Great...",
            text: "Acceptance Test Details has been Saved Successfully...!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
    // });
    } //end if of submit
    else if (acceptid !== "") { 
          
    //var filetype1 = acceptance_imgs.files[0].type;
      // result = getBase64(acceptance_imgs.files[0]).then( function (data) {      
       // console.log("update"); 
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesAcceptanceTest";
      // var myJsonString = 
      // {
      //   "id":acceptid,
      //   "ref_ssa_id":ssa_name,
      //   "site_name":site_name,
      //   "at_plandate":newatdate,
      //   "pre_at_status":prestatus,
      //   "pre_at_completiondate":newactdate,
      //   "final_at_status":at_status,
      //   "final_at_completiondate":newfinalatdate,
      //   "acceptance_certificate_issued":cer_issue,
      //   "acceptance_certificate_path":"",
      //   "remarks":remarks
      // };

      // var response = saveData(url, myJsonString);
  
     formData.append("id", acceptid);      
     formData.append("ref_ssa_id", ssa_name);
     formData.append("site_name", site_name);
     formData.append("at_plandate", newatdate);
     formData.append("pre_at_status", prestatus);
     formData.append("pre_at_completiondate", newactdate);
     formData.append("final_at_status", at_status);
     formData.append("final_at_completiondate", newfinalatdate);
     formData.append("partial_migration_date", newpartialdate);
     formData.append("full_migration_date", newfulldate);
     formData.append("acceptance_certificate_issued", cer_issue);
     formData.append("remarks", remarks);

    	var response = saveFormData(url, formData); 

      response.then(function (data) {    
          $('.ajax-loader').css("visibility", "hidden");
        if (data.status == true) {
          $("#region").val();
          $("#circle_name").val();
          $("#site_name").val();
          $("#ssa_name").val();
          $("#site_type").val();
          $("#atdate").val();
          $("#prestatus").val();
          $("#actdate").val();
          $("#at_status").val();
          $("#partial_dt").val();
          $("#full_dt").val();
          $("#cer_issue").val();
          $("#finalatdate").val();
          $("#remarks").val();       
          $("#acceptid").val();   
          $("#files").val();    
           swal({
            type: "success",
            title: "Great...",
            text: "Acceptance Test Details has been Updated Successfully...!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: "Data Updation failed!",
          });
        }
      });
    // });
    } 
    else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went Wrong..!",
      });
    }
  }
}

function editpopulate(id, isActive) {
  if (isActive == 0) {  console.log("isn't active");
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else { console.log("is active");
    $("#acceptance_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");

    var url = "api/getAcceptanceTestById";
    var myJsonString = 
      {
         "acceptance_id":id    
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) {  console.log("editdata",returnData);
      $('.ajax-loader').css("visibility", "hidden");
      $("#ssa_name").val(returnData.data.ref_ssa_id).trigger("change");
      $("#site_name").val(returnData.data.site_name);

      var newvdate1 = returnData.data.at_plandate;
       if(newvdate1 == null || newvdate1 == "" || newvdate1 == undefined)
         {
          var newplandate="";
         }
         else{
          newplandate = newvdate1.split("-").reverse().join("-");
          $("#atdate").val(newplandate);     
        }


      $("#prestatus").val(returnData.data.pre_at_status).trigger("change");

      var newvdate2 = returnData.data.pre_at_completiondate;
       if(newvdate2 == null || newvdate2 == "" || newvdate2 == undefined)
         {
          var newprecompletiondate="";
         }
         else{
          newprecompletiondate = newvdate2.split("-").reverse().join("-");
          $("#actdate").val(newprecompletiondate);  
        }


      $("#at_status").val(returnData.data.final_at_status).trigger("change");
      $("#cer_issue").val(returnData.data.acceptance_certificate_issued).trigger("change");

      //console.log("newfinalatdate",returnData.data.final_at_completiondate);


      var newvdate3 = returnData.data.final_at_completiondate;
       if(newvdate3 == null || newvdate3 == "" || newvdate3 == undefined)
         {
          var newfinalatdate="";
         }
         else{
       newfinalatdate = newvdate3.split("-").reverse().join("-");
      //console.log("newfinalatdate",newfinalatdate);

      $("#finalatdate").val(newfinalatdate);
        }

      var newvpartialdt = returnData.data.partial_migration_date;
       if(newvpartialdt == null || newvpartialdt == "" || newvpartialdt == undefined)
         {
          var newpartialdate="";
          $("#partial_dt").val(newpartialdate);
         }
         else
         {
          newpartialdate = newvpartialdt.split("-").reverse().join("-");
          $("#partial_dt").val(newpartialdate);
        }

      var newvfullmgdt = returnData.data.full_migration_date;
       if(newvfullmgdt == null || newvfullmgdt == "" || newvfullmgdt == undefined)
         {
          var newfullmgdate="";
          $("#full_dt").val(newfullmgdate);
         }
         else
         {
          newfullmgdate = newvfullmgdt.split("-").reverse().join("-");
          $("#full_dt").val(newfullmgdate);
        }

      $("#remarks").val(returnData.data.remarks);   
     // $("#files").attr(returnData.data.acceptance_certificate_path);  
      $("#files").attr("val",returnData.data.acceptance_certificate_path);
      $("#blahs").attr("src",returnData.data.acceptance_certificate_path);
      $("#blahs").attr("width","100px");
	    $("#blahs").attr("height","100px");
      $("#acceptid").val(returnData.data.id);  
    });
  }
}

function activateDeactivateData(id) {  //console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Delete this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/deletedAcceptanceTestById";
      var myJsonString = {
        "id":id,
      }
       var response = saveData(url, myJsonString);
       
      response.then(function (data) { //console.log("data",data);
     $('.ajax-loader').css("visibility", "hidden");
        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}