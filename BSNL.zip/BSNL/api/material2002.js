function getcircledata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getCircles";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#circle_name").html("");
        $("#circle_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#circle_name").append(
          '<option value="' + val.circle_id + '">' + val.circle_name + "</option>"
          );
        });
      });
}


function getssadata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSites";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#ssa_name").html("");
        $("#ssa_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#ssa_name").append(
          '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
          );
        });
      });
}

function getallzonedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getZoneName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnzoneData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#zone_name").html("");
        $("#zone_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#zone_name").append(
          '<option value="' + val.zone_id + '">' + val.zone_name + "</option>"
          );
        });
      });
}
function getallSiteTypedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSiteTypes";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").html("");
        $("#site_type").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#site_type").append(
          '<option value="' + val.site_type_id + '">' + val.site_type + "</option>"
          );
        });
      });
}

function getallData(){
  $('.ajax-loader').css("visibility", "visible");
  var ssaId = $("#ssa_name").val();
    var url = "api/getIdFromSsaName";
    let data = {
      "ssa_id":ssaId
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").val(returnData.data.ref_site_type_id).trigger("change");
        $("#zone_name").val(returnData.data.ref_zone_id).trigger("change");
        $("#circle_name").val(returnData.data.ref_circle_id).trigger("change");

        $("#site_type").prop("disabled", true);  
         $("#zone_name").prop("disabled", true); 
          $("#circle_name").prop("disabled", true); 
      });
}

function clearpge(){
  $("#zone_name option:first").prop("selected", true).trigger("change");
  $("#circle_name option:first").prop("selected", true).trigger("change");
  $("#ssa_name option:first").prop("selected", true).trigger("change");
  $("#site_type option:first").prop("selected", true).trigger("change");
  $("#sign_off option:first").prop("selected", true).trigger("change");
  $("#mdate").val("");
  $("#ddate").val("");
  $("#received_by").val("");
  $("#status option:first").prop("selected", true).trigger("change");
  $("#dispatchdate").val("");
  $("#remarks").val("");
}

function getallmaterialdata() {   //console.log("getall");
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); 
  var yyyy = today.getFullYear();

  today = dd + "-" + mm + "-" + yyyy;
    console.log("---->today", today);

  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMaterialDelivery";
  let data = {
   };
  var response = saveData(url, data);
 // console.log("getall");
  response.then(function (returnData) {
   //  console.log("getall",returnData);
    $('.ajax-loader').css("visibility", "hidden");

    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      console.log("value",value);

          var date1 = value.material_delivery_plan;

         if(date1 == null || date1 == "" || date1 == undefined)
         {
          var plan_date="";
         }
         else{
           plan_date = date1.split("-").reverse().join("-");
         }

        if(plan_date <= today  && (value.status == "Pending" || value.status == "Hold")){   
          var colorval = "#E21717";
        }

    tbody += "<tr><td style='color:"+colorval+";'>" + i + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.zone_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.circle_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.ssa_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.site_type + "</td>";


      var date1 = value.material_delivery_plan;

      if(date1 == null || date1 == "" || date1 == undefined)
      {
          tbody += "<td></td>";
      } 
      else 
      {
          var plann_date = date1.split("-").reverse().join("-");
          tbody += "<td style='color:"+colorval+";'>" + plann_date + "</td>";
      }

      var date2 = value.material_receiving_date;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
            var receiving_date = date2.split("-").reverse().join("-");
            tbody += "<td style='color:"+colorval+";'>" + receiving_date + "</td>";
      }
    tbody += "<td style='color:"+colorval+";'>" + value.material_receiving_by + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.signoff_bsnl + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.status + "</td>";
    var dispatch_newdate = value.material_dispatch_date;
      if(dispatch_newdate == null || dispatch_newdate == ""|| dispatch_newdate == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
            var dispatched_date = dispatch_newdate.split("-").reverse().join("-");
            tbody += "<td style='color:"+colorval+";'>" + dispatched_date + "</td>";
      }
    tbody += "<td style='color:"+colorval+";'>" + value.remarks + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.bsnl_remarks + "</td>";


          if(roleid == '1')
          {
            tbody += '<td><a onclick="enterBsnlRemarks(' +value.delivery_id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-placement="top" title="View" data-toggle="modal" data-target="#productsQuickView"  title="Enter Remarks">Remarks</a></td>';
          }
          else 
          {
            tbody +=
            '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
            value.delivery_id +
            "," +
            value.is_active +
            ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp <a data-toggle="tooltip" title="Delete" name="delete" id="delete" style="cursor:pointer; padding-left:5px;" onclick="activateDeactivateData(' +value.delivery_id +');"><i class="ti-trash" style="size:100%; color: #FF0000! important;"></i></a> &nbsp ';
            // if(value.is_active  == 1){ 
            //   tbody += '<a onclick="activateDeactivateData(' +value.delivery_id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
            //   } else { 
            //   tbody += '<a onclick="activateDeactivateData(' +value.delivery_id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' }
              tbody +='</td>';
          } 
      
           tbody +='</tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}

var deliveryid;
function enterBsnlRemarks(id){
  deliveryid = id;
}

function submitRemarks(){
  var bsnlremarks     =   $("#bsnlremarks").val();

  if(bsnlremarks == ""){
      swal({
          title: 'info',
          text: 'Please enter Remarks',
          timer: 2000
      });
      return;
  }else{

  $('.ajax-loader').css("visibility", "visible");
  var myJsonString = {
    "bsnl_remarks":bsnlremarks,
    "delivery_id":deliveryid
  }
  var url  = "api/updateMaterialDeliveryStatus"
  var response = saveData(url, myJsonString);
  response.then(function (data) {
      $('.ajax-loader').css("visibility", "hidden");
      if(data.status == true){
        $('#productsQuickView').modal('hide');
        swal({
          type: "success",
          title: "Great...",
          text: "Remarks Submited Successfully ...!",
          allowOutsideClick: false,
          confirmButtonText: "OK",
        }).then((result) => {
          location.reload();
        });
      }else{
          swal({
              text: data.message,
              timer: 2000
          });
      }
      
  });
  }
}

function save_submit() {  
  var ssa_name = $("#ssa_name").val();
  var mdate = $("#mdate").val();
  var received_by = $("#received_by").val();
  var ddate = $("#ddate").val();
  var sign_off = $("#sign_off").val();
  var status = $("#status").val();
  var dispatchdate = $("#dispatchdate").val();
  var remarks = $("#remarks").val();
  var materialid = $("#materialid").val();



if(sign_off ==  "-- Please Select --"){
 var ssign_off = "";
}else{
  ssign_off = sign_off;
}

    if(mdate == "" || mdate == null || mdate == undefined)
    {
    var newmdate = "";
    }
    else{
       newmdate = mdate.split("-").reverse().join("-");
    }

    if(ddate == "" || ddate == null || ddate == undefined)
    {
    var newddate = "";
    }
    else{
       newddate = ddate.split("-").reverse().join("-");
    }

    if(dispatchdate == "" || dispatchdate == null || dispatchdate == undefined)
    {
    var newdispatchdate = "";
    }
    else{
     newdispatchdate = dispatchdate.split("-").reverse().join("-");
    }

 
if (ssa_name == null || ssa_name == "" || ssa_name == undefined || ssa_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select SSA..",
    });
    return false;
  }
  else if (mdate == null || mdate == "" || mdate == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Material Delivery Plan Date..",
    });
    return false;
  }

//     else if (received_by == null || received_by == "" || received_by == undefined) {
//     swal({
//       type: "error",
//       title: "Oops...",
//       text: "Please Select Material Received By..",
//     });
//     return false;
//   }
//     else if (ddate == null || ddate == "" || ddate == undefined) {
//     swal({
//       type: "error",
//       title: "Oops...",
//       text: "Please Enter Material Receiving Date..",
//     });
//     return false;
//   }
//   else if (sign_off == null || sign_off == "" || sign_off == undefined || sign_off == "-- Please Select --") {
//     swal({
//       type: "error",
//       title: "Oops...",
//       text: "Please Select Sign Off By BSNL..",
//     });
//     return false;
//   } 
   else if (status == null || status == "" || status == undefined || status == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Status..",
    });
    return false;
  }
  else 
  {
    if (materialid == "") 
    {  
     // console.log("save");

     if(status == "Partial_Delivery")
      { console.log("partial");
        if(remarks == "" || remarks == undefined || remarks == null)
        {
        swal({
          type: "error",
          title: "Oops...",
          text: "Please Select Remarks..",
        });
        return false;
        }
        else
        {  console.log("partialelse");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesMaterialDelivery";
      var myJsonString = 
      {
        "ref_ssa_id":ssa_name,
        "material_delivery_plan":newmdate,
        "material_receiving_date":newddate,
        "material_receiving_by":received_by,
        "material_dispatch_date":newdispatchdate,
        "signoff_bsnl":ssign_off,
        "status":status,
        "remarks":remarks
      };

        console.log(myJsonString,"myJsonString");

      var response = saveData(url, myJsonString);
     console.log(response,"response");
      response.then(function (data) {       
        console.log("savedata",data);
          $('.ajax-loader').css("visibility", "hidden");

        if (data.message == "Material Delivery Details saved Successfully") {
          $("#zone").val("");
          $("#circle").val("");
          $("#ssa_name").val("");
          $("#site_type").val("");
          $("#address").val("");
          $("#sign_off").val("");
          $("#mdate").val("");
          $("#received_by").val("");
          $("#ddate").val("");
          $("#dispatchdate").val("");
          $("#status").val("");
          $("#remarks").val("");

          swal({
            type: "success",
            title: "Great...",
            text: "Material Delivery Details has been Saved Successfully!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
    }
    }
    else
    {
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesMaterialDelivery";
      var myJsonString = 
      {
        "ref_ssa_id":ssa_name,
        "material_delivery_plan":newmdate,
        "material_receiving_date":newddate,
        "material_receiving_by":received_by,
        "material_dispatch_date":newdispatchdate,
        "signoff_bsnl":ssign_off,
        "status":status,
        "remarks":remarks
      };

        console.log(myJsonString,"myJsonString");

      var response = saveData(url, myJsonString);
     console.log(response,"response");
      response.then(function (data) {       
        console.log("savedata",data);
          $('.ajax-loader').css("visibility", "hidden");

        if (data.message == "Material Delivery Details saved Successfully") {
          $("#zone").val("");
          $("#circle").val("");
          $("#ssa_name").val("");
          $("#site_type").val("");
          $("#address").val("");
          $("#sign_off").val("");
          $("#mdate").val("");
          $("#received_by").val("");
          $("#ddate").val("");
          $("#dispatchdate").val("");
          $("#status").val("");
          $("#remarks").val("");

          swal({
            type: "success",
            title: "Great...",
            text: "Material Delivery Details has been Saved Successfully!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
    }
    } //end if of submit
    else if (materialid !== "") {    
      console.log("update");

     if(status == "Partial_Delivery")
      { console.log("partial");
        if(remarks == "" || remarks == undefined || remarks == null)
        {
        swal({
          type: "error",
          title: "Oops...",
          text: "Please Select Remarks..",
        });
        return false;
        }
        else
        {
      $('.ajax-loader').css("visibility", "visible");

      var url = "api/saveUpdatesMaterialDelivery";
      var myJsonString = 
      {
        "delivery_id":materialid,
        "ref_ssa_id":ssa_name,
        "material_delivery_plan":newmdate,
        "material_receiving_date":newddate,
        "material_receiving_by":received_by,
        "material_dispatch_date":newdispatchdate,
        "signoff_bsnl":ssign_off,
        "status":status,
        "remarks":remarks
      };
      var response = saveData(url, myJsonString);
      response.then(function (data) {            console.log("data",data);
       $('.ajax-loader').css("visibility", "hidden");

        if (data.message == "Material Delivery Details updated Successfully") {
          $("#materialid").val("");
          $("#zone").val("");
          $("#circle").val("");
          $("#ssa_name").val("");
          $("#site_type").val("");
          $("#address").val("");
          $("#sign_off").val("");
          $("#mdate").val("");
          $("#received_by").val("");
          $("#ddate").val("");
          $("#dispatchdate").val("");
          $("#status").val("");
          $("#remarks").val(""); 

           swal({
            type: "success",
            title: "Great...",
            text: "Material Delivery Details has been updated Successfully!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
    }
  }
  else
  {
      $('.ajax-loader').css("visibility", "visible");

      var url = "api/saveUpdatesMaterialDelivery";
      var myJsonString = 
      {
        "delivery_id":materialid,
        "ref_ssa_id":ssa_name,
        "material_delivery_plan":newmdate,
        "material_receiving_date":newddate,
        "material_receiving_by":received_by,
        "material_dispatch_date":newdispatchdate,
        "signoff_bsnl":ssign_off,
        "status":status,
        "remarks":remarks
      };
      var response = saveData(url, myJsonString);
      response.then(function (data) {            console.log("data",data);
       $('.ajax-loader').css("visibility", "hidden");

        if (data.message == "Material Delivery Details updated Successfully") {
          $("#materialid").val("");
          $("#zone").val("");
          $("#circle").val("");
          $("#ssa_name").val("");
          $("#site_type").val("");
          $("#address").val("");
          $("#sign_off").val("");
          $("#mdate").val("");
          $("#received_by").val("");
          $("#ddate").val("");
          $("#dispatchdate").val("");
          $("#status").val("");
          $("#remarks").val(""); 

           swal({
            type: "success",
            title: "Great...",
            text: "Material Delivery Details has been updated Successfully!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
  }


    } // end of updt  
    else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went wrong!",
      });
    }
  }
}

function editpopulate(id,isActive) {
  if (isActive == 0) {  console.log("id",id);
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else { //console.log("is active");
    $("#material_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
   $('.ajax-loader').css("visibility", "visible");

    var url = "api/getMaterialDeliveryById";
    var myJsonString = 
      {
         "delivery_id":id
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) {  console.log("editdata",returnData);
     $('.ajax-loader').css("visibility", "hidden");
     $("#materialid").val(returnData.data.delivery_id); 
     $("#ssa_name").val(returnData.data.ref_ssa_id).trigger('change');
     $("#site_type").val(returnData.data.site_type_id).trigger('change'); 
     $("#zone_name").val(returnData.data.zone_id).trigger('change');
     $("#circle_name").val(returnData.data.circle_id).trigger('change');
       
      var deliveryplandt = returnData.data.material_delivery_plan;
          if(deliveryplandt == null || deliveryplandt == "" || deliveryplandt == undefined){ 
            var plandate = "";
          } 
          else
          {
             plandate = deliveryplandt.split("-").reverse().join("-");
          }


      var deliveryreceivedt = returnData.data.material_receiving_date;
                
      if(deliveryreceivedt == null || deliveryreceivedt == "" || deliveryreceivedt == undefined){ 
            var receivedate = "";
          } 
          else
          {
          receivedate = deliveryreceivedt.split("-").reverse().join("-");
          }


      $("#mdate").val(plandate);
      $("#ddate").val(receivedate);
      $("#received_by").val(returnData.data.material_receiving_by);
      $("#sign_off").val(returnData.data.signoff_bsnl).trigger("change");
      $("#status").val(returnData.data.status).trigger("change");
            
       var deliverydispatchdt = returnData.data.material_dispatch_date;
      if(deliverydispatchdt == null || deliverydispatchdt == "" || deliverydispatchdt == undefined){ 
        var dispatchdate = "";
      } 
      else
      {
         dispatchdate = deliverydispatchdt.split("-").reverse().join("-");
      }

      $("#dispatchdate").val(dispatchdate);
      $("#remarks").val(returnData.data.remarks);      
    });
  }
}

function activateDeactivateData(id) {  //console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Delete this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
   $('.ajax-loader').css("visibility", "visible");

      var url = "api/deletedMaterialDeliveryById";
      var myJsonString = {
          "delivery_id":id
      }
       var response = saveData(url, myJsonString);
       
      response.then(function (data) { //console.log("data",data);
     $('.ajax-loader').css("visibility", "hidden");

        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}