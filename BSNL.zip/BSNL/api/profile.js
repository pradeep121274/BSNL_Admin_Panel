var base;
function editProfileData(baseurl) {
    base = baseurl;
    var user_id = localStorage.getItem("userid");
    console.log(user_id);
     var myJsonString = {
         "user_id": user_id
     };
     var url = "admin/AdminEditProfile";
     var response = saveData(url, myJsonString);
     response.then(function (data) {
         console.log(data);
         $("#hiddensubtypeid").val(data.data.user_id);
         $("#autoname").val(data.data.name);
         $("#autoemail").val(data.data.emailid);
         $("#automobile").val(data.data.mobileno);
    
     })
 }

 function updateUser(){
     var hiddensubtypeid = $("#hiddensubtypeid").val();
     var autoname = $("#autoname").val();
     var autoemail = $("#autoemail").val();
     var automobile = $("#automobile").val();

     var myJsonString = {
        "user_name":"Shobha123",
        "name": autoname,
        "emailid":autoemail,
        "mobileno":automobile,
        "user_id":hiddensubtypeid
    };
    var url = "admin/AdminUpdateProfile";
    var response = saveData(url, myJsonString);
    response.then(function (data) {
        if(data.success == true){
            swal({
                "text": data.message,
                "allowOutsideClick": false
            }).then(function () {
                location.reload(); 
            });
        }else{
            swal({
                "text": data.message,
                "allowOutsideClick": false
            });
        }
    })
 }