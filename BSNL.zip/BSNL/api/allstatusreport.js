function getcurrentdate() { 
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
  var yyyy = today.getFullYear();

  today = dd + "-" + mm + "-" + yyyy;
  //document.write(today);
 // console.log("---->today", today);
  $("#start_date").val(today);
  $("#end_date").val(today);
   
  var currentdt = 'From ' +today+'  To  '+today;
  $("#datecurrent").html(currentdt);
  ordersList();
}

function getzonedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getZoneName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnzoneData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#zone_name").html("");
        $("#zone_name").append("<option>-- ALL --</option>");
          $.each(returnData.data,function(key,val){
         $("#zone_name").append(
          '<option value="' + val.zone_id + '">' + val.zone_name + "</option>"
          );
        });
      });
}

function getcircledata(){
    $('.ajax-loader').css("visibility", "visible");
    var zone_name = $("#zone_name").val();
    var url = "api/getAllCircleByZoneId";
    let data = {
      "zone_id":zone_name
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#circle_name").html("");
        $("#circle_name").append("<option>-- ALL --</option>");
          $.each(returnData.data,function(key,val){
         $("#circle_name").append(
          '<option value="' + val.circle_id + '">' + val.circle_name + "</option>"
          );
        });
      });
}

function getssadata(){
    $('.ajax-loader').css("visibility", "visible");
    var circle_name = $("#circle_name").val();
    var url = "api/getAllSsaByCircleId";
    let data = {
      "circle_id": circle_name
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#ssa_name").html("");
        $("#ssa_name").append("<option>-- ALL --</option>");
          $.each(returnData.data,function(key,val){
         $("#ssa_name").append(
          '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
          );
        });
      });
}

function clearForm() {
  $("#start_date").val("");
  $("#end_date").val("");
  $("#circle_name option:first").prop("selected","true").trigger("change");

  $("#allusers").html("");
  var tbody = "";
  tbody +=
    '<tr>\n\
    <td colspan="10" style="text-align: center;color: red;"> No data found to display.! </td></tr>';
  $("#allusers").html("");
  $("#allusers").append(tbody);
}
 
function ordersList() { //console.log("orders");
  $("#allusers").html("");

  var startdate = $("#start_date").val();
  var enddate = $("#end_date").val();
  var zone_name = $("#zone_name").val();
  var circle_name = $("#circle_name").val();
  var ssa_name = $("#ssa_name").val();

  var date = startdate;
  var start_date = date.split("-").reverse().join("-");
  var date1 = enddate;
  var end_date = date1.split("-").reverse().join("-");


    var currentdto = 'From ' +startdate+'  To  '+enddate;
   $("#datecurrent").html(currentdto);

 if(zone_name == "-- ALL --" || zone_name == "" || zone_name == null || zone_name == undefined){   
  var zonename = "";
  }
  else{ 
     zonename = zone_name;
  }
    if(circle_name == "-- ALL --" || circle_name == "" || circle_name == null || circle_name == undefined){   
  var circlename = "";
  }
  else{ 
     circlename = circle_name;
  }
    if(ssa_name == "-- ALL --" || ssa_name == "" || ssa_name == null || ssa_name == undefined){   
  var ssaname = "";
  }
  else{ 
     ssaname = ssa_name;
  }

  if (startdate !== "" && enddate !== "") {
    var url = "api/getAllBSNLReports";
    let data = {
       "startdate":start_date,
       "enddate":end_date,
       "zone_id":zonename,
       "circle_id":circlename,
       "ssa_id":ssaname
       };
     
       console.log("data",data);
    var response = saveData(url, data);
    response.then(function (data) {
      console.log("allreportsdata",data);

      var tbody = "";
      var i = 1;
      if (data.status == false) {
         tbody +=
           '<tr>\n\
    <td colspan="10" style="text-align: center;color: red;"> No Records found to display.! </td></tr>';
      } else {
          $.each(data.data, function (key, value) {   console.log("value",value);

          // var plandt = value.installation_plandate;
          // var newplandate = plandt.split("-").reverse().join("-");

          var newplandt = value.material_delivery_plan;
            if(newplandt == null || newplandt == "" || newplandt == undefined)
            {
              var newplandate="";
            }
            else{
              newplandate = newplandt.split("-").reverse().join("-");
            }

           var newvdate1 = value.installation_completeddate;
          if(newvdate1 == null || newvdate1 == "" || newvdate1 == undefined)
         {
          var newcompdate="";
         }
         else{
           newcompdate = newvdate1.split("-").reverse().join("-");
        }

          var newvrdate1 = value.final_at_completiondate;
          if(newvrdate1 == null || newvrdate1 == "" || newvrdate1 == undefined)
            {
              var newatcompdate="";
            }
            else{
              newatcompdate = newvrdate1.split("-").reverse().join("-");  
            }

            var newvrpartialdt = value.partial_migration_date;
          if(newvrpartialdt == null || newvrpartialdt == "" || newvrpartialdt == undefined)
            {
              var newpartialdate="";
            }
            else{
              newpartialdate = newvrpartialdt.split("-").reverse().join("-");  
            }

            var newvrfullmgdt = value.full_migration_date;
          if(newvrfullmgdt == null || newvrfullmgdt == "" || newvrfullmgdt == undefined)
            {
              var newfullmggdate="";
            }
            else{
              newfullmggdate = newvrfullmgdt.split("-").reverse().join("-");  
            }
          
            var newvrcommissiondt = value.comminssioning_date;
            if(newvrcommissiondt == null || newvrcommissiondt == "" || newvrcommissiondt == undefined)
            {
              var newcommissiondate="";
            }
            else{
              newcommissiondate = newvrcommissiondt.split("-").reverse().join("-");  
            }
   
            tbody +=
              "<tr>\n\
                <td>" +
              i +
              "</td>\n\
                <td>" +
              value.zone_name +
              "</td>\n\
                <td>" +
              value.circle_name +
              "</td>\n\
               <td>" +
              value.ssa_name + 
              "</td>\n\
              <td>" +
              newplandate +
              "</td>\n\
              <td>" +
              newcompdate +
              "</td>\n\
              <td>"+
              newcompdate +
              "</td>\n\
              <td>"+
              value.MPLS_reachability +
              "</td>\n\
              <td>" +
              newatcompdate +
              "</td>\n\
              <td>" +
              newpartialdate +
              "</td>\n\
                <td>"+
               newfullmggdate +
              "</td>\n\
              <td>"+
               newcommissiondate +
              "</td>\n\
               </tr>";
          i++;
        });
      }
   
      $("#allusers").html("");
      $("#allusers").append(tbody);
    });
  } else {  
    var msg = "kindly select date.. !";
    var tbody = "";
    tbody +=
      '<tr>\n\
    <td colspan="10" style="text-align: center;color: red;"> No data found to display.! </td></tr>';
    $("#allusers").html("");
    $("#allusers").append(tbody);
    swal(msg);
  }
}