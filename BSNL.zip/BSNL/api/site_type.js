function getAllSiteTypes() {  
  $('.ajax-loader').css("visibility", "visible");
     //console.log("getall");
  var url = "api/getAllSiteTypes";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      console.log("value",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.site_type + "</td>";


      tbody +=
        '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
        value.site_type_id +
        "," +
        value.is_active +
        ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp ';
        if(value.is_active  == 1){ 
           tbody += '<a onclick="activateDeactivateData(' +value.site_type_id +');" style="cursor:pointer;background-color: #027e61;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
          } else { 
           tbody += '<a onclick="activateDeactivateData(' +value.site_type_id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' }
           '</td></tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}

function save_submit() { 
  var site_type = $("#site_type").val();
  var sitetypeid = $("#sitetypeid").val();

   if (site_type == null || site_type == "" || site_type == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Site Type..",
    });
    return false;
  } 
  else 
  {
    if (sitetypeid == "") 
    {  //console.log("save");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesSiteTypes";
      var myJsonString = 
      {
        "site_type":site_type  
      };

      var response = saveData(url, myJsonString);
     console.log(response,"response");
      response.then(function (data) {       console.log(data,"data");
    $('.ajax-loader').css("visibility", "hidden");

        if (data.status == true) {
          $("#site_type").val("");
          swal({
            type: "success",
            title: "Great...",
            text: "Site Type Details has been Saved Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          }).then((result) => {
          $("#site_type").val("");
          });
        }
      });
    } //end if of submit
    else if (sitetypeid !== "") { //console.log("update");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesSiteTypes";
      var myJsonString = 
      {
        "site_type_id":sitetypeid,
        "site_type":site_type      
      };
      var response = saveData(url, myJsonString);
      response.then(function (data) {           // console.log("data",data);
          $('.ajax-loader').css("visibility", "hidden");
        if (data.status == true) {
          $("#sitetypeid").val("");
          $("#site_type").val("");       
           swal({
            type: "success",
            title: "Great...",
            text: "Site Type Details has been updated Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: "Data Updation failed!",
          });
        }
      });
    } else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went Wrong..!",
      });
    }
  }
}

function editpopulate(id, isActive) {
  if (isActive == 0) {  //console.log("isn't active");
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else {    //console.log("is active");
    $("#sitetype_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");

    var url = "api/getIdBySiteTypes";
    var myJsonString = 
      {
         "site_type_id":id    
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) { 
      console.log("data",returnData);
      $('.ajax-loader').css("visibility", "hidden");
      $("#site_type").val(returnData.data.site_type);
      $("#sitetypeid").val(returnData.data.site_type_id);
    });
  }
}



function clearpge(){
  $("#site_type").val("");
  $("#sitetypeid").val("");

}

function activateDeactivateData(id) {  //console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Enable / Disable this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/deleteSiteTypesById";
      var myJsonString = {
        "site_type_id":id,
      }
       var response = saveData(url, myJsonString);
       
      response.then(function (data) { //console.log("data",data);
     $('.ajax-loader').css("visibility", "hidden");
        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}