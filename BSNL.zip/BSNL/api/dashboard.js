function getAllDashboardData(){
   // var url = "admin/AdminDashboard";
   var url ="api/getAllBsnlDashboardData";
   let data={};
   var response = saveData(url, data);
   // console.log("res",response);
    response.then(function(data) { 
       console.log(data);

    
        $("#ssacount").html(data.data.ssa_totalcnt);
        $("#materialssacount").html(data.data.ssa_totalcnt);
        $("#powerssacount").html(data.data.ssa_totalcnt);
        $("#commissionssacount").html(data.data.ssa_totalcnt);
        $("#acceptancessacount").html(data.data.ssa_totalcnt);
        $("#mplssacount").html(data.data.ssa_totalcnt);

        $("#surveycount").html(data.data.surveycount);
        $("#materialdelivery").html(data.data.materialdeliverycount);
        $("#inventorycount").html(data.data.inventory_managementcount);
        $("#installationcount").html(data.data.installation_Statustotalcnt);
        $("#commissioncount").html(data.data.commissioningStatusCount);
        //alert(data.data.commissioningStatusCount)
        //$("#commissioncount").html('0');
        $("#acceptancecount").html(data.data.acceptancetestcount);

        $("#readyinstallcnt").html(data.data.Site_ready_for_installation_totalcnt);
        $("#ntreadytoinstallcnt").html(data.data.Site_with_open_issues_totalcnt);

        $("#materialdispatchcnt").html(data.data.in_transitcount);
        $("#materialpartialcnt").html(data.data.partial_deliverycount);    

        
        $("#installationcount").html(data.data.equipment_power_StatusCount);
        $("#installprogresscnt").html(data.data.installation_on_progresstotalcnt);
        $("#installholdcnt").html(data.data.installation_activity_holdtotalcnt);

        $("#mplsreachcnt").html(data.data.MPLS_reachabilityCount);
        $("#bngtypeone").html(data.data.bngtypeonetotalcount);
        $("#bngtypetwo").html(data.data.bngtypetwototalcount);
        $("#controlplanecnt").html(data.data.controlplanetotalcount);
        $("#rpopcnt").html(data.data.RPOPtotalcount);
        $("#mplsupscnt").html(data.data.MplsUPStotalcount);
        //alert(data.data.commissioning_bngonetotalcount)
        $("#commissionbngonecnt").html(data.data.commissioning_bngonetotalcount);
       // $("#commissionbngonecnt").html('0');
        $("#commissionbngtwocnt").html(data.data.commissioning_bngtwototalcount);
       // $("#commissionbngtwocnt").html('0');
        $("#commissioncontrolcnt").html(data.data.commissioning_controlplanetotalcount);
        $("#commissionrpopcnt").html(data.data.commissioning_rpopplanetotalcount);
        $("#commissionupscnt").html(data.data.commissioning_upstotalcount);
        //  $("#commissioncontrolcnt").html('0');
        // $("#commissionrpopcnt").html('0');
        // $("#commissionupscnt").html('0');

        $("#acceptancebngonecnt").html(data.data.acceptance_bngonetotalcount);
        $("#acceptancebngtwocnt").html(data.data.acceptance_bngtwototalcount);
        $("#acceptancecontrolcnt").html(data.data.acceptance_controlplanetotalcount);
        $("#acceptancerpopcnt").html(data.data.acceptance_rpopplanetotalcount);
        $("#acceptanceupscnt").html(data.data.acceptance_upsplanetotalcount);

        $("#materialopenissuecnt").html(data.data.materialdeliverystatuscount);
        $("#installopenissuecnt").html(data.data.equipment_power_StatusNotCount);
        $("#mplsopenissuecnt").html(data.data.MPLS_reachabilityNotCount);
        $("#commissionopenissuecnt").html(data.data.commissioningNotStatusCount);
        //$("#commissionopenissuecnt").html('0');
        $("#acceptanceopenissuecnt").html(data.data.acceptancetestfinalatstatuscount);
    })
}

function undelivereddata(){
   var url ="api/updatesByMsterialDeliveryStatus";
    let data={};
   var response = saveData(url, data); 
    response.then(function(data) {   //console.log("datapend",data);
         $("#undeliveredcount").html(data.data.statusCount);
    })
}

function readytoinstall(){ 
    var roleid = window.localStorage.getItem("roleid"); 
    // $("#SurveyQuickView").modal('hide');

    var url ="api/getAllSiteReadyInstallation";
    let data={
        "site_ready_for_installation":"Yes"
    };
    var response = saveData(url, data); 
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");

    // $("#SurveyQuickView").modal('show');

    // console.log("getall",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("value",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";

       if (value.site_survey_plandate == null || value.site_survey_plandate == "" || value.site_survey_plandate == undefined)
       {
 
              tbody += "<td></td>";
       }
       else
       {
            var date = value.site_survey_plandate;
            var start_date = date.split("-").reverse().join("-");
             tbody += "<td>" + start_date + "</td>";
       }
            tbody += "<td>" + value.site_survey_status + "</td>";


        if (value.site_survey_completeddate == null || value.site_survey_completeddate == "" || value.site_survey_completeddate == undefined)
        {
            tbody += "<td></td>";
        }
        else
        {
            var date1 = value.site_survey_completeddate;
            var end_date = date1.split("-").reverse().join("-");
            tbody += "<td>" + end_date + "</td>";
        }

      tbody += "<td>" + value.survey_reportsinoff + "</td>";
      tbody += "<td>" + value.report_upload_status + "</td>";
      tbody += "<td>" + value.site_ready_for_installation + "</td>";

      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";   
           tbody +='</tr>';
           i++;
    });
    $('#example').dataTable().fnClearTable();
    $('#example').dataTable().fnDraw();
    $('#example').dataTable().fnDestroy();
    $("#allsiteopen").html("");
    $("#allsiteopen").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}


function siteissue(){ 
    var roleid = window.localStorage.getItem("roleid"); 
    // $("#SurveyQuickView").hide();

    var url ="api/getAllSiteReadyInstallation";
    let data={
        "site_ready_for_installation":"No"
    };
    var response = saveData(url, data); 
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");

        // $("#SurveyQuickView").show();

    // console.log("getall",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("value",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";

       if (value.site_survey_plandate == null || value.site_survey_plandate == "" || value.site_survey_plandate == undefined)
       {
 
              tbody += "<td></td>";
       }
       else
       {
            var date = value.site_survey_plandate;
            var start_date = date.split("-").reverse().join("-");
             tbody += "<td>" + start_date + "</td>";
       }
            tbody += "<td>" + value.site_survey_status + "</td>";


        if (value.site_survey_completeddate == null || value.site_survey_completeddate == "" || value.site_survey_completeddate == undefined)
        {
            tbody += "<td></td>";
        }
        else
        {
            var date1 = value.site_survey_completeddate;
            var end_date = date1.split("-").reverse().join("-");
            tbody += "<td>" + end_date + "</td>";
        }

      tbody += "<td>" + value.survey_reportsinoff + "</td>";
      tbody += "<td>" + value.report_upload_status + "</td>";
      tbody += "<td>" + value.site_ready_for_installation + "</td>";

      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";      
           tbody +='</tr>';
           i++;
    });
    $('#example').dataTable().fnClearTable();
    $('#example').dataTable().fnDraw();
    $('#example').dataTable().fnDestroy();
    $("#allsiteopen").html("");
    $("#allsiteopen").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}

function materialtransit(){
  var roleid = window.localStorage.getItem("roleid"); 

  var today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); 
  var yyyy = today.getFullYear();

  today = dd + "-" + mm + "-" + yyyy;
    //console.log("---->today", today);

  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMaterialStatus";
  let data = {
    "status":"Dispatched"
   };
  var response = saveData(url, data);
 // console.log("getall");
  response.then(function (returnData) {
    //console.log("getall",returnData);
    $('.ajax-loader').css("visibility", "hidden");

    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("value",value);

          var date1 = value.material_delivery_plan;

         if(date1 == null || date1 == "" || date1 == undefined)
         {
          var plan_date="";
         }
         else{
           plan_date = date1.split("-").reverse().join("-");
         }

        if(plan_date <= today  && (value.status == "Pending" || value.status == "Hold")){   
          var colorval = "#E21717";
        }

    tbody += "<tr><td style='color:"+colorval+";'>" + i + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.zone_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.circle_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.ssa_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.site_type + "</td>";


      var date1 = value.material_delivery_plan;

      if(date1 == null || date1 == "" || date1 == undefined)
      {
          tbody += "<td></td>";
      } 
      else 
      {
          var plann_date = date1.split("-").reverse().join("-");
          tbody += "<td style='color:"+colorval+";'>" + plann_date + "</td>";
      }

      var date2 = value.material_receiving_date;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
            var receiving_date = date2.split("-").reverse().join("-");
            tbody += "<td style='color:"+colorval+";'>" + receiving_date + "</td>";
      }
    tbody += "<td style='color:"+colorval+";'>" + value.material_receiving_by + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.signoff_bsnl + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.status + "</td>";
    var dispatch_newdate = value.material_dispatch_date;
      if(dispatch_newdate == null || dispatch_newdate == ""|| dispatch_newdate == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
            var dispatched_date = dispatch_newdate.split("-").reverse().join("-");
            tbody += "<td style='color:"+colorval+";'>" + dispatched_date + "</td>";
      }
    tbody += "<td style='color:"+colorval+";'>" + value.remarks + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.bsnl_remarks + "</td>";
      
           tbody +='</tr>';
           i++;
    });

    $('#materialexample').dataTable().fnClearTable();
    $('#materialexample').dataTable().fnDraw();
    $('#materialexample').dataTable().fnDestroy();
    $("#allmaterials").html("");
    $("#allmaterials").append(tbody);
    $("#materialexample").DataTable({ pagingType: "full_numbers" });
  });
}

function materialpartials(){
  var roleid = window.localStorage.getItem("roleid"); 

  var today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); 
  var yyyy = today.getFullYear();

  today = dd + "-" + mm + "-" + yyyy;
    //console.log("---->today", today);

  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMaterialStatus";
  let data = {
     "status":"Partial Delivery"
   };
  var response = saveData(url, data);
 // console.log("getall");
  response.then(function (returnData) {
   // console.log("getall",returnData);
    $('.ajax-loader').css("visibility", "hidden");

    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("value",value);

          var date1 = value.material_delivery_plan;

         if(date1 == null || date1 == "" || date1 == undefined)
         {
          var plan_date="";
         }
         else{
           plan_date = date1.split("-").reverse().join("-");
         }

        if(plan_date <= today  && (value.status == "Pending" || value.status == "Hold")){   
          var colorval = "#E21717";
        }

    tbody += "<tr><td style='color:"+colorval+";'>" + i + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.zone_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.circle_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.ssa_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.site_type + "</td>";


      var date1 = value.material_delivery_plan;

      if(date1 == null || date1 == "" || date1 == undefined)
      {
          tbody += "<td></td>";
      } 
      else 
      {
          var plann_date = date1.split("-").reverse().join("-");
          tbody += "<td style='color:"+colorval+";'>" + plann_date + "</td>";
      }

      var date2 = value.material_receiving_date;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
            var receiving_date = date2.split("-").reverse().join("-");
            tbody += "<td style='color:"+colorval+";'>" + receiving_date + "</td>";
      }
    tbody += "<td style='color:"+colorval+";'>" + value.material_receiving_by + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.signoff_bsnl + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.status + "</td>";
    var dispatch_newdate = value.material_dispatch_date;
      if(dispatch_newdate == null || dispatch_newdate == ""|| dispatch_newdate == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
            var dispatched_date = dispatch_newdate.split("-").reverse().join("-");
            tbody += "<td style='color:"+colorval+";'>" + dispatched_date + "</td>";
      }
    tbody += "<td style='color:"+colorval+";'>" + value.remarks + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.bsnl_remarks + "</td>";
      
           tbody +='</tr>';
           i++;
    });

    $('#materialexample').dataTable().fnClearTable();
    $('#materialexample').dataTable().fnDraw();
    $('#materialexample').dataTable().fnDestroy();
    $("#allmaterials").html("");
    $("#allmaterials").append(tbody);
    $("#materialexample").DataTable({ pagingType: "full_numbers" });
  });
}

function materialopenissuedata(){
  var roleid = window.localStorage.getItem("roleid"); 

  var today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); 
  var yyyy = today.getFullYear();

  today = dd + "-" + mm + "-" + yyyy;
    //console.log("---->today", today);

  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMaterialNotDelivererdStatus";
  let data = {
   };
  var response = saveData(url, data);
 // console.log("getall");
  response.then(function (returnData) {
   // console.log("getall",returnData);
    $('.ajax-loader').css("visibility", "hidden");

    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("value",value);

          var date1 = value.material_delivery_plan;

         if(date1 == null || date1 == "" || date1 == undefined)
         {
          var plan_date="";
         }
         else{
           plan_date = date1.split("-").reverse().join("-");
         }

        if(plan_date <= today  && (value.status == "Pending" || value.status == "Hold")){   
          var colorval = "#E21717";
        }

    tbody += "<tr><td style='color:"+colorval+";'>" + i + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.zone_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.circle_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.ssa_name + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.site_type + "</td>";


      var date1 = value.material_delivery_plan;

      if(date1 == null || date1 == "" || date1 == undefined)
      {
          tbody += "<td></td>";
      } 
      else 
      {
          var plann_date = date1.split("-").reverse().join("-");
          tbody += "<td style='color:"+colorval+";'>" + plann_date + "</td>";
      }

      var date2 = value.material_receiving_date;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
            var receiving_date = date2.split("-").reverse().join("-");
            tbody += "<td style='color:"+colorval+";'>" + receiving_date + "</td>";
      }
    tbody += "<td style='color:"+colorval+";'>" + value.material_receiving_by + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.signoff_bsnl + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.status + "</td>";
    var dispatch_newdate = value.material_dispatch_date;
      if(dispatch_newdate == null || dispatch_newdate == ""|| dispatch_newdate == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
            var dispatched_date = dispatch_newdate.split("-").reverse().join("-");
            tbody += "<td style='color:"+colorval+";'>" + dispatched_date + "</td>";
      }
    tbody += "<td style='color:"+colorval+";'>" + value.remarks + "</td>";
    tbody += "<td style='color:"+colorval+";'>" + value.bsnl_remarks + "</td>";
      
           tbody +='</tr>';
           i++;
    });

    $('#materialexample').dataTable().fnClearTable();
    $('#materialexample').dataTable().fnDraw();
    $('#materialexample').dataTable().fnDestroy();
    $("#allmaterials").html("");
    $("#allmaterials").append(tbody);
    $("#materialexample").DataTable({ pagingType: "full_numbers" });
  });
}


function installcommissionprogress(){
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllInstallationStatus";
  let data = {
      "installation_status":"In progress"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function installcommissionhold(){
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllInstallationStatus";
  let data = {
       "installation_status":"Hold"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function installopenissuedata(){
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllInstallationNotCompletedStatus";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}


function mplsreachdata(){ //console.log("mpls");
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMPLSreachabilityCompletedStatus";
  let data = {
      "MPLS_reachability":"Completed"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function mplsbngonedata(){ 
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMPLSreachabilityStatus";
  let data = {
        "MPLS_reachability":"Completed",
        "site_type":"BNG TYPE-I"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function mplsbngtwodata(){ 
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMPLSreachabilityStatus";
  let data = {
        "MPLS_reachability":"Completed",
        "site_type":"BNG TYPE-II"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function mplsuserplanedata(){ 
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMPLSreachabilityStatus";
  let data = {
        "MPLS_reachability":"Completed",
        "site_type":"User Plane"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function mplscontrolplanedata(){ 
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMPLSreachabilityStatus";
  let data = {
        "MPLS_reachability":"Completed",
        "site_type":"Control Plane"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });


    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function mplsrpopdata(){ 
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMPLSreachabilityStatus";
  let data = {
        "MPLS_reachability":"Completed",
        "site_type":"RPOP"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function mplsupsdata(){ 
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllMPLSreachabilityStatus";
  let data = {
        "MPLS_reachability":"Completed",
        "site_type":"UPS"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}


function mplsopenissuedata()
{ 
    $('.ajax-loader').css("visibility", "visible");
   var url = "api/getAllMPLSreachabilityCompletedStatus";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function commissionuserdata(){   console.log("getcomissionuser");
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllCommissioningStatus";
  let data = {
         "comminssioning_status":"Completed",
         "site_type":"User Plane"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getcomissionuser",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}


function commissioncontroldata(){  
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllCommissioningStatus";
  let data = {
    "comminssioning_status":"Completed",
    "site_type":"Control Plane"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function commissionbngonedata(){  
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllCommissioningStatus";
  let data = {
    "comminssioning_status":"Completed",
    "site_type":" BNG TYPE-I"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}
function commissionbngtwodata(){  
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllCommissioningStatus";
  let data = {
    "comminssioning_status":"Completed",
    "site_type":"BNG TYPE-II"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function commissionrpopdata(){  
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllCommissioningStatus";
  let data = {
     "comminssioning_status":"Completed",
     "site_type":"RPOP"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function commissionupsdata(){  
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllCommissioningStatus";
  let data = {
    "comminssioning_status":"Completed",
    "site_type":"UPS"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}


function commissionopenissuedata(){  
    $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllCommissioningNotCompletedStatus";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    //console.log("getall",returnData);
   $('.ajax-loader').css("visibility", "hidden");
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var date1 = value.installation_plandate;
      if(date1 == null || date1 == ""|| date1 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var plandate = date1.split("-").reverse().join("-");
        tbody += "<td>" + plandate + "</td>";
      }

      tbody += "<td>" + value.installation_status + "</td>";

      var date2 = value.installation_completeddate;
      if(date2 == null || date2 == ""|| date2 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
        var instcompleteddate = date2.split("-").reverse().join("-");
        tbody += "<td>" + instcompleteddate + "</td>";
      }

      tbody += "<td>" + value.comminssioning_status + "</td>";

      var date3 = value.comminssioning_date;
      if(date3 == null || date3 == ""|| date3 == undefined)
      {
        tbody += "<td></td>";
      }
      else
      {
      var commisioncompleteddate = date3.split("-").reverse().join("-");   
      tbody += "<td>" + commisioncompleteddate + "</td>";
      }
      tbody += "<td>" + value.MPLS_reachability + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';

           i++;
    });

    $('#installexample').dataTable().fnClearTable();
    $('#installexample').dataTable().fnDraw();
    $('#installexample').dataTable().fnDestroy();
    $("#allinstallprogress").html("");
    $("#allinstallprogress").append(tbody);
    $("#installexample").DataTable({ pagingType: "full_numbers" });
  });
}

function acceptanceuserdata(){
  $('.ajax-loader').css("visibility", "visible");
 //console.log("getall");
  var url = "api/getAllAcceptanceStatus";
  let data = {
      "acceptance_issued":"Yes",
      "site_type":"User Plane"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var newvdate1 = value.at_plandate;
      if(newvdate1 == "" || newvdate1 == null || newvdate1 == undefined)
      {
       var newplandate = "<td></td>";
      }
      else
      {
         newplandate = newvdate1.split("-").reverse().join("-");
         tbody += "<td>" + newplandate + "</td>";
      }

      tbody += "<td>" + value.pre_at_status + "</td>";

      var newvdate2 = value.pre_at_completiondate;
      if(newvdate2 == "" || newvdate2 == null || newvdate2 == undefined)
      {
       var preatcompdt = "<td></td>";
      }
      else
      {
         preatcompdt = newvdate2.split("-").reverse().join("-");
         tbody += "<td>" + preatcompdt + "</td>";
      }


      tbody += "<td>" + value.final_at_status + "</td>";

      var newvdate3 = value.final_at_completiondate;
      if(newvdate3 == "" || newvdate3 == null || newvdate3 == undefined)
      {
       var finalatcompdt = "<td></td>";
      }
      else
      {
       finalatcompdt = newvdate3.split("-").reverse().join("-");
      tbody += "<td>" + finalatcompdt + "</td>";
      }

      tbody += "<td>" + value.acceptance_certificate_issued + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';
           i++;
    });

    $('#acceptanceexample').dataTable().fnClearTable();
    $('#acceptanceexample').dataTable().fnDraw();
    $('#acceptanceexample').dataTable().fnDestroy();
    $("#allacceptancedata").html("");
    $("#allacceptancedata").append(tbody);
    $("#acceptanceexample").DataTable({ pagingType: "full_numbers" });
  });
}

function acceptancecontroldata(){
  $('.ajax-loader').css("visibility", "visible");
 //console.log("getall");
  var url = "api/getAllAcceptanceStatus";
  let data = {
      "acceptance_issued":"Yes",
      "site_type":"Control Plane"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var newvdate1 = value.at_plandate;
      if(newvdate1 == "" || newvdate1 == null || newvdate1 == undefined)
      {
       var newplandate = "<td></td>";
      }
      else
      {
         newplandate = newvdate1.split("-").reverse().join("-");
         tbody += "<td>" + newplandate + "</td>";
      }

      tbody += "<td>" + value.pre_at_status + "</td>";

      var newvdate2 = value.pre_at_completiondate;
      if(newvdate2 == "" || newvdate2 == null || newvdate2 == undefined)
      {
       var preatcompdt = "<td></td>";
      }
      else
      {
         preatcompdt = newvdate2.split("-").reverse().join("-");
         tbody += "<td>" + preatcompdt + "</td>";
      }


      tbody += "<td>" + value.final_at_status + "</td>";

      var newvdate3 = value.final_at_completiondate;
      if(newvdate3 == "" || newvdate3 == null || newvdate3 == undefined)
      {
       var finalatcompdt = "<td></td>";
      }
      else
      {
       finalatcompdt = newvdate3.split("-").reverse().join("-");
      tbody += "<td>" + finalatcompdt + "</td>";
      }

      tbody += "<td>" + value.acceptance_certificate_issued + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';
           i++;
    });

    $('#acceptanceexample').dataTable().fnClearTable();
    $('#acceptanceexample').dataTable().fnDraw();
    $('#acceptanceexample').dataTable().fnDestroy();
    $("#allacceptancedata").html("");
    $("#allacceptancedata").append(tbody);
    $("#acceptanceexample").DataTable({ pagingType: "full_numbers" });
  });
}

function acceptancebngonedata(){
  $('.ajax-loader').css("visibility", "visible");
 //console.log("getall");
  var url = "api/getAllAcceptanceStatus";
  let data = {
      "acceptance_issued":"Yes",
      "site_type":"BNG TYPE-I"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var newvdate1 = value.at_plandate;
      if(newvdate1 == "" || newvdate1 == null || newvdate1 == undefined)
      {
       var newplandate = "<td></td>";
      }
      else
      {
         newplandate = newvdate1.split("-").reverse().join("-");
         tbody += "<td>" + newplandate + "</td>";
      }

      tbody += "<td>" + value.pre_at_status + "</td>";

      var newvdate2 = value.pre_at_completiondate;
      if(newvdate2 == "" || newvdate2 == null || newvdate2 == undefined)
      {
       var preatcompdt = "<td></td>";
      }
      else
      {
         preatcompdt = newvdate2.split("-").reverse().join("-");
         tbody += "<td>" + preatcompdt + "</td>";
      }


      tbody += "<td>" + value.final_at_status + "</td>";

      var newvdate3 = value.final_at_completiondate;
      if(newvdate3 == "" || newvdate3 == null || newvdate3 == undefined)
      {
       var finalatcompdt = "<td></td>";
      }
      else
      {
       finalatcompdt = newvdate3.split("-").reverse().join("-");
      tbody += "<td>" + finalatcompdt + "</td>";
      }

      tbody += "<td>" + value.acceptance_certificate_issued + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';
           i++;
    });

    $('#acceptanceexample').dataTable().fnClearTable();
    $('#acceptanceexample').dataTable().fnDraw();
    $('#acceptanceexample').dataTable().fnDestroy();
    $("#allacceptancedata").html("");
    $("#allacceptancedata").append(tbody);
    $("#acceptanceexample").DataTable({ pagingType: "full_numbers" });
  });
}

function acceptancebngtwodata(){
  $('.ajax-loader').css("visibility", "visible");
 //console.log("getall");
  var url = "api/getAllAcceptanceStatus";
  let data = {
      "acceptance_issued":"Yes",
      "site_type":"BNG TYPE-II"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var newvdate1 = value.at_plandate;
      if(newvdate1 == "" || newvdate1 == null || newvdate1 == undefined)
      {
       var newplandate = "<td></td>";
      }
      else
      {
         newplandate = newvdate1.split("-").reverse().join("-");
         tbody += "<td>" + newplandate + "</td>";
      }

      tbody += "<td>" + value.pre_at_status + "</td>";

      var newvdate2 = value.pre_at_completiondate;
      if(newvdate2 == "" || newvdate2 == null || newvdate2 == undefined)
      {
       var preatcompdt = "<td></td>";
      }
      else
      {
         preatcompdt = newvdate2.split("-").reverse().join("-");
         tbody += "<td>" + preatcompdt + "</td>";
      }


      tbody += "<td>" + value.final_at_status + "</td>";

      var newvdate3 = value.final_at_completiondate;
      if(newvdate3 == "" || newvdate3 == null || newvdate3 == undefined)
      {
       var finalatcompdt = "<td></td>";
      }
      else
      {
       finalatcompdt = newvdate3.split("-").reverse().join("-");
      tbody += "<td>" + finalatcompdt + "</td>";
      }

      tbody += "<td>" + value.acceptance_certificate_issued + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';
           i++;
    });

    $('#acceptanceexample').dataTable().fnClearTable();
    $('#acceptanceexample').dataTable().fnDraw();
    $('#acceptanceexample').dataTable().fnDestroy();
    $("#allacceptancedata").html("");
    $("#allacceptancedata").append(tbody);
    $("#acceptanceexample").DataTable({ pagingType: "full_numbers" });
  });
}

function acceptancerpopdata(){
  $('.ajax-loader').css("visibility", "visible");
 //console.log("getall");
  var url = "api/getAllAcceptanceStatus";
  let data = {
      "acceptance_issued":"Yes",
      "site_type":"RPOP"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var newvdate1 = value.at_plandate;
      if(newvdate1 == "" || newvdate1 == null || newvdate1 == undefined)
      {
       var newplandate = "<td></td>";
      }
      else
      {
         newplandate = newvdate1.split("-").reverse().join("-");
         tbody += "<td>" + newplandate + "</td>";
      }

      tbody += "<td>" + value.pre_at_status + "</td>";

      var newvdate2 = value.pre_at_completiondate;
      if(newvdate2 == "" || newvdate2 == null || newvdate2 == undefined)
      {
       var preatcompdt = "<td></td>";
      }
      else
      {
         preatcompdt = newvdate2.split("-").reverse().join("-");
         tbody += "<td>" + preatcompdt + "</td>";
      }


      tbody += "<td>" + value.final_at_status + "</td>";

      var newvdate3 = value.final_at_completiondate;
      if(newvdate3 == "" || newvdate3 == null || newvdate3 == undefined)
      {
       var finalatcompdt = "<td></td>";
      }
      else
      {
       finalatcompdt = newvdate3.split("-").reverse().join("-");
      tbody += "<td>" + finalatcompdt + "</td>";
      }

      tbody += "<td>" + value.acceptance_certificate_issued + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';
           i++;
    });

    $('#acceptanceexample').dataTable().fnClearTable();
    $('#acceptanceexample').dataTable().fnDraw();
    $('#acceptanceexample').dataTable().fnDestroy();    
    $("#allacceptancedata").html("");
    $("#allacceptancedata").append(tbody);
    $("#acceptanceexample").DataTable({ pagingType: "full_numbers" });
  });
}

function acceptanceupsdata(){
  $('.ajax-loader').css("visibility", "visible");
 //console.log("getall");
  var url = "api/getAllAcceptanceStatus";
  let data = {
        "acceptance_issued":"Yes",
        "site_type":"UPS"
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var newvdate1 = value.at_plandate;
      if(newvdate1 == "" || newvdate1 == null || newvdate1 == undefined)
      {
       var newplandate = "<td></td>";
      }
      else
      {
         newplandate = newvdate1.split("-").reverse().join("-");
         tbody += "<td>" + newplandate + "</td>";
      }

      tbody += "<td>" + value.pre_at_status + "</td>";

      var newvdate2 = value.pre_at_completiondate;
      if(newvdate2 == "" || newvdate2 == null || newvdate2 == undefined)
      {
       var preatcompdt = "<td></td>";
      }
      else
      {
         preatcompdt = newvdate2.split("-").reverse().join("-");
         tbody += "<td>" + preatcompdt + "</td>";
      }


      tbody += "<td>" + value.final_at_status + "</td>";

      var newvdate3 = value.final_at_completiondate;
      if(newvdate3 == "" || newvdate3 == null || newvdate3 == undefined)
      {
       var finalatcompdt = "<td></td>";
      }
      else
      {
       finalatcompdt = newvdate3.split("-").reverse().join("-");
      tbody += "<td>" + finalatcompdt + "</td>";
      }

      tbody += "<td>" + value.acceptance_certificate_issued + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';
           i++;
    });

    $('#acceptanceexample').dataTable().fnClearTable();
    $('#acceptanceexample').dataTable().fnDraw();
    $('#acceptanceexample').dataTable().fnDestroy();
    $("#allacceptancedata").html("");
    $("#allacceptancedata").append(tbody);
    $("#acceptanceexample").DataTable({ pagingType: "full_numbers" });
  });
}

function acceptanceopenissuedata(){
  $('.ajax-loader').css("visibility", "visible");
 //console.log("getall");
  var url = "api/getAllAcceptanceFinalAtStatus";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("getallvalue",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_name + "</td>";

      var newvdate1 = value.at_plandate;
      if(newvdate1 == "" || newvdate1 == null || newvdate1 == undefined)
      {
       var newplandate = "<td></td>";
      }
      else
      {
         newplandate = newvdate1.split("-").reverse().join("-");
         tbody += "<td>" + newplandate + "</td>";
      }

      tbody += "<td>" + value.pre_at_status + "</td>";

      var newvdate2 = value.pre_at_completiondate;
      if(newvdate2 == "" || newvdate2 == null || newvdate2 == undefined)
      {
       var preatcompdt = "<td></td>";
      }
      else
      {
         preatcompdt = newvdate2.split("-").reverse().join("-");
         tbody += "<td>" + preatcompdt + "</td>";
      }


      tbody += "<td>" + value.final_at_status + "</td>";

      var newvdate3 = value.final_at_completiondate;
      if(newvdate3 == "" || newvdate3 == null || newvdate3 == undefined)
      {
       var finalatcompdt = "<td></td>";
      }
      else
      {
       finalatcompdt = newvdate3.split("-").reverse().join("-");
      tbody += "<td>" + finalatcompdt + "</td>";
      }

      tbody += "<td>" + value.acceptance_certificate_issued + "</td>";
      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

           tbody +='</tr>';
           i++;
    });

    $('#acceptanceexample').dataTable().fnClearTable();
    $('#acceptanceexample').dataTable().fnDraw();
    $('#acceptanceexample').dataTable().fnDestroy();
    $("#allacceptancedata").html("");
    $("#allacceptancedata").append(tbody);
    $("#acceptanceexample").DataTable({ pagingType: "full_numbers" });
  });
// pirchat 
function renderChartData() {
    $('.ajax-loader').css("visibility", "visible");

    var url = "api/getAllAcceptanceStatus";
    let data = {
        "acceptance_issued": "Yes",
        "site_type": "RPOP"
    };

    var response = saveData(url, data);
    response.then(function (returnData) {
        $('.ajax-loader').css("visibility", "hidden");

        // Assuming returnData.data contains the necessary chart data
        var chartData = returnData.data;

        // Process the dynamic data and render the chart
        updatePieChart('chartCanvas1', chartData, 'Acceptance Chart');

        // Additional processing if needed
    });
}

// Example function to update or create a pie chart
function updatePieChart(canvasId, chartData, chartTitle) {
    var combinedData = {
        datasets: [
            {
                data: chartData.map(item => item.value),
                backgroundColor: ['green', 'yellow', 'orange'],
                label: chartTitle
            }
        ],
        labels: chartData.map(item => item.label)
    };

    var ctx = document.getElementById(canvasId);
    if (window[canvasId]) {
        // Update existing chart if it exists
        window[canvasId].data = combinedData;
        window[canvasId].options.title.text = chartTitle;
        window[canvasId].update();
    } else {
        // Create a new pie chart
        window[canvasId] = new Chart(ctx, {
            type: 'pie',
            data: combinedData,
            options: {
                title: {
                    display: true,
                    text: chartTitle
                }
            }
        });
    }
}
    
}
