function getallrolesdata()
{
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getRoleName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnrolesData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#roles").html("");
        $("#roles").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#roles").append(
          '<option value="' + val.role_id + '">' + val.name + "</option>"
          );
        });
      });
}

function getalluserdata() {  
  $('.ajax-loader').css("visibility", "visible");
     //console.log("getall");
  var url = "api/getAllUsers";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    // console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      console.log("value",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.fullname + "</td>";
      tbody += "<td>" + value.email + "</td>";
      tbody += "<td>" + value.mobile + "</td>";

      tbody +=
        '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
        value.user_id +
        "," +
        value.is_active +
        ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp ';
        if(value.is_active  == 1){ 
           tbody += '<a onclick="activateDeactivateData(' +value.user_id +');" style="cursor:pointer;background-color: #027e61;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
          } else { 
           tbody += '<a onclick="activateDeactivateData(' +value.user_id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' }
           '</td></tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}


function save_submit() { 
  var fullname = $("#full_name").val();
  var email = $("#email").val();
  var mobileno = $("#mobile_no").val();
  var roles = $("#roles").val();
  var username = $("#username").val();
  var password = $("#password").val();
  var userid = $("#userid").val();


    if (fullname == null || fullname == "" || fullname == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Full Name..",
    });
    return false;
  }
  else if (email == null || email == "" || email == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Email Id..",
    });
    return false;
  }
    else if (mobileno == null || mobileno == "" || mobileno == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Mobile Number..",
    });
    return false;
  }
      else if (roles == null || roles == "" || roles == undefined || roles == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Roles..",
    });
    return false;
  }
      else if (username == null || username == "" || username == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter User Name..",
    });
    return false;
  }
      else if (password == null || password == "" || password == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Password..",
    });
    return false;
  }
  else 
  {
    if (userid == "") 
    {  //console.log("save");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesUsers";
      var myJsonString = 
      {
        "fullname":fullname,
        "username":username,
        "mobile":mobileno,
        "email":email,
        "ref_role_id":roles,
        "password":password   
      };

      //console.log("myJsonString",myJsonString);
      var response = saveData(url, myJsonString);
    // console.log(response,"response");
      response.then(function (data) {       //console.log(data,"data");
    $('.ajax-loader').css("visibility", "hidden");

        if (data.status == true) {
            $("#full_name").val();
            $("#email").val();
            $("#mobile_no").val();
            $("#roles").val();
            $("#username").val();
            $("#password").val();

          swal({
            type: "success",
            title: "Great...",
            text: "User Details has been Saved Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          }).then((result) => {
          $("#username").val("");
          });
        }
      });
    } //end if of submit
    else if (userid !== "") { //console.log("update");
      $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesUsers";
      var myJsonString = 
      {
        "user_id":userid,
        "fullname":fullname,
        "username":username,
        "mobile":mobileno,
        "email":email,
        "ref_role_id":roles,
        "password":password     
      };

     // console.log("myJsonString",myJsonString);
      var response = saveData(url, myJsonString);
      response.then(function (data) {           // console.log("data",data);
          $('.ajax-loader').css("visibility", "hidden");
        if (data.status == true) {
            $("#userid").val("");
            $("#full_name").val();
            $("#email").val();
            $("#mobile_no").val();
            $("#roles").val();
            $("#username").val();
            $("#password").val();      
           swal({
            type: "success",
            title: "Great...",
            text: "User Details has been updated Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: "Data Updation failed!",
          });
        }
      });
    } else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went Wrong..!",
      });
    }
  }
}

function editpopulate(id, isActive) {
  if (isActive == 0) {  //console.log("isn't active");
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else {    //console.log(id);
    $("#circle_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");

    var url = "api/getUserById";
    var myJsonString = 
      {
         "user_id": id    
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) { 
     // console.log("editdata",returnData);
      $('.ajax-loader').css("visibility", "hidden");

      $("#full_name").val(returnData.data.fullname);   
      $("#email").val(returnData.data.email);
      $("#mobile_no").val(returnData.data.mobile);
      $("#username").val(returnData.data.username);
      $("#roles").val(returnData.data.ref_role_id).trigger("change");
      $("#password").val(returnData.data.password);
      $("#userid").val(returnData.data.user_id);
    });
  }
}

function clearpge(){
  $("#roles option:first").prop("selected","true").trigger("change");
  $("#full_name").val("");
  $("#email").val("");
  $("#mobile_no").val("");
  $("#roles").val("");
  $("#username").val("");
  $("#password").val(""); 
}

function activateDeactivateData(id) { // console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Enable / Disable this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/deletedUsersById";
      var myJsonString = {
        "user_id":id,
      }
       var response = saveData(url, myJsonString);
       
      response.then(function (data) { //console.log("data",data);
     $('.ajax-loader').css("visibility", "hidden");
        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}