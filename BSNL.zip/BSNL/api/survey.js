function getcircledata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getCircles";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#circle_name").html("");
        $("#circle_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#circle_name").append(
          '<option value="' + val.circle_id + '">' + val.circle_name + "</option>"
          );
        });
      });
}


function getssadata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSites";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#ssa_name").html("");
        $("#ssa_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#ssa_name").append(
          '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
          );
        });
      });
}

function getallSiteTypedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSiteTypes";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").html("");
        $("#site_type").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#site_type").append(
          '<option value="' + val.site_type_id + '">' + val.site_type + "</option>"
          );
        });
      });
}

function getallData(){
  $('.ajax-loader').css("visibility", "visible");
  var ssaId = $("#ssa_name").val();
    var url = "api/getIdFromSsaName";
    let data = {
      "ssa_id":ssaId
      };
    var response = saveData(url, data);
      response.then(function (returnData) {    // console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").val(returnData.data.ref_site_type_id).trigger("change");
        $("#zone_name").val(returnData.data.ref_zone_id).trigger("change");
        $("#circle_name").val(returnData.data.ref_circle_id).trigger("change");

        $("#site_type").prop("disabled", true);  
         $("#zone_name").prop("disabled", true); 
          $("#circle_name").prop("disabled", true); 
      });
}

function getallzonedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getZoneName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnzoneData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#zone_name").html("");
        $("#zone_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#zone_name").append(
          '<option value="' + val.zone_id + '">' + val.zone_name + "</option>"
          );
        });
      });
}


function clearpge(){  
  $("#zone_name option:first").prop("selected", true).trigger("change");
  $("#circle_name option:first").prop("selected", true).trigger("change");
  $("#ssa_name option:first").prop("selected", true).trigger("change");
  $("#site_type option:first").prop("selected", true).trigger("change");
  $("#address").val("");
  $("#start_date").val("");
  $("#site_status option:first").prop("selected", true).trigger("change");
  $("#end_date").val("");
  $("#survey_rep option:first").prop("selected", true).trigger("change");
  $("#rep_status option:first").prop("selected", true).trigger("change");
  $("#install_status option:first").prop("selected", true).trigger("change");
  $("#files").val("");
  $("#remarks").val("");
  $("#surveyid").val("");

  $("#files").removeAttr("val");
  $("#blahs").removeAttr("src");
  $("#blahs").removeAttr("width");
  $("#blahs").removeAttr("height");  
}

function getallsurveydata() {   
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllSurvey";
  let data = {
   };
  var response = saveData(url, data);
 // console.log("getall");
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");

    // console.log("getall",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      //console.log("value",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";

       if (value.site_survey_plandate == null || value.site_survey_plandate == "" || value.site_survey_plandate == undefined)
       {
 
              tbody += "<td></td>";
       }
       else
       {
            var date = value.site_survey_plandate;
            var start_date = date.split("-").reverse().join("-");
             tbody += "<td>" + start_date + "</td>";
       }
            tbody += "<td>" + value.site_survey_status + "</td>";


        if (value.site_survey_completeddate == null || value.site_survey_completeddate == "" || value.site_survey_completeddate == undefined)
        {
            tbody += "<td></td>";
        }
        else
        {
            var date1 = value.site_survey_completeddate;
            var end_date = date1.split("-").reverse().join("-");
            tbody += "<td>" + end_date + "</td>";
        }

      tbody += "<td>" + value.survey_reportsinoff + "</td>";
      tbody += "<td>" + value.report_upload_status + "</td>";
      tbody += "<td>" + value.site_ready_for_installation + "</td>";

      tbody += "<td>" + value.remarks + "</td>";
      tbody += "<td>" + value.bsnl_remarks + "</td>";

      if(value.survey_document_path  == ""){
        tbody += "<td></td>";
       }else{
        tbody += '<td><a href="' +value.survey_document_path + '" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Download" target="_blank">Download</a> &nbsp</td>';
      }
      if(roleid == '1'){
        tbody += '<td><a onclick="enterBsnlRemarks(' +value.survey_id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-placement="top" title="View" data-toggle="modal" data-target="#productsQuickView"  title="Enter Remarks">Remarks</a></td>'; 
      }else{
        tbody +=
        '<td style="width:400px;"><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
        value.survey_id +
        "," +
        value.is_active +
        ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp <a data-toggle="tooltip" title="Delete" name="delete" id="delete" style="cursor:pointer; padding-left:5px;" onclick="activateDeactivateData(' +value.survey_id +');"><i class="ti-trash" style="size:100%; color: #FF0000! important;"></i></a> &nbsp ';
      }
      
           tbody +='</tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}
var survayid;
function enterBsnlRemarks(id){
  survayid = id;
}

function submitRemarks(){
  var bsnlremarks     =   $("#bsnlremarks").val();

  if(bsnlremarks == ""){
      swal({
          title: 'info',
          text: 'Please enter Remarks',
          timer: 2000
      });
      return;
  }else{

  $('.ajax-loader').css("visibility", "visible");
  var myJsonString = {
    "bsnl_remarks":bsnlremarks,
    "survey_id":survayid
  }
  var url  = "api/updateSurveyStatus"
  var response = saveData(url, myJsonString);
  response.then(function (data) {
      $('.ajax-loader').css("visibility", "hidden");
      if(data.status == true){
        $('#productsQuickView').modal('hide');
        swal({
          type: "success",
          title: "Great...",
          text: "Remarks Submited Successfully ...!",
          allowOutsideClick: false,
          confirmButtonText: "OK",
        }).then((result) => {
          location.reload();
        });
      }else{
          swal({
              text: data.message,
              timer: 2000
          });
      }
      
  });
  }
}

function save_submit() { 
  var ssa_name = $("#ssa_name").val();
  var site_type = $("#site_type").val();
  var zone_name = $("#zone_name").val();
  var circle_name = $("#circle_name").val();
  var start_date = $("#start_date").val();
  var site_status = $("#site_status").val();
  var end_date = $("#end_date").val();
  var survey_rep = $("#survey_rep").val();
  var rep_status = $("#rep_status").val();
  var install_status = $("#install_status").val();
  var remarks = $("#remarks").val();
  var surveyid = $("#surveyid").val();

    if(start_date == "" || start_date == null || start_date == undefined){
       var newstart_date = "";
    }
    else{
       newstart_date = start_date.split("-").reverse().join("-");
    }

   if(end_date == "" || end_date == null || end_date == undefined){
       var newenddate = "";
    }
    else{
       newenddate = end_date.split("-").reverse().join("-");
    }



  if (ssa_name == null || ssa_name == "" || ssa_name == undefined || ssa_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select SSA..",
    });
    return false;
  } 
    else if (start_date == null || start_date == "" || start_date == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Survey Planned Date..",
    });
    return false;
  }
    else if (site_status == null || site_status == "" || site_status == undefined || site_status == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Site Survey Status..",
    });
    return false;
  } 
    else if (end_date == null || end_date == "" || end_date == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Survey Completed Date..",
    });
    return false;
  }
     else if (survey_rep == null || survey_rep == "" || survey_rep == undefined || survey_rep == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Survey Report Signoff..",
    });
    return false;
  } 
     else if (rep_status == null || rep_status == "" || rep_status == undefined || rep_status == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Report Upload Status..",
    });
    return false;
  } 
    else if (install_status == null || install_status == "" || install_status == undefined || install_status == "-- Please Select --") {
        swal({
          type: "error",
          title: "Oops...",
          text: "Please Select Site Ready for Installation..",
        });
        return false;
      } 
  else 
  {
          var formData = new FormData();
          var uploadFile = document.getElementById("files");
         // console.log("uploadFile",uploadFile.files[0]);
          formData.append("survey_document_path", uploadFile.files[0]);

          
    if (surveyid == "") 
    {  
      if(install_status == "No")
      {
       if(remarks == "" || remarks == undefined || remarks == null)
        {
        swal({
          type: "error",
          title: "Oops...",
          text: "Please Enter Remarks..",
        });
        return false;
        }
        else{
           $('.ajax-loader').css("visibility", "visible");
          var url = "api/saveUpdatesSurvey";
          formData.append("ref_ssa_id", ssa_name);
          formData.append("site_survey_plandate", newstart_date);
          formData.append("site_survey_status", site_status);
          formData.append("site_survey_completeddate", newenddate);
          formData.append("survey_reportsinoff", survey_rep);
          formData.append("report_upload_status", rep_status);
          formData.append("remarks", remarks);
          formData.append("site_ready_for_installation", install_status);

        	var response = saveFormData(url, formData); 

      response.then(function (data) {   // console.log("resdata",data);
    $('.ajax-loader').css("visibility", "hidden");

        if (data.status == true) {
          $("#ssa_name").val("");  
          $("#site_type").val("");
          $("#zone_name").val("");
          $("#circle_name").val("");
          $("#start_date").val("");  
          $("#site_status").val("");
          $("#end_date").val("");
          $("#survey_rep").val("");  
          $("#rep_status").val("");
          $("#remarks").val("");
          $("#install_status").val("");

          swal({
            type: "success",
            title: "Great...",
            text: "Survey Details has been Saved Successfully!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
        }
      }
    else
    {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesSurvey";
     formData.append("ref_ssa_id", ssa_name);
     formData.append("site_survey_plandate", newstart_date);
     formData.append("site_survey_status", site_status);
     formData.append("site_survey_completeddate", newenddate);
     formData.append("survey_reportsinoff", survey_rep);
     formData.append("report_upload_status", rep_status);
     formData.append("remarks", remarks);
     formData.append("site_ready_for_installation", install_status);


    	var response = saveFormData(url, formData); 

      response.then(function (data) {   // console.log("resdata",data);
    $('.ajax-loader').css("visibility", "hidden");

        if (data.status == true) {
          $("#ssa_name").val("");  
          $("#site_type").val("");
          $("#zone_name").val("");
          $("#circle_name").val("");
          $("#start_date").val("");  
          $("#site_status").val("");
          $("#end_date").val("");
          $("#survey_rep").val("");  
          $("#rep_status").val("");
          $("#remarks").val("");
          $("#install_status").val("");

          swal({
            type: "success",
            title: "Great...",
            text: "Survey Details has been Saved Successfully!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
    } 
  }//end if of submit
    else if (surveyid !== "") { 
      if(install_status == "No")
      {
       if(remarks == "" || remarks == undefined || remarks == null)
        {
        swal({
          type: "error",
          title: "Oops...",
          text: "Please Enter Remarks..",
        });
        return false;
        }
        else{
         $('.ajax-loader').css("visibility", "visible");

          var url = "api/saveUpdatesSurvey";

        formData.append("survey_id", surveyid);
        formData.append("ref_ssa_id", ssa_name);
        formData.append("site_survey_plandate", newstart_date);
        formData.append("site_survey_status", site_status);
        formData.append("site_survey_completeddate", newenddate);
        formData.append("survey_reportsinoff", survey_rep);
        formData.append("report_upload_status", rep_status);
        formData.append("remarks", remarks);
        formData.append("site_ready_for_installation", install_status);

          var response = saveFormData(url, formData); 
          response.then(function (data) {  //console.log("updtdata",data);
              $('.ajax-loader').css("visibility", "hidden");

            if (data.status == true) {
              $("#surveyid").val("");
              $("#ssa_name").val("");  
              $("#site_type").val("");
              $("#zone_name").val("");
              $("#circle_name").val("");
              $("#start_date").val("");  
              $("#site_status").val("");
              $("#end_date").val("");
              $("#survey_rep").val("");  
              $("#rep_status").val("");
              $("#remarks").val("");  
              $("#install_status").val("");

              swal({
                type: "success",
                title: "Great...",
                text: "Survey Details has been updated Successfully!",
                allowOutsideClick: false,
                confirmButtonText: "OK",
              }).then((result) => {
                location.reload();
              });
            } else {
              swal({
                type: "error",
                title: "Oops...",
                text: data.message,
              });
            }
          });
            }
        }
       else
       { 
        $('.ajax-loader').css("visibility", "visible");

      var url = "api/saveUpdatesSurvey";

     formData.append("survey_id", surveyid);
     formData.append("ref_ssa_id", ssa_name);
     formData.append("site_survey_plandate", newstart_date);
     formData.append("site_survey_status", site_status);
     formData.append("site_survey_completeddate", newenddate);
     formData.append("survey_reportsinoff", survey_rep);
     formData.append("report_upload_status", rep_status);
     formData.append("remarks", remarks);
     formData.append("site_ready_for_installation", install_status);


    	var response = saveFormData(url, formData); 
      response.then(function (data) {  //console.log("updtdata",data);
          $('.ajax-loader').css("visibility", "hidden");

        if (data.status == true) {
          $("#surveyid").val("");
          $("#ssa_name").val("");  
          $("#site_type").val("");
          $("#zone_name").val("");
          $("#circle_name").val("");
          $("#start_date").val("");  
          $("#site_status").val("");
          $("#end_date").val("");
          $("#survey_rep").val("");  
          $("#rep_status").val("");
          $("#remarks").val("");  
          $("#install_status").val("");

           swal({
            type: "success",
            title: "Great...",
            text: "Survey Details has been updated Successfully!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          });
        }
      });
    }
   } else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went wrong!",
      });
    }
  }
}

function editpopulate(id, isActive) {
  if (isActive == 0) {  //console.log("id",id);
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else { //console.log("is active");
    $("#survey_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");

    var url = "api/getIdBySurvey";
    var myJsonString = 
      {
          "survey_id":id
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) { 
      //console.log("editdata",returnData);
     $('.ajax-loader').css("visibility", "hidden");
          $("#surveyid").val(returnData.data.survey_id);
          $("#ssa_name").val(returnData.data.ref_ssa_id).trigger('change');
          $("#site_type").val(returnData.data.site_type).trigger('change'); 
          $("#zone_name").val(returnData.data.ref_zone_id).trigger('change');
          $("#circle_name").val(returnData.data.ref_circle_id).trigger('change');

          var newplandt = returnData.data.site_survey_plandate;
          if(newplandt == "" || newplandt == null || newplandt == undefined)
          {
           var newplandate ="";
          }
          else
          {
           newplandate = newplandt.split("-").reverse().join("-");
          }

          var newcompdt = returnData.data.site_survey_completeddate;
          if(newcompdt == "" || newcompdt == null || newcompdt == undefined)
          {
              var newcompdate ="";
          }
          else
          {
           newcompdate = newcompdt.split("-").reverse().join("-");
          }
          
          $("#start_date").val(newplandate);  
          $("#site_status").val(returnData.data.site_survey_status).trigger('change');
          $("#end_date").val(newcompdate);
          $("#survey_rep").val(returnData.data.survey_reportsinoff).trigger('change');
          $("#rep_status").val(returnData.data.report_upload_status).trigger('change');
          $("#install_status").val(returnData.data.site_ready_for_installation).trigger('change');
          $("#remarks").val(returnData.data.remarks); 

          $("#files").attr("val",returnData.data.survey_document_path);
          $("#blahs").attr("src",returnData.data.survey_document_path);
          $("#blahs").attr("width","100px");
          $("#blahs").attr("height","100px");
          
          $("#site_type").prop("disabled", true);  
         $("#zone_name").prop("disabled", true); 
          $("#circle_name").prop("disabled", true); 
    });
  }
}

function activateDeactivateData(id) { // console.log("deleteid",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Delete this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");

      var url = "api/deleteSurveyById";
      var myJsonString = {
          "survey_id":id
      }
       var response = saveData(url, myJsonString);
       
      response.then(function (data) { //console.log("data",data);
     $('.ajax-loader').css("visibility", "hidden");

        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}