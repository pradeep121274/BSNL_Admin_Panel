function getallzonedata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getZoneName";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnzoneData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#zone_name").html("");
        $("#zone_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#zone_name").append(
          '<option value="' + val.zone_id + '">' + val.zone_name + "</option>"
          );
        });
      });
}
function getcircledata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getCircles";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#circle_name").html("");
        $("#circle_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#circle_name").append(
          '<option value="' + val.circle_id + '">' + val.circle_name + "</option>"
          );
        });
      });
}

function getsitetypes(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getSiteTypes";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) {     //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#site_type").html("");
        $("#site_type").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#site_type").append(
          '<option value="' + val.site_type_id + '">' + val.site_type + "</option>"
          );
        });
      });
}

function getallssadata() {  
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllSites";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    //console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {      console.log("value",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.zone_name + "</td>";
      tbody += "<td>" + value.circle_name + "</td>";
      tbody += "<td>" + value.site_type + "</td>";
      tbody += "<td>" + value.ssa_name + "</td>";

      tbody +=
        '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
        value.ssa_id +
        "," +
        value.is_active +
        ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp ';
        if(value.is_active  == 1){ 
           tbody += '<a onclick="activateDeactivateData(' +value.ssa_id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
          } else { 
           tbody += '<a onclick="activateDeactivateData(' +value.ssa_id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' }
           '</td></tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}


function save_submit() { 
  var zone_name = $("#zone_name").val();
  var circle_name = $("#circle_name").val();
  var site_type = $("#site_type").val();
  var ssa_name = $("#ssa_name").val();
  var site_address = $("#site_address").val();
  var ssa_id = $("#ssa_id").val();


  if (zone_name == null || zone_name == "" || zone_name == undefined || zone_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Zone Name..",
    });
    return false;
  }
  else if (circle_name == null || circle_name == "" || circle_name == undefined || circle_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Circle Name..",
    });
    return false;
  }
    
  else if (site_type == null || site_type == "" || site_type == undefined || site_type == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Site Type..",
    });
    return false;
  }

  else if (ssa_name == null || ssa_name == "" || ssa_name == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter SSA Name..",
    });
    return false;
  }

  else 
  {
    if (ssa_id == "") 
    {
  $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesSites";
      var myJsonString = 
      {
        "ssa_name":ssa_name,
        "ref_zone_id":zone_name,
        "ref_circle_id":circle_name,
        "ref_site_type_id":site_type,
        "site_address":site_address
      };

      console.log(myJsonString,"myJsonString");

      var response = saveData(url, myJsonString);
     console.log(response,"response");
      response.then(function (data) {      
        console.log(data,"data");
        $('.ajax-loader').css("visibility", "hidden");
        if (data.status == true) {
          $("#zone_name").val("");
          $("#circle_name").val("");
          $("#ssa_name").val("");
          $("#site_type").val("");
          $("#site_address").val("");
          swal({
            type: "success",
            title: "Great...",
            text: "SSA Details has been Saved Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          }).then((result) => {
          $("#ssa_name").val("");
          });
        }
      });
    } //end if of submit
    else if (ssa_id !== "") {  
        $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesSites";
      var myJsonString = 
      {
        "ssa_id":ssa_id,
        "ssa_name":ssa_name,
        "ref_zone_id":zone_name,
        "ref_circle_id":circle_name,
        "ref_site_type_id":site_type,
        "site_address":site_address 
        };
      var response = saveData(url, myJsonString);
      response.then(function (data) {           // console.log("dataUPDATE",data);
        $('.ajax-loader').css("visibility", "hidden"); 
      if (data.status == true) {
          $("#ssa_id").val("");
          $("#zone_name").val("");
          $("#circle_name").val("");
          $("#ssa_name").val("");
          $("#site_type").val("");
          $("#site_address").val(""); 
           swal({
            type: "success",
            title: "Great...",
            text: "SSA Details has been updated Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: "Data Updation failed!",
          });
        }
      });
    } else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went wrong!",
      });
    }
  }
}

function editpopulate(id, isActive) {
  if (isActive == 0) {  //console.log("isn't active");
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else {            
    //console.log("is active");
    $("#ssa_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getIdBySite";
    var myJsonString = 
      {
         "ssa_id":id  
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) {             
    $('.ajax-loader').css("visibility", "hidden"); 
    $("#zone_name").val(returnData.data.ref_zone_id).trigger("change");
    $("#circle_name").val(returnData.data.ref_circle_id).trigger("change");
    $("#site_type").val(returnData.data.ref_site_type_id).trigger("change");
    $("#ssa_name").val(returnData.data.ssa_name);
    $("#site_address").val(returnData.data.site_address);
    $("#ssa_id").val(returnData.data.ssa_id);
    });
  }
}

function clearpge(){
  $("#zone_name option:first").prop("selected","true").trigger("change");
  $("#circle_name option:first").prop("selected","true").trigger("change");
  $("#site_type option:first").prop("selected","true").trigger("change");
  $("#ssa_name").val("");
  $("#site_address").val("");
  $("#ssa_id").val("");
}

function activateDeactivateData(id) {  //console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Enable / Disable this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/deleteSiteById";
      var myJsonString = {
        "ssa_id":id,
      }
       var response = saveData(url, myJsonString);
      // console.log("response",response);
      response.then(function (data) { //console.log("data",data);
      $('.ajax-loader').css("visibility", "hidden"); 
        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}