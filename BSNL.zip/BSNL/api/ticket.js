

function getallempdata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getAllEmpDepartmentData";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnzoneData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#emp_name").html("");
        $("#emp_name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#emp_name").append(
          '<option value="' + val.id + '">' + val.emp_name + "</option>"
          );
        });
      });
}
function getprioritiesdata(){
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getAllPrioritiesData";
    let data = {
      "is_active":1
      };
    var response = saveData(url, data);
      response.then(function (returnData) { //console.log("returnData",returnData);
    $('.ajax-loader').css("visibility", "hidden");
        $("#name").html("");
        $("#name").append("<option>-- Please Select --</option>");
          $.each(returnData.data,function(key,val){
         $("#name").append(
          '<option value="' + val.priority_id + '">' + val.name + "</option>"
          );
        });
      });
}


function getSitetypes() {
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllticketStatusData";
  let data = {
      "is_active": 1
  };

  var response = saveData(url, data);

  response.then(function (returnData) {
      $('.ajax-loader').css("visibility", "hidden");
      $("#site_type").html("");
      $("#site_type").append("<option>-- Please Select --</option>");

      $.each(returnData.data, function (key, val) {
          $("#site_type").append(
              '<option value="' + val.status_id + '">' + val.name + "</option>"
          );
      });
  });
}
function getssatypes(){
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllSsaNameAdd";
  let data = {
    "is_active":1
    };
  var response = saveData(url, data);
    response.then(function (returnData) { //console.log("returnzoneData",returnData);
  $('.ajax-loader').css("visibility", "hidden");
      $("#ssa_name").html("");
      $("#ssa_name").append("<option>-- Please Select --</option>");
        $.each(returnData.data,function(key,val){
       $("#ssa_name").append(
        '<option value="' + val.ssa_id + '">' + val.ssa_name + "</option>"
        );
      });
    });
}
// save data in db 
// function saveDataBasedOnSelectedOption() {
//   var selectedEmpId = $("#emp_name").val();
//   var selectedPriorityId = $("#name").val();
//   var selectedSiteTypeId = $("#site_type").val(); // Uncomment this line if you want to use "site_type"

//   // Use these selected IDs for saving data
//   console.log("Selected Employee ID: ", selectedEmpId);
//   console.log("Selected Priority ID: ", selectedPriorityId);
//   console.log("Selected Site Type ID: ", selectedSiteTypeId);
// }

function getallssadata() {  
  $('.ajax-loader').css("visibility", "visible");
  var url = "api/getAllTickets";
  let data = {
   };
  var response = saveData(url, data);
  response.then(function (returnData) {
    $('.ajax-loader').css("visibility", "hidden");
    CKEDITOR.instances['description'].setData(returnData.data.description);
    //var privacypolicy = CKEDITOR.instances.description.getData();
    $("#ticket_id").val(returnData.data.ticket_id);
    //console.log("return",returnData);
    var tbody = "";
    var i = 1;
    $.each(returnData.data, function (key, value) {     // console.log("value",value);

      tbody += "<tr><td>" + i + "</td>";
      tbody += "<td>" + value.ticket_name + "</td>";
      tbody += "<td>" + value.description + "</td>";
      tbody += "<td>" + value.priority + "</td>";
      tbody += "<td>" + value.status + "</td>";
      tbody += "<td>" + value.emp_name + "</td>";
      tbody += "<td>" + value.start_date + "</td>";
      tbody += "<td>" + value.due_date + "</td>"; 
      tbody += "<td>" + value.ssa_name + "</td>";
      tbody += "<td>" + value.site_address + "</td>";
      tbody +=
        '<td><a data-toggle="tooltip" title="Edit" name="equestion" id="questioneditsub1" style="cursor:pointer; padding-left:5px;" onClick="javascript:editpopulate(' +
        value.ticket_id +
        "," +
        value.is_active +
        ')"><i class="ti-pencil-alt" style="size:100%; color:#FFC400! important;"></i></a> &nbsp ';
        if(value.is_active  == 1){ 
           tbody += '<a onclick="activateDeactivateData(' +value.ticket_id +');" style="cursor:pointer;background-color: #102e56;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Enable</a>'; 
          } else { 
           tbody += '<a onclick="activateDeactivateData(' +value.ticket_id +');" style="cursor:pointer;background-color: #e1d6d6;color:#fff;padding: 5px;border-radius: 5px;" data-toggle="tooltip" data-placement="top" title="Enable">Disable</a>' }
           '</td></tr>';
           i++;
    });

    $("#allusers").html("");
    $("#allusers").append(tbody);
    $("#example").DataTable({ pagingType: "full_numbers" });
  });
}

function save_submit() { 
  var ticket_name = $("#ticket_name").val();
  var privacypolicy = CKEDITOR.instances.description.getData();
  var name = $("#name").val();
  var emp_name = $("#emp_name").val();
    var name = $("#name").val();
    var start_date = $("#start_date").val();
    var due_date = $("#due_date").val();
  var ssa_name = $("#ssa_name").val();
  var ticket_id = $("#ticket_id").val();
  if(start_date == "" || start_date == null || start_date == undefined){
    var newstart_date = "";
 }
 else{
    newstart_date = start_date.split("-").reverse().join("-");
 }

if(due_date == "" || due_date == null || due_date == undefined){
    var newduedate = "";
 }
 else{
    newduedate = due_date.split("-").reverse().join("-");
 }


  if (emp_name == null || emp_name == "" || emp_name == undefined || emp_name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Employee Name..",
    });
    return false;
  }
  else if (name == null || name == "" || name == undefined || name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Priority Name..",
    });
    return false;
  }
    
  else if (name == null || name == "" || name == undefined || name == "-- Please Select --") {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Select Status..",
    });
    return false;
  }

  else if (description == null || description == "" || description == undefined) {
    swal({
      type: "error",
      title: "Oops...",
      text: "Please Enter Description..!",
    });
    return false;
  }

  else 
  {
    if (ticket_id == "") 
    {
  $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesTicket";
      var myJsonString = 
      {
        "ticket_name":ticket_name,  
        "description":privacypolicy, 
        "ref_status_id":name,
        "ref_ssa_id":ssa_name,
        "ref_department_id":emp_name,
        "ref_priority_id":name,
        "start_date":newstart_date,
        "due_date":newduedate,
      };
      

    //  console.log(myJsonString,"myJsonString");

      var response = saveData(url, myJsonString);
     console.log(response,"response");
      response.then(function (data) {      
        console.log(data,"data");
        $('.ajax-loader').css("visibility", "hidden");
        if (data.status == true) {
          $("#ticket_name").val("");
          $("#description").val("");
          $("#name").val("");
          $("#ssa_name").val("");
          $("#emp_name").val("");
          $("#name").val("");
          swal({
            type: "success",
            title: "Great...",
            text: "Ticket Details has been Saved Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: data.message,
          }).then((result) => {
          $("#ssa_name").val("");
          });
        }
      });
    } //end if of submit
    else if (ticket_id !== "") {  
        $('.ajax-loader').css("visibility", "visible");
      var url = "api/saveUpdatesTicket";
      var myJsonString = 
      {
        "ticket_name":ticket_name,  
        "description":privacypolicy, 
        "ref_status_id":name,
        "ref_ssa_id":ssa_name,
        "ref_department_id":emp_name,
        "ref_priority_id":name,
        "start_date":newstart_date,
        "due_date":newduedate,
        };
      var response = saveData(url, myJsonString);
      response.then(function (data) {           // console.log("dataUPDATE",data);
        $('.ajax-loader').css("visibility", "hidden"); 
      if (data.status == true) {
        $("#ticket_name").val("");
        $("#description").val("");
        $("#name").val(""); 
        $("#ssa_name").val("");
        $("#emp_name").val("");
        $("#name").val(""); 
           swal({
            type: "success",
            title: "Great...",
            text: "Ticket Details has been updated Successfully....!",
            allowOutsideClick: false,
            confirmButtonText: "OK",
          }).then((result) => {
            location.reload();
          });
        } else {
          swal({
            type: "error",
            title: "Oops...",
            text: "Data Updation failed!",
          });
        }
      });
    } else {
      swal({
        type: "error",
        title: "Oops...",
        text: "Something went wrong!",
      });
    }
  }
}

function editpopulate(id, isActive) {
  if (isActive == 0) {  //console.log("isn't active");
    swal({
      text: "You are not allowed to edit. Data has been disabled."
        });
  } else {            
    //console.log("is active");
    $("#ssa_submit").val("Update");
    $("#clearpage").hide("");
    $("#pincodename").show("");
    $("#listhide").hide("");
    $('.ajax-loader').css("visibility", "visible");
    var url = "api/getTicketById";
    var myJsonString = 
      {
         "ticket_id":id  
      };
      var response = saveData(url, myJsonString);
    response.then(function (returnData) {             
    $('.ajax-loader').css("visibility", "hidden"); 
    $("#emp_name").val(returnData.data.ref_department_id).trigger("change");
    $("#ticket_name").val(returnData.data.ticket_name).trigger("change");
    $("#name").val(returnData.data.ref_status_id).trigger("change");
    $("#name").val(returnData.data.ref_priority_id).trigger("change");
    $("#ssa_name").val(returnData.data.ref_ssa_id);
    $("#site_address").val(returnData.data.site_address);
    $("#ticket_id").val(returnData.data.ticket_id);
    });
  }
}

function clearpge(){
  $("#name option:first").prop("selected","true").trigger("change");
  $("#emp_name option:first").prop("selected","true").trigger("change");
  $("#name option:first").prop("selected","true").trigger("change");
  $("#ssa_name option:first").prop("selected","true").trigger("change");
  $("#ticket_name").val("");
  $("#description").val("");
  // $("#ticket_id").val("");
}

function activateDeactivateData(id) {  //console.log("id",id);
  swal({   
    title: "Are you sure?",
    text: "Do you want to Enable / Disable this Record..?",
    type: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  }).then((result) => {
    if (result.value) {
    $('.ajax-loader').css("visibility", "visible");
      var url = "api/deletedTicketDataById";
      var myJsonString = {
        "ticket_id":id,
      }
       var response = saveData(url, myJsonString);
      // console.log("response",response);
      response.then(function (data) { //console.log("data",data);
      $('.ajax-loader').css("visibility", "hidden"); 
        swal({
          title: "Done..!",
          text: data.message,
        }).then((result) => {
              location.reload();
            });;
      });
    }
  });
}