 //var baseUrl = "https://arthainfosystems.com/bsnl-survey-sites-testing/server.php/";
//var baseUrl = "https://arthainfosystems.com/bsnl-survey-sites-testing/server.php/";

  
function saveData(path, postData) {
  var apiVal = localStorage.getItem("apiVal");
  if(apiVal)
  {
    if(apiVal==1)
    {
      var baseUrl = "https://localhost/GitBSNLWebApi/BSNLApi/BSNLApiPhaseOne/server.php/";
    }
    else if(apiVal==2)
    {
      var baseUrl = "https://localhost/GitBSNLWebApi/BSNLApi/BSNLApiPhaseTwo/server.php/";
    }else if(apiVal==3)
    {
      var baseUrl = "https://localhost/GitBSNLWebApi/BSNLApi/BSNLApiPhaseThree/server.php/";
    }
  }
  
var urlPath = baseUrl + path;
return $.ajax({
  url: urlPath,
  dataType: "json",
  data: JSON.stringify(postData),
  type: "post",
  crossDomain: true,
  contentType: "application/json",
});
}

function getAllData(path) {
var urlPath = baseUrl + path;
return $.ajax({
  url: urlPath,
  dataType: "json",
  type: "get",
});
}

function editData(path) {
var urlPath = baseUrl + path;
return $.ajax({
  url: urlPath,
  dataType: "json",
  type: "get",
});
}
function deleteData(path) {
var urlPath = baseUrl + path;
return $.ajax({
  url: urlPath,
  dataType: "json",
  type: "get",
});
}
function saveFormData(path, postData) {
  var apiVal = localStorage.getItem("apiVal");
  if(apiVal)
  {
    if(apiVal==1)
    {
      var baseUrl = "https://localhost/GitBSNLWebApi/BSNLApi/BSNLApiPhaseOne/server.php/";
    }
    else if(apiVal==2)
    {
      var baseUrl = "https://localhost/GitBSNLWebApi/BSNLApi/BSNLApiPhaseTwo/server.php/";
    }else if(apiVal==3)
    {
      var baseUrl = "https://localhost/GitBSNLWebApi/BSNLApi/BSNLApiPhaseThree/server.php/";
    }
  }
var urlPath = baseUrl + path;
return $.ajax({
  url: urlPath,
  type: "post",
  data: postData,
  enctype: "multipart/form-data",
  processData: false,
  contentType: false,
  cache: false,
});
}
