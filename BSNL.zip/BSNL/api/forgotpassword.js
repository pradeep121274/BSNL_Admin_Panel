
function forgotPassword(baseurl){
    
    base = baseurl;

    var emailid = $("#email").val();
    console.log(emailid);
   
 
    if (emailid == "") {
        alert("Please Enter Email Id");
    }
    else{
        var url = "staff/forgotpassword";
        var jsonstring = {
            "email": emailid
        }
        console.log(jsonstring);
        var response = saveData(url,jsonstring);
        response.then(function(data){
            console.log(data);
              if(data.success == true){
                 swal({
              type: "success",
              title: "Great...",
              text: data.message,
              allowOutsideClick: false,
              confirmButtonText: "OK",
            }).then(function () {
                    window.location=baseurl+"index.php/Home/index"; 
                });           
            }else{
                swal({
                    "type": "error",
                    "text": data.message,
                    "allowOutsideClick": false
                });
            } 
        });   
    }
}