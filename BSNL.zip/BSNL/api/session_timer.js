var base;
var idleTime;
function session_timer(baseurl){
 base = baseurl;
var counter = 60;
idleTime = 0;
var idleInterval;

    idleInterval = setInterval(timerIncrement,15*60000);

$(window).click(function(){
    idleTime = 0;   
    counter = 60;
    clearInterval(idleInterval);
    idleInterval = setInterval(timerIncrement,15*60000);
});

$(window).keyup(function(){
    idleTime = 0;    
    counter = 60;  
    clearInterval(idleInterval);
    idleInterval = setInterval(timerIncrement,15*60000);
});


$(window).mousemove(function(){
    idleTime = 0;                    
    counter = 60;  
    clearInterval(idleInterval);
    idleInterval = setInterval(timerIncrement,15*60000);
});


}

function timerIncrement(){ 
    idleTime = idleTime + 1;
    if(idleTime >= 1){
    let sessid = sessionStorage.getItem("id");     //Storing the id of user in SESSION variable.
        sessionStorage.clear();
        let userid = localStorage.getItem("userid"); 
        localStorage.clear();
   window.location = base + "index.php";
    }
}