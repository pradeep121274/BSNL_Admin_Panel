<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
<link type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
<div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-10">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-6">
                                <div class="welcome-content">
                                    <div class="brand-logo">
                                        <a href="<?php echo base_url();?>Home/signup">Artha</a>
                                    </div>
                                    <h3 class="welcome-title">Welcome to Artha</h3>
                                    <div class="intro-social">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4 txtcolor">Sign up your account</h4>
                                    <form action="<?php echo base_url();?>">
                                        <div class="form-row ">
                                            <div class="form-group col-md-12">
                                                <label><strong class="txtcolor">Name</strong></label>
                                                <input type="text" class="form-control" placeholder="Name">
                                            </div>
                                            
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label><strong class="txtcolor">Email Id</strong></label>
                                                <input type="email" class="form-control" placeholder="hello@example.com">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label><strong class="txtcolor">Phone Number</strong></label>
                                                <input type="email" class="form-control" placeholder="XXXX XXX XXX">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label><strong class="txtcolor">Password</strong></label>
                                                <input type="password" class="form-control" value="Password">
                                            </div>
                                        </div>
                                        <div class="text-center mt-4">
                                            <button type="submit" class="btn btn-primary btn-block">Sign me up</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p>Already have an account? <a class="text-primary" href="<?php echo base_url();?>">Sign in</a></p>
                                    </div>    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>