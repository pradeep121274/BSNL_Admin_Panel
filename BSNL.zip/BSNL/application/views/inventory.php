<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style>
  .box {
	float: left;
	padding: 50px 0px;
}

.clearfix::after {
	clear: both;
	display: table;
}

.options {
	margin: 5px 0px 0px 0px;
	float: left;
}

.pagination {
	float: right;
}

.pagination a {
	color: black;
	float: left;
	padding: 8px 16px;
	text-decoration: none;
	transition: background-color .3s;
	border: 1px solid #ddd;
	margin: 0 4px;
}

.pagination a.activepage {
	background-color: #4CAF50;
	color: white;
	border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {
	background-color: #ddd;
}
.file {
  visibility: hidden;
  position: absolute;
}

@media screen and (max-width: 480px){

a {
  font-size: 8px;
}
.btn{
  font-size: 9px;
}
}
</style>
<script src="<?php echo base_url(); ?>api/inventory.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>
 <!--**********************************
            Content body start
        ***********************************-->
        <div class="ajax-loader">
            <img src="<?php echo base_url(); ?>assets/images/loader.gif" class="img-responsive" />
        </div>
        <div class="content-bodys">
            <div class="container-fluid" style="padding-top:0px;">
            <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="breadcrumb-range-picker">
                            <span><i class="icon-calender"></i></span>
                            <span class="ml-1">Home</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Inventory Management List</a></li>
                        </ol>
                    </div>
                </div>
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card" id="pincodename">
                            <div class="card-header">
                                <h4 class="card-title">Inventory Form</h4>
                                <button type="submit" class="btn btn-primary" id="listview"> Back to list
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Add"><i
                                            class="fa fa-undo color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label>SSA*</label>
                                            <select id="ssa_name" name="ssa_name"  class="form-control select2" required onChange="getallData();"></select> 
                                        </div>
                                        <div class="form-group col-md-6">
                                        <label>Type Of Site*</label>
                                        <select id="site_type" class="form-control select2" required></select>
                                        </div>
                                    </div>

                                            <div class="form-row">
                                            <div class="col-md-12">
                                            <table id="POITable"  style="width: 100%; border=0;">
                                            <input type="hidden" name="inventoryid" id="inventoryid" />
                                                <tr>
                                                <td style="padding-right: 10px;">
                                                    <div class="form-group">
                                                        <label>Inventory Name*</label>
                                                        <select id="inventory" name="inventory" class="form-control select2" required>
                                                        </select>
                                                    </div>
                                                </td>
                                                <td style="padding-right: 10px;">
                                                    <div class="form-group">
                                                    <label>Qty*</label>
                                                    <input type="text" class="form-control" id="quantity" name="quantity" placeholder="Enter Quantity" value="" maxlength="10" onblur="qty_validation()">
                                                    </div>
                                                </td>
                                                <td style="padding-right: 10px;">
                                                    <div class="form-group">
                                                    <label>Serial Number*</label>
                                                    <input type="text" class="form-control" id="serial_number" name="serial_number" placeholder="Enter Serial Number" value="" maxlength="10" onblur="serialnm_validation()">
                                                    </div>
                                                </td>
                                                <td style="width:200px;padding-top: 5px;">
                                                    <!-- <input type="button" id="delPOIbutton" value="Delete" onclick="deleteRow(this)" style="color: #fff;background-color: #de0909;padding: 5px;border-radius: 10px;" /> -->
                                                    <input type="button" id="addmorePOIbutton" value="Add More" onclick="insRow()" style="color: #fff;background-color: #3c2ce4;padding: 5px;border-radius: 10px;" />
                                                </td>
                                                </tr>
                                            </table>
                                            </div>
                                        </div>

                                         <input type="submit" id="inventory_submit" name="inventory_submit" value="Submit" class="btn btn-primary"/>  
                                        <input type="hidden" name="inventory_management_id" id="inventory_management_id" />
                                       <input type="reset" id="clearpage" name="Reset" class="btn btn-secondary" value="Clear">                              
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <!--**********************************
            Content body end
        ***********************************-->

  <!-- Start QuickView Remarks Modal Area -->
     <div class="modal fade productsQuickView" id="productsQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label style="font-size: 16px;font-weight: 600;">Remarks</label>
                            <textarea style="padding: 5px;" rows="5" cols="70" id="bsnlremarks" placeholder="Enter Remarks(if any)"></textarea>
                        </div>                                         
                    </div> 
                    <div class="form-row">
                        <input type="submit" id="remarks_submit" name="remarks_submit" value="Submit" class="btn btn-primary" onclick="submitRemarks();"/> 
                    </div> 
                </div>
            </div>
        </div>

        <!-- End QuickView Remarks Modal Area -->
                    
        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body" style="padding-top: 0rem !important;">
            <div class="container-fluid">
               
                <!-- row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card" id="listhide">
                            <div class="card-header">
                                <h4 class="card-title">Inventory Management List</h4>
                                <button type="submit" class="btn btn-primary"  id="txtshow"> Create Inventory
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Create Inventory"><i
                                            class="fa fa-plus-circle color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border : 1;">
                                        <thead>
                                        <tr>
                                        <th>Sl No</th>
                                        <th>SSA Name</th>
                                        <th>Bsnl Remarks</th>
                                        <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="allusers">
                                        </tbody> 
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function(){
        var userid = window.localStorage.getItem("userid");
        if(userid == "" || userid == null || userid == undefined)
        {
            window.location="<?php echo base_url();?>"; 
        } 
        else {
            $('.select2').select2();
            $("#pincodename").hide("");
            $("#sub_form").hide(""); 
              getallssadata();
              getallSiteTypedata();
              getallInventoryName();
              getallinventorydata();
        }
        });


        $("#txtshow").click(function () {        
                $("#pincodename").show("");         
                $("#listhide").hide(""); 
        });

        $("#listview").click(function () {  
            location.reload();       
        });


 function qty_validation(){
     var  mx = 1;  
        var my = 20;      
        var quantity =$("#quantity").val();
        var len = quantity.length;
        var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;

        if (quantity  != "") 
		{
      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Quantity Name should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("quantity").value = "";
    }
           else if(!Checkregex.test(quantity)){
		            swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("quantity").value = "";
		           }else{
                       return true;
                   }
	          });				 
    }
     }
   }

 function serialnm_validation(){
     var  mx = 3;  
        var my = 10;      
        var serial_number =$("#serial_number").val();
        var len = serial_number.length;
        var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;
    if (serial_number  != "") 
		{
      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Serial Number should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("serial_number").value = "";
    }
    else {

				if (!Checkregex.test(serial_number))
				{
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("serial_number").value = "";
		           }else{
                       return true;
                   }
	          });				
        	}
		
    }
    }
 }

 function insRow() {
    var x = document.getElementById('POITable');
    var len = x.rows.length;
    var id = len;
    var html = '';
        html += '<tr>\n\
                    <td style="padding-right: 10px;">\n\
                        <div class="form-group">\n\
                            <label>Inventory Name*</label>\n\
                            <input type="hidden" name="inventoryid'+id+'" id="inventoryid'+id+'" />\n\
                            <select id="inventory'+id+'" name="inventory" class="form-control select2" required>\n\
                            </select>\n\
                        </div>\n\
                    </td>\n\
                    <td style="padding-right: 10px;">\n\
                        <div class="form-group">\n\
                        <label>Qty*</label>\n\
                        <input type="text" class="form-control" id="quantity'+id+'" name="quantity" placeholder="Enter Quantity" value="" maxlength="10" onblur="qty_validation()">\n\
                        </div>\n\
                    </td>\n\
                    <td style="padding-right: 10px;">\n\
                        <div class="form-group">\n\
                        <label>Serial Number*</label>\n\
                        <input type="text" class="form-control" id="serial_number'+id+'" name="serial_number" placeholder="Enter Serial Number" value="" maxlength="10" onblur="serialnm_validation()">\n\
                        </div>\n\
                    </td>\n\
                    <td style="width:200px;padding-top: 5px;">\n\
                        <input type="button" id="delPOIbutton" value="Delete" onclick="deleteRow(this)" style="color: #fff;background-color: #de0909;padding: 5px;border-radius: 10px;" />\n\
                        <input type="button" id="addmorePOIbutton" value="Add More" onclick="insRow()" style="color: #fff;background-color: #3c2ce4;padding: 5px;border-radius: 10px;" />\n\
                    </td>\n\
                </tr>';

        $('#POITable').append(html);
        getDynamicAllInventoryData(id);
}
function deleteRow(row) {
    var i = row.parentNode.parentNode.rowIndex;
    document.getElementById('POITable').deleteRow(i);
}

 $("#clearpage").click(function(){ 
		 clearpge();
});	

$("#inventory_submit").click(function(){  
    save_submit();
		  });

    var roleid = window.localStorage.getItem("roleid"); 
    if(roleid=="1"){
        $("#txtshow").hide();
     }  
</script>