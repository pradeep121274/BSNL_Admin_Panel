<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style>
    .box {
        float: left;
        padding: 50px 0px;
    }

    .clearfix::after {
        clear: both;
        display: table;
    }

    .options {
        margin: 5px 0px 0px 0px;
        float: left;
    }

    .pagination {
        float: right;
    }

    .pagination a {
        color: black;
        float: left;
        padding: 8px 16px;
        text-decoration: none;
        transition: background-color .3s;
        border: 1px solid #ddd;
        margin: 0 4px;
    }

    .pagination a.activepage {
        background-color: #4CAF50;
        color: white;
        border: 1px solid #4CAF50;
    }

    .pagination a:hover:not(.active) {
        background-color: #ddd;
    }

    .file {
        visibility: hidden;
        position: absolute;
    }

    @media screen and (max-width: 480px) {

        a {
            font-size: 8px;
        }

        .btn {
            font-size: 9px;
        }
    }
</style>
<script src="<?php echo base_url(); ?>api/material.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>
<!--**********************************
            Content body start
        ***********************************-->
<div class="ajax-loader">
    <img src="<?php echo base_url(); ?>assets/images/loader.gif" class="img-responsive" />
</div>
<div class="content-bodys">
    <div class="container-fluid" style="padding-top:0px;">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="breadcrumb-range-picker">
                    <span><i class="icon-calender"></i></span>
                    <span class="ml-1">Home</span>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Material Delivery List</a></li>
                </ol>
            </div>
        </div>

        <!-- row -->
        <div class="row">
            <div class="col-12">
                <div class="card" id="listhide">
                    <div class="card-header">
                        <h4 class="card-title">Material Delivery List</h4>
                        <button type="submit" class="btn btn-primary" id="txtshow"> Create Material
                            <span>
                                <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Create Material"><i class="fa fa-plus-circle color-muted addclr"></i> </a>
                            </span>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border : 1;">
                                <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Zone</th>
                                        <th>Circle</th>
                                        <th>SSA</th>
                                        <th>Site Type</th>
                                        <th>Material Delivery Plan Date</th>
                                        <th>Material Receiving date</th>
                                        <th>Material Received by</th>
                                        <th>BC/DC Sign off By BSNL</th>
                                        <th>Status</th>
                                        <th>Material Dispatched Date</th>
                                        <th>Remarks</th>
                                        <th>Bsnl Remarks</th>
                                        <th class="action" id="actions">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="allusers">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--**********************************
            Content body end
        ***********************************-->

   <!-- Start QuickView Remarks Modal Area -->
     <div class="modal fade productsQuickView" id="productsQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label style="font-size: 16px;font-weight: 600;">Remarks</label>
                            <textarea rows="5" cols="70" id="bsnlremarks" placeholder="Enter Remarks(if any)" style="padding: 5px;"></textarea>
                        </div>                                         
                    </div> 
                    <div class="form-row">
                        <input type="submit" id="remarks_submit" name="remarks_submit" value="Submit" class="btn btn-primary" onclick="submitRemarks();"/> 
                    </div> 
                </div>
            </div>
        </div>

        <!-- End QuickView Remarks Modal Area -->



<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body" style="padding-top: 0rem !important;">
    <div class="container-fluid">

        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card" id="pincodename">
                    <div class="card-header">
                        <h4 class="card-title">Material Form</h4>
                        <button type="submit" class="btn btn-primary" id="listview"> Back to list
                            <span>
                                <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Add"><i class="fa fa-undo color-muted addclr"></i> </a>
                            </span>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="basic-form">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>SSA*</label>
                                       <select id="ssa_name" name="ssa_name"  class="form-control select2" required onChange="getallData();"></select> 
                                </div>
                                <div class="form-group col-md-6">
                                     <label>Site Type*</label>
                                      <select id="site_type" class="form-control select2" required></select>
                                </div>
                            </div>

                            <div class="form-row">
                                 <div class="form-group col-md-6">
                                    <label>Zone*</label>
                                        <select id="zone_name" name="zone_name" class="form-control select2" required></select> 
                                 </div>
                                <div class="form-group col-md-6">
                                    <label>Circle*</label>
                                        <select id="circle_name" name="circle_name"  class="form-control select2" required></select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Material Delivery Plan Date*</label>
                                    <input type="text" id="mdate" name="mdate"  class="form-control border-input" placeholder="Select Date" autocomplete="off" required>
                                </div>
                                     <div class="form-group col-md-6">
                                    <label>Material Received By</label>
                                    <input type="text" class="form-control" id="received_by" name="received_by" placeholder="Enter Material Received By" value="" onblur="receivedby_validate()" maxlength="30" required>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Material Receiving Date</label>
                                      <input type="text" id="ddate" name="ddate"  class="form-control  border-input" placeholder="Select Date" autocomplete="off" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>BC/DC Sign Off By BSNL</label>
                                    <select class="form-control select2" id="sign_off">
                                         <option>-- Please Select --</option>
                                        <option value='YES'>Yes</option>
                                        <option value='NO'>No</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                   <div class="form-group col-md-6">
                                    <label>Status*</label>
                                         <select id="status" class="form-control select2" required>
                                            <option>-- Please Select --</option>
                                            <option value='Pending'>Pending</option>
                                            <option value='Dispatched'>Dispatched</option>
                                            <option value='Delivered'>Delivered</option>
                                            <option value='Partial Delivery'>Partial Delivery</option>
                                        </select>                              
                                 </div>
                                <div class="form-group col-md-6">
                                    <label>Material Dispatched Date</label>
                                      <input type="text" id="dispatchdate" name="dispatchdate"  class="form-control border-input" placeholder="Select Date" autocomplete="off" required>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Remarks</label>
                                    <textarea rows="5" cols="170" id="remarks" onblur="remarks_validate()" placeholder="Enter Remarks(if any)" required></textarea>
                                </div>
                            </div>
                        </div>

                        <input type="submit" id="material_submit" name="material_submit" value="Submit" class="btn btn-primary" />
                        <input type="hidden" name="materialid" id="materialid" />
                        <input type="reset" id="clearpage" name="Reset" class="btn btn-secondary" value="Clear">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!--**********************************
            Content body end
        ***********************************-->

<script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        var userid = window.localStorage.getItem("userid");
        if (userid == "" || userid == null || userid == undefined) {
            window.location = "<?php echo base_url(); ?>";
        } else {
            $("#pincodename").hide("");
            $('.select2').select2();
            getcircledata();
            getssadata();
            getallzonedata();
            getallmaterialdata();
            getallSiteTypedata();
        }
    });


    $("#txtshow").click(function() {
        $("#pincodename").show("");
        $("#listhide").hide("");
    });

    $("#listview").click(function() {
        location.reload();
    });


function siteaddress_validate()
{ 
         var  mx = 3;  //minlength
         var my = 2000;
         var address = $("#address").val(); 
         var len = address.length;
          if(len < mx ||len >my){
      swal({
							type: 'warning',
							title: 'Oops...',
							text: 'Address should be between ' +mx+ ' and ' +my+ ' Characters,digits or Special Characters',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						});
			document.getElementById("address").value = "";
 }
}

function remarks_validate()
{ 
         var  mx = 3;  //minlength
         var my = 2000;
         var remarks = $("#remarks").val(); 
         var len = remarks.length;
          if(len < mx ||len >my){
      swal({
							type: 'warning',
							title: 'Oops...',
							text: 'Remarks should be between ' +mx+ ' and ' +my+ ' Characters,digits or Special Characters',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						});
			document.getElementById("remarks").value = "";
 }
}


 function receivedby_validate(){ 
         var  mx = 3;  //minlength
         var my = 30;
         var received_by = $("#received_by").val(); 
         var len = received_by.length;
          if(len < mx ||len >my){
      swal({
							type: 'warning',
							title: 'Oops...',
							text: 'Material Received By should be between ' +mx+ ' and ' +my+ ' Characters,digits or Special Characters',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						});
						document.getElementById("received_by").value = "";
 } else{
		if (received_by != "") 
		{    
			var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;
				if (!Checkregex.test(received_by)) 
				{
					swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits or special characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("received_by").value = "";
		           }
	          });
				}
				else{
				return true;
		     	} 
		}
    }
 }

    $("#clearpage").click(function() {
        clearpge();
    });

    $("#material_submit").click(function() {
        save_submit();
    });

    var roleid = window.localStorage.getItem("roleid"); 
    if(roleid=="1"){
        $("#txtshow").hide();
     }  
</script>