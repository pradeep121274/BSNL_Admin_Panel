<style>
h4.text-dark.actpend {
    color: white !important;
}
h3.text-dark.actpend {
    color: white !important;
}
.actcolor.bg-primary.card-body {
    background-color: #D82E2F !important;
}

.cardaction{
    width: 355px;
    height: 300px;
}

.nexrow{
justify-content: center;
}

/* .desc{
    color:#000000;
    font-weight: bold;
} */

@media (min-width: 576px){
.modal-dialog {
    max-width: 900px;
    margin: 1.75rem auto;
}
}

</style>
<script src="https://www.gstatic.com/charts/loader.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
    // Function to determine the base URL based on login
    function getBaseUrl(apiVal) {
        switch (parseInt(apiVal)) {
            case 1:
                return 'https://arthainfosystems.com/BSNLApi/BSNLApiPhaseOne/server.php/';
            case 2:
                return 'https://arthainfosystems.com/BSNLApi/BSNLApiPhaseTwo/server.php/';
            case 3:
                return 'https://arthainfosystems.com/BSNLApi/BSNLApiPhaseThree/server.php/';
            default:
                console.error("Invalid or missing apiVal:", apiVal);
                return ''; // Return an empty string or another default value based on your requirement
        }
    }

    // Fetch API value from localStorage
    var apiVal = localStorage.getItem("apiVal");

    if (apiVal) {
        var baseUrl = getBaseUrl(apiVal);

        if (baseUrl) {
            // Fetch your data dynamically using the determined base URL
            fetch(baseUrl + 'api/chart-data')
                .then(response => response.json())
                .then(data => {
                    // Process the dynamic data

                    // Replace pie chart logic with your chart population or any other logic
                    var chartData1 = data.chartData1;
                    var chartData2 = data.chartData2;

                    var combinedData1 = {
                        datasets: [
                            {
                                data: chartData1.map(item => item.value),
                                backgroundColor: ['green', 'yellow', 'orange'],
                                label: 'Installation Status'
                            }
                        ],
                        labels: chartData1.map(item => item.label)
                    };
                    var options1 = {
                        plugins: {
                            title: {
                                display: true,
                                text: 'I & C Activity Progress'
                            }
                        }
                    };
                    var combinedData2 = {
                        datasets: [
                            {
                                data: chartData2.map(item => item.value),
                                backgroundColor: ['green', 'yellow', 'orange'],
                                label: 'Acceptance Test Status',
                            }
                        ],
                        labels: chartData2.map(item => item.label)
                    };
                    var options2 = {
                        plugins: {
                            title: {
                                display: true,
                                text: 'AT Activity Status'
                            }
                        }
                    };

                    // Create or update the first pie chart
                    var ctx1 = document.getElementById('chartCanvas1');
                    if (window.myPieChart1) {
                        // Update existing chart if it exists
                        window.myPieChart1.data = combinedData1;
                        window.myPieChart1.options.title.text = 'I & C Activity Progress';
                        window.myPieChart1.update();
                    } else {
                        // Create a new pie chart
                        window.myPieChart1 = new Chart(ctx1, {
                            type: 'pie',
                            data: combinedData1,
                            options: {
                                title: {
                                    display: true,
                                    text: 'I & C Activity Progress'
                                }
                            }
                        });
                    }

                    // Create or update the second pie chart
                    var ctx2 = document.getElementById('chartCanvas2');
                    if (window.myPieChart2) {
                        // Update existing chart if it exists
                        window.myPieChart2.data = combinedData2;
                        window.myPieChart2.options.title.text = 'AT Activity Status';
                        window.myPieChart2.update();
                    } else {
                        // Create a new pie chart
                        window.myPieChart2 = new Chart(ctx2, {
                            type: 'pie',
                            data: combinedData2,
                            options: {
                                title: {
                                    display: true,
                                    text: 'AT Activity Status'
                                }
                            }
                        });
                    }

                    console.log("Data:", data);
                })
                .catch(error => console.error('Error fetching data:', error));
        } else {
            console.error("Invalid or missing baseUrl for apiVal:", apiVal);
        }
    } else {
        console.error("Missing apiVal in localStorage");
    }
});
</script>

    <script src='https://cdn.plot.ly/plotly-2.27.0.min.js'></script>
<script src="<?php echo base_url(); ?>api/centralApi.js"></script>
<script src="<?php echo base_url(); ?>api/dashboard.js"></script>
<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
        
            <div class="container-fluid" >
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <h5 class="mb-0">Hi, <small>Welcome</small></h5>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Dashboard</a></li>
                        </ol>
                    </div>
                </div>

                <div id="sec1">
                <div class="row">
                    <!--<div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">-->
                    <!--   <a href="<?php echo base_url();?>undeliveredmaterialreport">-->
                    <!--    <div class="card widget-stat">-->
                    <!--        <div class="card-body bg-primary actcolor">-->
                    <!--            <div class="d-flex justify-content-between">-->
                    <!--                <div>-->
                    <!--                    <h4 class="text-dark actpend">Undelivered Materials</h4>-->
                    <!--                </div>-->
                    <!--               <h3 class="text-dark actpend" id="undeliveredcount">&nbsp;</h3>-->
                                   <!-- <h3 class="text-dark">20</h3> -->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</a>-->
                    <!--</div>-->
                    <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                       <a href="<?php echo base_url();?>survey">
                        <div class="card widget-stat">
                            <div class="card-body bg-primary cardaction">
                                <div class="d-flex justify-content-between">
                                    <div style="width: -webkit-fill-available;">
                                        <h4 class="text-dark">Survey Completed</h4>
                                    </div>
                                   <h3 class="text-dark" id="surveycount">&nbsp;</h3>
                                   <h3 class="text-dark">/</h3>
                                   <h3 class="text-dark" id="ssacount">&nbsp;</h3>

                                   <!-- <h3 class="text-dark">20</h3> -->
                                </div><br/>
                                  <h5 class="text-dark" style="cursor: pointer;"><a id="site_open" data-placement="top" title="View" data-toggle="modal" data-target="#SurveyQuickView">Site ready for installation :  <span id="readyinstallcnt"></span></a></h5>

                                  <h5 class="text-dark" style="cursor: pointer;"><a id="site_issue" data-placement="top" title="View" data-toggle="modal" data-target="#SurveyQuickView">Sites with open issues :  <span id="ntreadytoinstallcnt"></span></a></h5>
                                   
                                  <!-- <h5 class="desc">2. Sites with open issues:<span id="ntreadytoinstallcnt"></span></h5> -->
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                    <a href="<?php echo base_url();?>material">
                        <div class="card widget-stat">
                            <div class="card-body bg-success cardaction">
                                <div class="d-flex justify-content-between">
                                    <div style="width: -webkit-fill-available;">
                                        <h4 class="text-dark">Material Delivered Successfully</h4>
                                    </div>
                                   <h3 class="text-dark" id="materialdelivery">&nbsp;</h3>
                                   <!-- <h3 class="text-dark">/135</h3> -->
                                   <h3 class="text-dark">/</h3>
                                   <h3 class="text-dark" id="materialssacount">&nbsp;</h3>
                                    <!-- <h3 class="text-dark">60</h3> -->
                                </div>
                                  <h5 class="text-dark" style="cursor: pointer;"><a id="transit_open" data-placement="top" title="View" data-toggle="modal" data-target="#transitQuickView"  >In transit :  <span id="materialdispatchcnt"></span></a></h5>

                                  <h5 class="text-dark" style="cursor: pointer;"><a id="materialpartial" data-placement="top" title="View" data-toggle="modal" data-target="#transitQuickView">Partial delivery :  <span id="materialpartialcnt"></span></a></h5>

                                  <h5 class="text-dark" style="cursor: pointer;"><a id="materialopenissue" data-placement="top" title="View" data-toggle="modal" data-target="#transitQuickView">Material  delivery with open issues :  <span id="materialopenissuecnt"></span></a></h5>
                            </div>
                        </div>
                      </a>
                    </div>

                    <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                       <a href="<?php echo base_url();?>commissioning">
                        <div class="card widget-stat">
                            <div class="card-body bg-primary cardaction">
                                <div class="d-flex justify-content-between">
                                    <div style="width: -webkit-fill-available;">
                                        <h4 class="text-dark">Equipment Powered ON</h4>
                                    </div>
                                   <h3 class="text-dark" id="installationcount">&nbsp;</h3>
                                   <!-- <h3 class="text-dark">/135</h3> -->
                                   <h3 class="text-dark">/</h3>
                                   <h3 class="text-dark" id="powerssacount">&nbsp;</h3>
                                </div>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="installprogress" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView"  >Installation in progress :  <span id="installprogresscnt"></span></a></h5>

                                 <h5 class="text-dark"style="cursor: pointer;"><a id="installhold" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">Installation activity hold :  <span id="installholdcnt"></span></a></h5>

                                 <h5 class="text-dark"style="cursor: pointer;"><a id="installopenissue" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">Installation with open issues :  <span id="installopenissuecnt"></span></a></h5>

                                <!-- <h5 class="desc">5. Installation in progress:<span id="installprogresscnt"></span></h5> -->
                                <!-- <h5 class="desc">6. Installation activity hold:<span id="installholdcnt"></span></h5> -->
                            </div>
                        </div>
                    </a>
                    </div>
                </div>

                 <div class="row nexrow">
                    <!--    <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">-->
                    <!--<a href="<?php echo base_url();?>inventoryreport">-->
                    <!--    <div class="card widget-stat">-->
                    <!--        <div class="card-body bg-info">-->
                    <!--            <div class="d-flex justify-content-between">-->
                    <!--                <div>-->
                    <!--                    <h4 class="text-dark">Total No of Inventory</h4>-->
                    <!--                </div>-->
                    <!--               <h3 class="text-dark" id="inventorycount">&nbsp;</h3>-->
                                    <!-- <h3 class="text-dark">80</h3> -->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--  </a>-->
                    <!--</div>-->

                <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                       <a href="<?php echo base_url();?>commissioning">
                        <div class="card widget-stat">
                            <div class="card-body bg-primary cardaction">
                                <!-- <div class="d-flex justify-content-between"> -->
                                    <!-- <div style="width: -webkit-fill-available;">
                                        <h5 class="text-dark"></h5>
                                    </div> -->
                                   <!-- <h3 class="text-dark" id="installationcount">&nbsp;</h3>
                                   <h3 class="text-dark">/135</h3> -->
                                   <!-- <h3 class="text-dark">120</h3> -->
                                 <!-- </div> -->

                                <h5 class="text-dark" style="cursor: pointer;"><a id="mplsreach" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">MPLS reachbility and basic configuration completed :  <span id="mplsreachcnt"></span>/<span id="mplssacount"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="mplsbngtypeone" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">BNG TYPE-I :  <span id="bngtypeone"></span></a></h5>
                                <h5 class="text-dark" style="cursor: pointer;"><a id="mplsbngtypetwo" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">BNG TYPE-II :  <span id="bngtypetwo"></span></a></h5>
                                <h5 class="text-dark" style="cursor: pointer;"><a id="mplscontrolplane" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">Control plane :  <span id="controlplanecnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="mplsrpop" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">RPOP :  <span id="rpopcnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="mplsups" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">UPS :  <span id="mplsupscnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="mplsopenissue" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">MPLS reachbility with open issues :  <span id="mplsopenissuecnt"></span></a></h5>

                                <!-- <h5 class="desc">7.MPLS reachbility and basic configuration completed:<span id="mplsreachcnt"></span></h5><br/> -->
                                <!-- <h5 class="desc">8. User plane:<span id="userplanecnt"></span></h5>
                                <h5 class="desc">9. Control plane:<span id="controlplanecnt"></span></h5>
                                <h5 class="desc">10. RPOP:<span id="rpopcnt"></span></h5> -->
                            </div>
                        </div>
                    </a>
                    </div> 
                     <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                    <a href="<?php echo base_url();?>commissioning">
                        <div class="card widget-stat">
                            <div class="card-body bg-success cardaction">
                                <div class="d-flex justify-content-between">
                                    <div style="width: -webkit-fill-available;">
                                        <h4 class="text-dark">Commissioning Completed</h4>                                    
                                    </div>
                                   <h3 class="text-dark" id="commissioncount">&nbsp;</h3>
                                   <h3 class="text-dark">/</h3>
                                   <h3 class="text-dark" id="commissionssacount">&nbsp;</h3>
                                   <!-- <h3 class="text-dark">/135</h3> -->
                                    <!-- <h3 class="text-dark">120</h3> -->
                                </div>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="commissionbngtypeone" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">BNG TYPE-I :  <span id="commissionbngonecnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="commissionbngtypetwo" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">BNG TYPE-II :  <span id="commissionbngtwocnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="commissioncontrol" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">Control plane :  <span id="commissioncontrolcnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="commissionrpop" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">RPOP :  <span id="commissionrpopcnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="commissionups" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">UPS :  <span id="commissionupscnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="commissionopenissue" data-placement="top" title="View" data-toggle="modal" data-target="#progressQuickView">Commissioning with open issues :  <span id="commissionopenissuecnt"></span></a></h5>

                                <!-- class="desc">11. User plane:<span id="commissionusercnt"></span></h5> -->
                                <!-- class="desc">12. Control plane:<span id="commissioncontrolcnt"></span></h5> -->
                                <!-- class="desc">13. RPOP:<span id="commissionrpopcnt"></span></h5> -->
                                <!-- class="desc">14. UPS:<span id="commissionupscnt"></span></h5> -->

                            </div>
                        </div>
                      </a>
                    </div>
                    <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                       <a href="<?php echo base_url();?>acceptance">
                        <div class="card widget-stat">
                            <div class="card-body bg-primary cardaction">
                                <div class="d-flex justify-content-between">
                                    <div style="width: -webkit-fill-available;">
                                    <h4 class="text-dark">Acceptance Issued</h4> 
                                    </div>
                                   <h3 class="text-dark" id="acceptancecount">&nbsp;</h3>
                                   <h3 class="text-dark">/</h3>
                                   <h3 class="text-dark" id="acceptancessacount">&nbsp;</h3>
                                   <!-- <h3 class="text-dark">/135</h3> -->
                                   <!-- <h3 class="text-dark">120</h3> -->
                                </div>  

                                <h5 class="text-dark" style="cursor: pointer;"><a id="acceptancebngone" data-placement="top" title="View" data-toggle="modal" data-target="#acceptanceQuickView">BNG TYPE-I :  <span id="acceptancebngonecnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="acceptancebngtwo" data-placement="top" title="View" data-toggle="modal" data-target="#acceptanceQuickView">BNG TYPE-II :  <span id="acceptancebngtwocnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="acceptancecontrol" data-placement="top" title="View" data-toggle="modal" data-target="#acceptanceQuickView">Control plane :  <span id="acceptancecontrolcnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="acceptancerpop" data-placement="top" title="View" data-toggle="modal" data-target="#acceptanceQuickView">RPOP :  <span id="acceptancerpopcnt"></span></a></h5>

                                <h5 class="text-dark" style="cursor: pointer;"><a id="acceptanceups" data-placement="top" title="View" data-toggle="modal" data-target="#acceptanceQuickView">UPS :  <span id="acceptanceupscnt"></span></a></h5>

                                 <h5 class="text-dark" style="cursor: pointer;"><a id="acceptanceopenissue" data-placement="top" title="View" data-toggle="modal" data-target="#acceptanceQuickView">Acceptance with open issues :  <span id="acceptanceopenissuecnt"></span></a></h5>

                                <!-- <h5 class="desc">16. User plane:<span id="acceptanceusercnt"></span></h5> -->
                                <!-- <h5 class="desc">17. Control plane:<span id="acceptancecontrolcnt"></span></h5>
                                <h5 class="desc">18. RPOP:<span id="acceptancerpopcnt"></span></h5>
                                <h5 class="desc">19. UPS:<span id="acceptanceupscnt"></span></h5> -->
                            </div>
                        </div>
                    </a>
                    </div>
                   
                     <!-- <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                    <a href="<?php echo base_url();?>busreport">
                        <div class="card widget-stat">
                            <div class="card-body bg-info">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">Total No of Buses</h4>
                                    </div>
                                   <h3 class="text-dark" id="buscount">&nbsp;</h3>
                                    <!-- <h3 class="text-dark">70</h3> -->
                                <!-- </div>
                            </div>
                        </div>
                      </a>
                    </div>  -->
                </div>

                  <!-- <div class="row"> -->
                    <!-- <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                        <div class="card widget-stat">
                            <div class="card-body bg-info">
                            <a href="<?php echo base_url();?>specialcustomer">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">Total No of </h4>
                                    </div>
                                  <h3 class="text-dark" id="specialcust">&nbsp;</h3>
                                     <!-- <h3 class="text-dark">20</h3> -->
                                <!-- </div>
                            </a>
                            </div>
                        </div>
                    </div> --> 
                    <!-- <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                        <div class="card widget-stat">
                            <div class="card-body bg-primary">
                            <a href="<?php echo base_url();?>vehicletype">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">No of Special Customers</h4>
                                    </div>
                                <!--    <h3 class="text-dark" id="ongoingorderscount">&nbsp;</h3> -->
                         <!--      <h3 class="text-dark">200</h3>
                                </div>
                            </a>
                            </div>
                        </div>
                    </div> -->
                    <!-- <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                        <div class="card widget-stat">
                            <div class="card-body bg-success">
                            <a href="<?php echo base_url();?>vehicletype">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">No of Approved Vehicles</h4>
                                    </div>
                               <!--     <h3 class="text-dark" id="totalorderscount">&nbsp;</h3> -->
                               <!--          <h3 class="text-dark">200</h3>

                                </div>
                            </a>
                            </div>
                        </div>
                    </div>  -->
<!-- 
                </div> -->
                
            <!-- <div class="container"> -->
                        <div class="row">
                        <div class="col-sm">
                        <!-- <canvas id="myChart" style="width:100%;max-width:600px"></canvas> -->
                        <div id="columnchart_material" style="width: 600px; height: 400px;"></div>
                    </div>
                        <div class="col-sm">
                    <!-- <div id="myChart1" style="width:100%; max-width:400px; height:400px;"></div> -->
                    <!-- <canvas id="chartCanvas1" width="400" height="400"></canvas> -->
                            <canvas id="chartCanvas1" style="width:100%; max-width:400px; height:400px;"></canvas>
                            </div>
                            <div class="col-sm">
                    <!-- <div id="myChart2" style="width:80%; max-width:400px; height:400px;"></div> -->
                    <!-- <canvas id="chartCanvas2" width="400" height="400"></canvas> -->
                        <canvas id="chartCanvas2"style="width:100%; max-width:400px; height:400px;"></canvas>
                        </div>
                <!-- </div> -->
            </div>
             </div>

                <!-- <div id="sec2">
                <div class="row">
                    <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                       <a href="<?php echo base_url();?>customerreport">
                        <div class="card widget-stat">
                            <div class="card-body bg-primary">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">Total No of Customers</h4>
                                    </div>
                                   <h3 class="text-dark" id="customercunts">&nbsp;</h3>
                                   <h3 class="text-dark">120</h3>
                                </div>
                            </div>
                        </div>
                    </a>
                    </div>
                    <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                        <div class="card widget-stat">
                            <div class="card-body bg-info">
                            <a href="<?php echo base_url();?>specialcustomer">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark"> No of Special Customers</h4>
                                    </div>
                                  <h3 class="text-dark" id="specialcusts">&nbsp;</h3>
                                     <h3 class="text-dark">20</h3>
                                </div>
                            </a>
                            </div>
                        </div>
                    </div>
                </div>

                
        
             </div> -->

             <!--    <div id="sec3">
                <div class="row">
                    <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                    <a href="<?php echo base_url();?>driverreport">
                        <div class="card widget-stat">
                            <div class="card-body bg-success">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">Total No of Drivers</h4>
                                    </div>
                                   <h3 class="text-dark" id="stproductcount">&nbsp;</h3>
                                    <h3 class="text-dark">600</h3>
                                </div>
                            </div>
                        </div>
                      </a>
                    </div> -->
                    
                    <!-- <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                       <a href="<?php echo base_url();?>driverreport">
                        <div class="card widget-stat">
                            <div class="card-body bg-primary">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">No of Approved Drivers</h4>
                                    </div>
                                   <h3 class="text-dark" id="stapprovedrivers">&nbsp;</h3>
                                   <!-- <h3 class="text-dark">120</h3> -->
                             <!--    </div>
                            </div>
                        </div>
                    </a>
                    </div> -->

                    <!-- <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                    <a href="<?php echo base_url();?>driverreport">
                        <div class="card widget-stat">
                            <div class="card-body bg-success">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">No of Pending Drivers</h4>
                                    </div>
                                   <h3 class="text-dark" id="stpendingdrivers">&nbsp;</h3>
                                    <!-- <h3 class="text-dark">600</h3> -->
                                 <!--  </div>
                            </div>
                        </div>
                      </a>
                    </div> -->

                </div>

                 <!-- <div class="row">
                     <div class="col-xl-4 col-xxl-4 col-lg-6 col-md-4">
                    <a href="<?php echo base_url();?>specialdriver">
                        <div class="card widget-stat">

                            <div class="card-body bg-info">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4 class="text-dark">No of Special Drivers</h4>
                                    </div>
                                   <h3 class="text-dark" id="stspecialdrivers">&nbsp;</h3>
/                                </div>
                            </div>
                        </div>
                      </a>
                    </div> 
                </div> 

             </div>
            </div>-->

        </div>

           
        </div>
        
        <!--**********************************
            Content body end
        ***********************************-->


           <!-- Start QuickView Survey Modal Area -->
     <div class="modal fade productsQuickView" id="SurveyQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border : 1;">
                                        <thead>
                                        <tr>
                                        <th>Sl No</th>
                                        <th>SSA Name</th>
                                        <th>Site Type </th>
                                        <th>Zone Name</th>
                                        <th>Circle Name</th>                                        
                                        <th>Survey Planned Date</th>
                                        <th>Survey Status</th>
                                        <th>Survey Completed Date</th>
                                        <th>Report Signoff</th>
                                        <th>Upload Status</th>
                                        <th>Site Ready for Installation</th>
                                        <th>Remarks</th>
                                        <th>Bsnl Remarks</th>
                                        <!-- <th>Download Report</th>
                                        <th id="actions">Action</th> -->
                                        </tr>
                                        </thead>
                                        <tbody id="allsiteopen">
                                        </tbody> 
                                    </table>
                                </div>
                            </div>
                </div>
            </div>
        </div>

        <!-- End QuickView Survey Modal Area -->

           <!-- Start QuickView Material Modal Area -->
     <div class="modal fade productsQuickView" id="transitQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-responsive-sm" id="materialexample" class="display" style="min-width: 100%; border : 1;">
                                <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Zone</th>
                                        <th>Circle</th>
                                        <th>SSA</th>
                                        <th>Site Type</th>
                                        <th>Material Delivery Plan Date</th>
                                        <th>Material Receiving date</th>
                                        <th>Material Received by</th>
                                        <th>BC/DC Sign off By BSNL</th>
                                        <th>Status</th>
                                        <th>Material Dispatched Date</th>
                                        <th>Remarks</th>
                                        <th>Bsnl Remarks</th>
                                    </tr>
                                </thead>
                                <tbody id="allmaterials">
                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>

        <!-- End QuickView Material Modal Area -->

        <!-- Start QuickView Installation Modal Area -->
     <div class="modal fade productsQuickView" id="progressQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-responsive-sm" id="installexample" class="display" style="min-width: 100%; border : 1;">
                                <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>SSA</th>
                                        <th>Site Type</th>
                                        <th>Region</th>
                                        <th>Circle</th>
                                        <th>Site Name</th>
                                        <th>Start Plan Date</th>
                                        <th>Installation Status</th>
                                        <th>Installation Date</th>
                                        <th>Commissioning/Config Status</th>
                                        <th>Commissioning Completion Date</th>
                                        <th>MPLS reachability and basic configuration</th>
                                        <th>Remarks</th>
                                        <th>Bsnl Remarks</th>
                                    </tr>
                                </thead>
                                <tbody id="allinstallprogress">
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- End QuickView Installation Modal Area -->

      <!--  Start QuickView Acceptance Modal Area -->
     <div class="modal fade productsQuickView" id="acceptanceQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                           <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-responsive-sm" id="acceptanceexample" class="display" style="min-width: 100%; border : 1;">
                                        <thead>
                                        <tr>
                                        <th>Sl No</th>
                                        <th>SSA Name</th>
                                        <th>Site Type</th>
                                        <th>Zone</th>
                                        <th>Circle</th>
                                        <th>Site Name</th>
                                        <th>AT plan date</th>
                                        <th>Pre-AT Status</th>
                                        <th>Pre-AT Completion Date</th>
                                        <th>Final AT Status</th>
                                        <th>Final AT Completion Date</th>
                                        <th>Acceptance Certificate Issued</th>
                                        <th>Remarks</th>
                                        <th>Bsnl Remarks</th>
                                        </tr>
                                        </thead>
                                        <tbody id="allacceptancedata">
                                        </tbody> 
                                    </table>
                                </div>
                            </div>
                </div>
            </div>
            <div>
       
        </div>
        

       
        <!-- End QuickView Acceptance Modal Area -->

         
  <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
  <script>
                $(document).ready(function(){
                     let userid = window.localStorage.getItem("userid"); 
                        if(userid == "" || userid == null ||userid == undefined){
                        window.location = baseurl; 
                        } else {
                    getAllDashboardData();
                    undelivereddata();
                    renderChartData();
                    drawChart();
                        }

            //  let roleid = window.localStorage.getItem("roleid"); 

    //  if(roleid =="5" || roleid == "6" || roleid == "7"){
    //     $("#sec1").show();
    //     $("#sec2").hide();
    //     $("#sec3").hide();
    //  }

    // if(roleid=="4" || roleid=="8" || roleid=="9" || roleid == "10"){
    //     $("#sec2").show();
    //     $("#sec1").hide();
    //     $("#sec3").hide();
    //  }

    //  if(roleid=="1" || roleid=="2" || roleid=="3"){
    //     $("#sec3").show();
    //     $("#sec1").hide();
    //     $("#sec2").hide();
    //  }
        });

        $("#site_open").click(function (){
            readytoinstall();
        });

         $("#site_issue").click(function (){
            siteissue();
        });

        $("#transit_open").click(function (){
            materialtransit();
        });

       $("#materialpartial").click(function (){
            materialpartials();
        });

       $("#materialopenissue").click(function (){
            materialopenissuedata();
        });

        $("#installprogress").click(function (){
            installcommissionprogress();
        });

       $("#installhold").click(function (){
            installcommissionhold();
        });

       $("#installopenissue").click(function (){
            installopenissuedata();
        });
        
        $("#mplsreach").click(function (){
            mplsreachdata();
        });

        $("#mplsbngtypeone").click(function (){
            mplsbngonedata();
        });

        $("#mplsbngtypetwo").click(function (){
            mplsbngtwodata();
        });

        $("#mplsuserplane").click(function (){
            mplsuserplanedata();
        });

        $("#mplscontrolplane").click(function (){
            mplscontrolplanedata();
        });

       $("#mplsrpop").click(function (){
            mplsrpopdata();
        });
        

        $("#mplsups").click(function (){
            mplsupsdata();
        });

        $("#mplsopenissue").click(function (){
            mplsopenissuedata();
        });

        $("#commissionuser").click(function (){
            commissionuserdata();
        });
        
        $("#commissionbngtypeone").click(function (){
            commissionbngonedata();
        });

        $("#commissionbngtypetwo").click(function (){
            commissionbngtwodata();
        });


        $("#commissioncontrol").click(function (){
            commissioncontroldata();
        });

        $("#commissionrpop").click(function (){
            commissionrpopdata();
        });

       $("#commissionups").click(function (){
            commissionupsdata();
        });
        
        $("#commissionopenissue").click(function (){
            commissionopenissuedata();
        });

        $("#acceptanceuser").click(function (){
            acceptanceuserdata();
        });

        $("#acceptancebngone").click(function (){
            acceptancebngonedata();
        });

        $("#acceptancebngtwo").click(function (){
            acceptancebngtwodata();
        });

        $("#acceptancecontrol").click(function (){
            acceptancecontroldata();
        });

        $("#acceptancerpop").click(function (){
            acceptancerpopdata();
        });

        $("#acceptanceups").click(function (){
            acceptanceupsdata();
        });

        $("#acceptanceopenissue").click(function (){
            acceptanceopenissuedata();
        });
        //  bar chart code by pradeep 
         </script> 

   <!-- <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);
         
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['chartData','RPOP', 'CP','UP1'],
          ['RPOP', 3, 1, 3],
          ['CP', 4, 2, 4],
          ['UP1', 5, 10, 4],
          ['UP2', 5, 10, 4],
        ]);
        // var data = google.visualization.arrayToDataTable(chartData1,true);
        var options = {
        title: 'Project Progress',
        width: 600,
        height: 400,
        chartArea: {width: '50%'},
        hAxis: {
          title: 'Activities Status Timeline',
          minValue: 0
        },
        vAxis: {
          title: 'NUMBER OF SITE COMPLTED'
        }
      };
        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));
        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
// Call the drawChart function to initially draw the chart
drawChart();
    </script>  -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    google.charts.load('current', {'packages':['bar']});
    google.charts.setOnLoadCallback(drawChart);

    function getBaseUrl(apiVal) {
        switch (parseInt(apiVal)) {
            case 1:
                return 'https://arthainfosystems.com/BSNLApi/BSNLApiPhaseOne/server.php/';
            case 2:
                return 'https://arthainfosystems.com/BSNLApi/BSNLApiPhaseTwo/server.php/';
            case 3:
                return 'https://arthainfosystems.com/BSNLApi/BSNLApiPhaseThree/server.php/';
            default:
                console.error("Invalid or missing apiVal:", apiVal);
                return ''; 
        }
    }

    var apiVal = localStorage.getItem("apiVal");
    var baseUrl = getBaseUrl(apiVal);

    function drawChart() {
        
        fetch(baseUrl + 'api/line-chart-data')
            .then(response => response.json())
            .then(data => {
                if (data.chartData.length === 0) {
                    // If no data, only show the axes without any bars
                    var chartData = [
                        ['Label', { role: 'annotation' }],
                        ['No Data', 'No Data'],
                    ];
                } else {
                    
                    var chartData = [
                        ['Label', 'RPOP', 'RPOP', 'RPOP', 'CP', 'CP', 'CP', 'UP1', 'UP1', 'UP1', 'UP2', 'UP2', 'UP2'],
                        [data.chartData[0].label, data.chartData[0].value, data.chartData2[0].value, data.chartData3[0].value, data.chartData4[0].value, data.chartData5[0].value, data.chartData6[0].value, data.chartData7[0].value, data.chartData8[0].value, data.chartData9[0].value, data.chartData10[0].value, data.chartData11[0].value, data.chartData12[0].value]
                    ];
                }

                var dataTable = google.visualization.arrayToDataTable(chartData);

                var options = {
                    title: 'Project Progress',
                    width: 600,
                    height: 400,
                    chartArea: { width: '50%' },
                    hAxis: {
                        title: 'Activities Status Timeline',
                        minValue: 0
                    },
                    vAxis: {
                        title: 'NUMBER OF SITE COMPLETED'
                    }
                };

                var chart = new google.charts.Bar(document.getElementById('columnchart_material'));
                chart.draw(dataTable, google.charts.Bar.convertOptions(options));
            })
            .catch(error => console.error('Error fetching data:', error));
    }
</script>