<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style>
  .box {
	float: left;
	padding: 50px 0px;
}

.clearfix::after {
	clear: both;
	display: table;
}

.options {
	margin: 5px 0px 0px 0px;
	float: left;
}

.pagination {
	float: right;
}

.pagination a {
	color: black;
	float: left;
	padding: 8px 16px;
	text-decoration: none;
	transition: background-color .3s;
	border: 1px solid #ddd;
	margin: 0 4px;
}

.pagination a.activepage {
	background-color: #4CAF50;
	color: white;
	border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {
	background-color: #ddd;
}

.file {
  visibility: hidden;
  position: absolute;
}

input#files {
    width: 250px;
} 

@media screen and (max-width: 480px){

a {
  font-size: 8px;
}
.btn{
  font-size: 9px;
}
}
</style>
<script src="<?php echo base_url(); ?>api/acceptance.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>
 <!--**********************************
            Content body start
        ***********************************-->
        <div class="ajax-loader">
            <img src="<?php echo base_url(); ?>assets\images/loader.gif" class="img-responsive" />
        </div>
        <div class="content-bodys">
            <div class="container-fluid" style="padding-top:0px;">
            <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="breadcrumb-range-picker">
                            <span><i class="icon-calender"></i></span>
                            <span class="ml-1">Home</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Acceptance List</a></li>
                        </ol>
                    </div>
                </div>
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card" id="pincodename">
                            <div class="card-header">
                                <h4 class="card-title">Acceptance Form</h4>
                                <button type="submit" class="btn btn-primary" id="listview"> Back to list
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Add"><i
                                            class="fa fa-undo color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                          <div class="form-row">
                                              <div class="form-group col-md-6">
                                                <label>SSA*</label>
                                                   <select id="ssa_name" name="ssa_name"  class="form-control select2" required onChange="getallData();"></select>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Site Type*</label>
                                                    <select id="site_type" class="form-control select2" required></select>
                                            </div>                                          
                                            </div>

                                      <div class="form-row">
                                          <div class="form-group col-md-6">
                                                <label>Zone*</label>
                                                <select id="region" name="region" class="form-control select2" required>
                                                </select>
                                            </div>
                                              <div class="form-group col-md-6">
                                                <label>Circle*</label>
                                                <select id="circle_name" name="circle_name"  class="form-control select2" required>
                                                </select>
                                            </div>
                                      </div>

                                            <div class="form-row">
                                               <div class="form-group col-md-6">
                                                <label>Site Name*</label>
                                                <input type="text" class="form-control" id="site_name" name="site_name" placeholder="Enter Site Name" value="" maxlength="30" onblur="sitenm_validation()" required>
                                            </div>
                                          <div class="form-group col-md-6">
                                                <label>AT Plan Date*</label>
                                                <input type="text" class="form-control" id="atdate" name="atdate" placeholder="Select AT Plan Date" value="" required>
                                            </div>
                                            </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Pre-AT Status*</label>
                                                <select id="prestatus" class="form-control select2">
                                                    <option>-- Please Select --</option>
                                                    <option value='Pending'>Pending</option>
                                                    <option value='Completed'>Completed</option>
                                                    <option value='In progress'>In progress</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Pre-AT Completion Date*</label>
                                                <input type="text" class="form-control" id="actdate" name="actdate" placeholder="Select Pre-AT completion Date" value="" required>
                                            </div>
                                        </div>

                                          <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Final AT Status*</label>
                                                <select id="at_status" class="form-control select2"> 
                                                    <option>-- Please Select --</option>
                                                    <option value='Pending'>Pending</option>
                                                    <option value='In progress'>In progress</option>
                                                    <option value='Completed'>Completed</option>
                                                    </select>
                                            </div>
                                                  <div class="form-group col-md-6">
                                                <label>Final AT Completion Date*</label>
                                                <input type="text" class="form-control" id="finalatdate" name="finalatdate" placeholder="Enter Final AT Completion Date" value=""required>
                                            </div>
                                            </div>

                                         <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Partial Migration Date</label>
                                                <input type="text" class="form-control" id="partial_dt" name="partial_dt" placeholder="Enter Partial Migration Date" value=""required>
                                            </div>
                                                  <div class="form-group col-md-6">
                                                <label>Full Migration Date</label>
                                                <input type="text" class="form-control" id="full_dt" name="full_dt" placeholder="Enter Full Migration Date" value=""required>
                                            </div>
                                            </div>

                                  <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label>Acceptance Certificate Issued*</label>
                                                <select id="cer_issue" class="form-control select2">
                                                         <option>-- Please Select --</option>
                                                        <option value='Yes'>Yes</option>
                                                        <option value='No'>No</option>
                                                </select>
                                         </div>
                                        <div class="form-group col-md-6">
                                            <div class="row">  
                                                <div>
                                                    <label>Upload Acceptance Certificate</label>
                                                     <div class="col-md-3">
                                                       <input class="btn btn-primary" type="file" id="files" name="files" onchange="getFileData(this);"/>
                                                     </div><br/>
                                                      <div class="col-md-3">
							                           <img id="blahs">
                                                      </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                            <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label>Remarks</label>
                                                <textarea rows="5" cols="170" id="remarks"  onblur="remarks_validate()" placeholder="Enter Remarks(if Any)" required></textarea>
                                            </div>
                                            </div>
                                            
                                         <input type="submit" id="acceptance_submit" name="acceptance_submit" value="Submit" class="btn btn-primary"/>  
                                            <input type="hidden" name="acceptid" id="acceptid" />
                                       <input type="reset" id="clearpage" name="Reset" class="btn btn-secondary" value="Clear">                              
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <!--**********************************
            Content body end
        ***********************************-->

<!-- Start QuickView Remarks Modal Area -->
     <div class="modal fade productsQuickView" id="productsQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label style="font-size: 16px;font-weight: 600;">Remarks</label>
                            <textarea style="padding: 5px;" rows="5" cols="70" id="bsnlremarks" placeholder="Enter Remarks(if any)"></textarea>
                        </div>                                         
                    </div> 
                    <div class="form-row">
                        <input type="submit" id="remarks_submit" name="remarks_submit" value="Submit" class="btn btn-primary" onclick="submitRemarks();"/> 
                    </div> 
                </div>
            </div>
        </div>

        <!-- End QuickView Remarks Modal Area -->
                    
        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body" style="padding-top: 0rem !important;">
            <div class="container-fluid">
               
                <!-- row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card" id="listhide">
                            <div class="card-header">
                                <h4 class="card-title">Acceptance test List</h4>
                                <button type="submit" class="btn btn-primary"  id="txtshow"> Create Acceptance Test 
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Create Survey"><i
                                            class="fa fa-plus-circle color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border : 1;">
                                        <thead>
                                        <tr>
                                        <th>Sl No</th>
                                        <th>SSA Name</th>
                                        <th>Site Type</th>
                                        <th>Zone</th>
                                        <th>Circle</th>
                                        <th>Site Name</th>
                                        <th>AT plan date</th>
                                        <th>Pre-AT Status</th>
                                        <th>Pre-AT Completion Date</th>
                                        <th>Final AT Status</th>
                                        <th>Final AT Completion Date</th>
                                        <th>Partial Migration Date</th>
                                        <th>Full Migration Date</th>
                                        <th>Acceptance Certificate Issued</th>
                                        <th>Remarks</th>
                                        <th>Bsnl Remarks</th>
                                        <th>Download Reports</th>
                                        <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="allusers">
                                        </tbody> 
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function(){
        var userid = window.localStorage.getItem("userid");
        if(userid == "" || userid == null || userid == undefined)
        {
            window.location="<?php echo base_url();?>"; 
        } 
        else {
            $("#pincodename").hide("");
             $('.select2').select2();
            getallzonedata();
            getallssadata();
            getcircledata();
            getallSiteTypedata();
            getallacceptancedata();
        }
        });


        $("#txtshow").click(function () {        
                $("#pincodename").show("");         
                $("#listhide").hide(""); 
        });

        $("#listview").click(function () {  
            location.reload();       
        });

 function sitenm_validation(){
     var  mx = 3;  
        var my = 30;      
        var site_name =$("#site_name").val();
        var len = site_name.length;
        var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;

      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Site Name should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("site_name").value = "";
    }
    else if(!Checkregex.test(site_name)){
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("site_name").value = "";
		           }else{
                       return true;
                   }
	          });					
    }
 }


 function remarks_validate(){ 
         var  mx = 3;  //minlength
         var my = 5000;
         var remarks = $("#remarks").val(); 
         var len = remarks.length;
          if(len < mx ||len >my){
      swal({
							type: 'warning',
							title: 'Oops...',
							text: 'Remarks should be between ' +mx+ ' and ' +my+ ' Characters,digits or Special Characters',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						});
			document.getElementById("remarks").value = "";
 }
}

		           var specilaimg = "";
                function getFileData(input) {   
                if (input.files && input.files[0]) {
                  // console.log(input.files[0]);
                     if(input.files[0].size > 1000000){
                    alert("Please Upload Image less than 1 MB");
                    }else {
                      var fileName = input.files[0].name;
                     //  $("#filep").val(fileName);
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        specilaimg = e.target.result;
                        document.getElementById("blahs").height = "100";
                        document.getElementById("blahs").width = "100";
                        $('#blahs').attr('src', e.target.result);  
                    }
                    reader.readAsDataURL(input.files[0]);
                }
                }
                }

  
 $("#clearpage").click(function(){ 
		 clearpge();
});	

$("#acceptance_submit").click(function(){   
    save_submit();
		  });

    var roleid = window.localStorage.getItem("roleid"); 
    if(roleid=="1"){
        $("#txtshow").hide();
     }  
</script>