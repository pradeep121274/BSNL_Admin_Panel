 <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style>
  .box {
	float: left;
	padding: 50px 0px;
}

.clearfix::after {
	clear: both;
	display: table;
}

.options {
	margin: 5px 0px 0px 0px;
	float: left;
}

.pagination {
	float: right;
}

.pagination a {
	color: black;
	float: left;
	padding: 8px 16px;
	text-decoration: none;
	transition: background-color .3s;
	border: 1px solid #ddd;
	margin: 0 4px;
}

.pagination a.activepage {
	background-color: #4CAF50;
	color: white;
	border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {
	background-color: #ddd;
}
.file {
  visibility: hidden;
  position: absolute;
}

@media screen and (max-width: 480px){

a {
  font-size: 8px;
}
.btn{
  font-size: 9px;
}
}
</style>
<script src="<?php echo base_url(); ?>api/survey.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>
 <!--**********************************
            Content body start
        ***********************************-->
        <div class="ajax-loader">
            <img src="<?php echo base_url(); ?>assets/images/loader.gif" class="img-responsive" />
        </div>
        <div class="content-bodys">
            <div class="container-fluid" style="padding-top:0px;">
            <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="breadcrumb-range-picker">
                            <span><i class="icon-calender"></i></span>
                            <span class="ml-1">Home</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Survey List</a></li>
                        </ol>
                    </div>
                </div>
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card" id="pincodename">
                            <div class="card-header">
                                <h4 class="card-title">Survey Form</h4>
                                <button type="submit" class="btn btn-primary" id="listview"> Back to list
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Add"><i
                                            class="fa fa-undo color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>SSA*</label>
                                                 <select id="ssa_name" name="ssa_name"  class="form-control select2" required onChange="getallData();"></select> 
                                            </div>  
                                            <div class="form-group col-md-6">
                                                <label>Site Type*</label>
                                                    <select id="site_type" class="form-control select2" required></select>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Zone*</label>
                                              <select id="zone_name" name="zone_name" class="form-control select2" required></select> 
                                            </div>
                                              <div class="form-group col-md-6">
                                                <label>Circle*</label>
                                                  <select id="circle_name" name="circle_name"  class="form-control select2" required></select> 
                                            </div>
                                        </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label>Site Survey Planned Date*</label>
                                            <input type="text" id="start_date" name="start_date"  class="form-control border-input" placeholder="Select Date" autocomplete="off" required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Site Survey Status*</label>
                                            <select id="site_status" class="form-control select2" required>
                                            <option>-- Please Select --</option>
                                            <option value='Hold'>Hold</option>
                                            <option value='Pending'>Pending</option>
                                            <option value='Completed'>Completed</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label>Site Survey Completed Date*</label>
                                            <input type="text" id="end_date" name="end_date"  class="form-control border-input" placeholder="Select Date" autocomplete="off" required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Survey Report Signoff*</label>
                                            <select id="survey_rep" class="form-control select2" required>
                                            <option>-- Please Select --</option>
                                            <option value='Yes'>Yes</option>
                                            <option value='No'>No</option></select>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label>Report Upload Status*</label>
                                            <select id="rep_status" class="form-control select2" required>
                                            <option>-- Please Select --</option>
                                            <option value='Yes'>Yes</option>
                                            <option value='No'>No</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <div class="row">  
                                                <div>
                                                    <label>Upload Report</label>
                                                <div class="col-md-3">
                                                <input class="btn btn-primary" type="file" id="files" name="files" onchange="getFileData(this);"/>
                                                </div><br/>
                                                <div class="col-md-3">
                                                    <img id="blahs">
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label>Site Ready for Installation*</label>
                                            <select id="install_status" class="form-control select2" required>
                                            <option>-- Please Select --</option>
                                            <option value='Yes'>Yes</option>
                                            <option value='No'>No</option>
                                            </select>
                                        </div>
                                    </div>


                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <label>Remarks</label>
                                                <textarea rows="5" cols="170" id="remarks" maxlength="1200" onblur="remarks_validate()" placeholder="Enter Remarks(if any)"></textarea>
                                        </div>                                         
                                    </div>
            
                                            
                                         <input type="submit" id="survey_submit" name="survey_submit" value="Submit" class="btn btn-primary"/>  
                                            <input type="hidden" name="surveyid" id="surveyid" />
                                       <input type="reset" id="clearpage" name="Reset" class="btn btn-secondary" value="Clear">                              
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <!--**********************************
            Content body end
        ***********************************-->

    <!-- Start QuickView Remarks Modal Area -->
     <div class="modal fade productsQuickView" id="productsQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label style="font-size: 16px;font-weight: 600;">Remarks :</label>
                            <textarea rows="5" cols="70" id="bsnlremarks" placeholder="Enter Remarks(if any)" style="padding: 5px;"></textarea>
                        </div>                                         
                    </div> 
                    <div class="form-row">
                        <input type="submit" id="remarks_submit" name="remarks_submit" value="Submit" class="btn btn-primary" onclick="submitRemarks();"/> 
                    </div> 
                </div>
            </div>
        </div>

        <!-- End QuickView Remarks Modal Area -->
                    
        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body" style="padding-top: 0rem !important;">
            <div class="container-fluid">
               
                <!-- row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card" id="listhide">
                            <div class="card-header">
                                <h4 class="card-title">Survey List</h4>
                                <button type="submit" class="btn btn-primary"  id="txtshow"> Create Survey 
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Create Survey"><i
                                            class="fa fa-plus-circle color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border : 1;">
                                        <thead>
                                        <tr>
                                        <th>Sl No</th>
                                        <th>SSA Name</th>
                                        <th>Site Type </th>
                                        <th>Zone Name</th>
                                        <th>Circle Name</th>                                        
                                        <th>Survey Planned Date</th>
                                        <th>Survey Status</th>
                                        <th>Survey Completed Date</th>
                                        <th>Report Signoff</th>
                                        <th>Upload Status</th>
                                        <th>Site Ready for Installation</th>
                                        <th>Remarks</th>
                                        <th>Bsnl Remarks</th>
                                        <th>Download Report</th>
                                        <th id="actions">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="allusers">
                                        </tbody> 
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function(){
        var userid = window.localStorage.getItem("userid");
        if(userid == "" || userid == null || userid == undefined)
        {
            window.location="<?php echo base_url();?>"; 
        } 
        else {
            $("#pincodename").hide("");
             $('.select2').select2();
            getcircledata();
            getssadata();
            getallSiteTypedata();
            getallzonedata();
            getallsurveydata();
        }
        });


        $("#txtshow").click(function () {        
            $("#pincodename").show("");         
            $("#listhide").hide(""); 
        });

        $("#listview").click(function () {  
            location.reload();       
        });



function address_validate(){ 
         var  mx = 3;  //minlength
         var my = 2000;
         var address = $("#address").val(); 
         var len = address.length;
          if(len < mx ||len >my){
      swal({
							type: 'warning',
							title: 'Oops...',
							text: 'Address should be between ' +mx+ ' and ' +my+ ' Characters,digits or Special Characters',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						});
			document.getElementById("address").value = "";
 }
}

function remarks_validate(){ 
         var  mx = 3;  //minlength
         var my = 2000;
         var remarks = $("#remarks").val(); 
         var len = remarks.length;
          if(len < mx ||len >my){
      swal({
							type: 'warning',
							title: 'Oops...',
							text: 'Remarks should be between ' +mx+ ' and ' +my+ ' Characters,digits or Special Characters',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						});
			document.getElementById("remarks").value = "";
 }
}

		           var specilaimg = "";
                function getFileData(input) {   
                if (input.files && input.files[0]) {
                  // console.log(input.files[0]);
                     if(input.files[0].size > 1000000){
                    alert("Please Upload Image less than 1 MB");
                    }else {
                      var fileName = input.files[0].name;
                     //  $("#filep").val(fileName);
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        specilaimg = e.target.result;
                        document.getElementById("blahs").height = "100";
                        document.getElementById("blahs").width = "100";
                        $('#blahs').attr('src', e.target.result);  
                    }
                    reader.readAsDataURL(input.files[0]);
                }
                }
                }

 $("#clearpage").click(function(){ 
		 clearpge();
});	

$("#survey_submit").click(function(){  
    save_submit();
		  });


    var roleid = window.localStorage.getItem("roleid"); 
    //console.log("surveyroleid",roleid);

       if(roleid=="1"){
        $("#txtshow").hide();
        
     }  
</script>