<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style>
  .box {
	float: left;
	padding: 50px 0px;
}

.clearfix::after {
	clear: both;
	display: table;
}

.options {
	margin: 5px 0px 0px 0px;
	float: left;
}

.pagination {
	float: right;
}

.pagination a {
	color: black;
	float: left;
	padding: 8px 16px;
	text-decoration: none;
	transition: background-color .3s;
	border: 1px solid #ddd;
	margin: 0 4px;
}

.pagination a.activepage {
	background-color: #4CAF50;
	color: white;
	border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {
	background-color: #ddd;
}
.file {
  visibility: hidden;
  position: absolute;
}

@media screen and (max-width: 480px){

a {
  font-size: 8px;
}
.btn{
  font-size: 9px;
}
}
</style>
<script src="<?php echo base_url(); ?>api/user_creation.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>
 <!--**********************************
            Content body start
        ***********************************-->
        <div class="ajax-loader">
            <img src="<?php echo base_url(); ?>assets\images/loader.gif" class="img-responsive" />
        </div>
        <div class="content-bodys">
            <div class="container-fluid" style="padding-top:0px;">
            <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="breadcrumb-range-picker">
                            <span><i class="icon-calender"></i></span>
                            <span class="ml-1">Home</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">User List</a></li>
                        </ol>
                    </div>
                </div>
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card" id="pincodename">
                            <div class="card-header">
                                <h4 class="card-title">User Creation Form</h4>
                                <button type="submit" class="btn btn-primary" id="listview"> Back to list
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Add"><i
                                            class="fa fa-undo color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Full Name*</label>
                                                <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter Full Name" value="" onblur="fullnm_validation()" maxlength="30" autocomplete= "off" required>
                                            </div>

                                          <div class="form-group col-md-6">
                                                <label>Email Id*</label>
                                                <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email Id" value="" onblur="email_validation()" maxlength="60"  autocomplete= "off" required>
                                            </div>
                                        </div>

                                          <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Mobile No*</label>
                                                <input type="text" class="form-control" id="mobile_no" name="mobile_no" placeholder="Enter Mobile No" value="" onblur="mobnum_validation()" maxlength="10"  autocomplete= "off" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Roles*</label>
                                                  <select id="roles" name="roles" class="form-control select2" required>
                                                  </select> 
                                            </div>
                                        </div>

                                       
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>User Name*</label>
                                                <input type="text" class="form-control" id="username" name="username" placeholder="Enter User Name" value="" onblur="usernm_validation()"  autocomplete= "off" maxlength="30" required>
                                            </div>

                                          <div class="form-group col-md-6">
                                                <label>Password*</label>
                                                <input type="text" class="form-control" id="password" name="password" placeholder="Enter Password" value="" onblur="password_validation()" autocomplete= "off" maxlength="12" required>
                                            </div>
                                        </div>
                                        
                                       
                                         <input type="submit" id="user_submit" name="user_submit" value="Submit" class="btn btn-primary"/>  
                                            <input type="hidden" name="userid" id="userid" />
                                       <input type="reset" id="clearpage" name="Reset" class="btn btn-secondary" value="Clear">                              
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <!--**********************************
            Content body end
        ***********************************-->


                    
        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body" style="padding-top: 0rem !important;">
            <div class="container-fluid">
               
                <!-- row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card" id="listhide">
                            <div class="card-header">
                                <h4 class="card-title">User List</h4>
                                <button type="submit" class="btn btn-primary"  id="txtshow"> Create  User
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Create User"><i
                                            class="fa fa-plus-circle color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border : 1;">
                                        <thead>
                                        <tr>
                                        <th>Sl No</th>
                                        <th>Name</th>
                                        <th>Email Id</th>
                                        <th>Mobile No</th>
                                        <th class="action">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="allusers">
                                        </tbody> 
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function(){
        var userid = window.localStorage.getItem("userid");
        if(userid == "" || userid == null || userid == undefined)
        {
            window.location="<?php echo base_url();?>"; 
        } 
        else {
            $("#pincodename").hide("");
            $('.select2').select2();
             getalluserdata();
             getallrolesdata();
        }
        });


        $("#txtshow").click(function () {        
                $("#pincodename").show("");         
                $("#listhide").hide(""); 
        });

        $("#listview").click(function () {  
            location.reload();       
        });

 
 function fullnm_validation(){
     var  mx = 3;  
        var my = 30;      
        var full_name =$("#full_name").val();
        var len = full_name.length;
        var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;

     if (full_name  != "") 
     {
      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Full Name should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("full_name").value = "";
    }
    else if(!Checkregex.test(full_name)){
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("full_name").value = "";
		           }else{
                       return true;
                   }
	          });					
    }
   }
 }

  function email_validation()
 {
       var  mx = 12;  //minlength
       var my = 60; //maxlength
       var mail =$("#email").val();
       var len = mail.length;

    var Checkregex = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

     if (mail  != "") 
     {
      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Email ID should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("email").value = "";
    }
    else if(!Checkregex.test(mail)){
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("email").value = "";
		           }else{
                       return true;
                   }
	          });					
    }
   }
 }

 function mobnum_validation(){
        var  mx = 10;  
        var mobile_no =$("#mobile_no").val();
        var len = mobile_no.length;
        if (mobile_no  != "") 
		{
      if(len < mx ||len > mx){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Mobile Number should be ' +mx+ ' Digits',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("mobile_no").value = "";
    }
    else{
           
 				var Checkregex = /^[0]?[6789]\d{9}$/;
				if (!Checkregex.test(mobile_no))
				{
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Please Enter Valid Mobile Number...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("mobile_no").value = "";
		           }else{
                       return true;
                   }
	          });				
        	}
    }
   }
 }

 function usernm_validation()
 {
       var  mx = 3;  
        var my = 30;      
        var username =$("#username").val();
        var len = username.length;
        if (username  != "") 
		{
      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Username should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("username").value = "";
    }
    else{
           
			var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;
				if (!Checkregex.test(username))
				{
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("username").value = "";
		           }else{
                       return true;
                   }
	          });				
        	}
		
    }
}
 }

 function password_validation()
 {
       var  mx = 6;  
        var my = 12;      
        var password =$("#password").val();
        var len = password.length;
        if (password  != "") 
		{
      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Password should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("password").value = "";
    }
    else{
           
			var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;
				if (!Checkregex.test(password))
				{
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("password").value = "";
		           }else{
                       return true;
                   }
	          });				
        	}	
    }
}
 }

  
 $("#clearpage").click(function(){ 
		 clearpge();
});	

$("#user_submit").click(function(){   console.log("circlesave");
    save_submit();
		  });

</script>