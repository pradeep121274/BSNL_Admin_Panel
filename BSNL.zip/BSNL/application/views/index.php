<style>
    .body {
        background-image: linear-gradient(blue, light blue);
        /* background-image: url(assets/images/BSNL.jpeg); */
    background-repeat: no-repeat;
    background-size: 100% 100%;
    }
    @media only screen and (max-width: 1199px) {
  img {
    height: 97px !important;
    width: 97px !important;
}
.welcome-content{
  padding: 0px !important;

} 
.auth-form {
    padding: 29px 50px !important;
}
    }
.frontdiv{
    padding:8%;
}
.frontdiv .card {
  box-shadow: 0 4px 80px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 80%;
}

.frontdiv.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.frontdiv.container {
  padding: 2px 10px;
}
.card-title {
    text-align: center;
}
</style>
<script src="<?php echo base_url(); ?>api/signin.js"></script>
<script src="<?php echo base_url(); ?>api/centralApi.js"></script>

    <!-- Sweet Alert -->
<link href="<?php echo base_url(); ?>assets/sweet-alert2/sweetalert2.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/sweet-alert2/sweetalert2.min.js"></script>
    <!-- <script src="<?php echo base_url(); ?>assets/pages/sweet-alert.init.js"></script> -->
<!-- <script type="text/javascript">
            window.history.forward();
    </script> -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
<link type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
    <div class="frontdiv" style="background-image: url('assets/images/BSNL.jpeg');background-repeat:no-repeat;background-size: 100% 100%; height:100%;text-align: -webkit-center;">
    <h1 style="color: white; text-align: center; margin-top: 20px;margin-bottom: 30px;">Welcome to BSNL</h1>
        <div class="row">
            <div class="col-4">
                <div class="frontdiv container">
                    <div class="frontdiv card" onclick="createItem(1);">
                        <h5 class="frontdiv card-title">Phase 1</h5>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="container">
                    <div class="frontdiv card" onclick="createItem(2);">
                        <h5 class="frontdiv card-title">Phase 2</h5>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="frontdiv container">
                    <div class="frontdiv card" onclick="createItem(3);">
                        <h5 class="frontdiv card-title">Phase 3</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- <div class="ajax-loader">
    <img src="<?php echo base_url(); ?>assets/images/loader.gif" class="img-responsive" />
</div> -->

<div class="authincation h-100 logonpgcolor" style="display:none;">
        <div class="container">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-10">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-6">
                                <div class="welcome-content">
                                    <div class="brand-logo" style="text-align: center;">
                                        <img src="<?php echo base_url();?>assets/images/BSNL_logo.png" alt="logo" width="250px" height="250px"/>
                                        <!-- <h1 style="color: #2bb294;">BSNL</h1> -->
                                    </div>
                                    <!-- <div class="brand-logo">
                                        <a href="<?php echo base_url();?>index.php/">BSNL</a>
                                    </div> -->
                                    <h3 class="welcome-title" style="color: blue;">Welcome to BSNL</h3>
                                    <!-- <div class="intro-social">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                        </ul>
                                    </div> -->
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4 txtcolor">Sign in your account</h4>
                                        <div class="form-group">
                                            <label><strong class="txtcolor">User Name</strong></label>
                                            <input type="text" class="form-control" id="email" autocomplete="off" >
                                        </div>
                                        <div class="form-group">
                                            <label><strong class="txtcolor">Password</strong></label>
                                            <input type="password" class="form-control" id="passWord" autocomplete="off">
                                        </div>
                                        <div class="form-row d-flex justify-content-between mt-4 mb-2">
                                            <!-- <div class="form-group">
                                                <div class="form-check ml-2">
                                                    <input class="form-check-input" type="checkbox" id="basic_checkbox_1">
                                                    <label class="form-check-label" for="basic_checkbox_1">Remember me</label>
                                                </div>
                                            </div> -->
                                        </div>
                                        <div class="text-center">
                                            <input type="submit" value="Sign in" id="submitButton" class="btn btn-primary btn-block" onclick=loginUser(); style="padding-top: 13px;" />
                                            <!-- <a class="btn btn-primary btn-block" id="submitButton" onclick=loginUser(); style="padding-top: 13px;"> Sign in</a> -->
                                        </div>
                                        <!-- <div class="form-group" style="margin-top: 25px;">
                                            <a href="<?php echo base_url();?>forgotpassword">Forgot Password?</a>
                                        </div> -->
                                    <!-- <div class="new-account mt-3">
                                        <p>Don't have an account? <a class="text-primary" href="<?php echo base_url();?>index.php/Home/signup">Sign up</a></p>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>

        <script>

           var baseurl = "<?php echo base_url();?>";
           function loginUser(){ //console.log("base",baseurl);
                login(baseurl);
           }

           $('#passWord').keypress(function (e){
                if(e.keyCode == 13 ) $('#submitButton').click();
            });
            function createItem(val) {
                localStorage.setItem("apiVal", val);
                document.getElementsByClassName('authincation h-100 logonpgcolor')[0].style.display = 'block';
                document.getElementsByClassName('frontdiv')[0].style.display = 'none';
            }
       </script>