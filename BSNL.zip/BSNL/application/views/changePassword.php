
<script src="<?php echo base_url(); ?>api/changePassword.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>

 <!-- Sweet Alert -->
<link href="<?php echo base_url(); ?>assets/sweet-alert2/sweetalert2.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/sweet-alert2/sweetalert2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/pages/sweet-alert.init.js"></script>

 <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-bodys">
            <div class="container-fluid" style="padding-top:0px;">
            <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="breadcrumb-range-picker">
                            <span><i class="icon-calender"></i></span>
                            <span class="ml-1">Home</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Change Password</a></li>
                        </ol>
                    </div>
                </div>
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-4 col-xxl-4">
                    </div>
                    <div class="col-xl-4 col-xxl-4">
                        <div class="card" id="categoryname">
                            <div class="card-header">
                                <h4 class="card-title">Change Password</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form>
                                        <div class="form-row">
                                            <input type="hidden" id="hiddensubtypeid" >
                                              <div class="form-group col-md-12">
                                            <label><strong class="txtcolor">Enter Email</strong></label>
                                            <input type="email" id="email" class="form-control" placeholder="hello@example.com" onblur="email_validation()" autocomplete="off">
                                        </div>
                                            <div class="form-group col-md-12">
                                                <label><strong class="txtcolor">Current Password</strong></label>
                                                <input type="text" class="form-control" id="oldPassword" placeholder="Enter the Current Password" onblur="pass_validation()" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label><strong class="txtcolor">New Password</strong></label>
                                                <input type="text" class="form-control" id="newPassword" placeholder="Enter the New Password" onblur="newpass_validation()" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label><strong class="txtcolor">Confirm Password</strong></label>
                                                <input type="text" class="form-control" id="confirmPassword" placeholder="Enter Confirm Password" onblur="cnfpass_validation()" autocomplete="off">
                                            </div>
                                            
                                        </div>
                                        <a class="btn btn-primary" id="submitButton" onclick=changePassword();>Submit</a>
                                        <input type="reset" class="btn btn-secondary" value="Clear">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-xxl-4">
                    </div>
                </div>

                
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
    <script>

         var baseurl = "<?php echo base_url();?>";
                 $(document).ready(function(){
            	var userid = localStorage.getItem("userid");
                if(userid == "" || userid == null)
                {
                    window.location="<?php echo base_url();?>Home"; 
                } 
        });
           function changePassword(){
            changepass(baseurl);
           }

 function email_validation(){
            var  mx = 12;  //minlength
            var my = 60; //maxlength
            var mail =$("#email").val();
            var len = mail.length;
            if(len < mx ||len >my){
            swal({
                type:'warning',
                title:'oops!...',
                text:'Email should be between ' +mx+ ' and ' +my+ ' Characters or Digits',
                allowOutsideClick: false,
                confirmButtonText: "OK"
            });
                document.getElementById("email").value = "";
               } else {
                var mobno = $("#email").val();
		if (mobno != "") 
		{
				var CheckMobileNo = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
				if (!CheckMobileNo.test(mobno)) 
				{
					swal({
							type: 'error',
							title: 'Oops...',
							text: 'Invalid Email Address...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						})
						document.getElementById("email").value = "";
						//return false;
				}
				else
			{
				return true;
			} 
		}
        }
 }

function pass_validation(){
        var  mx = 6;  //minlength
  var my = 12; //maxlength
var staffpwd =$("#oldPassword").val();
var len = staffpwd.length;
 if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Current Password should be between ' +mx+ ' and ' +my+ ' Characters or Digits',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("oldPassword").value = "";
 }
 }

 function newpass_validation(){
        var  mx = 6;  //minlength
  var my = 12; //maxlength
var staffpwd1 =$("#newPassword").val();
var len1 = staffpwd1.length;
 if(len1 < mx ||len1 > my){
      swal({
          type:'warning',
          title:'oops!...',
          text:' New Password should be between ' +mx+ ' and ' +my+ ' Characters or Digits',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("newPassword").value = "";
 }
 }

 function cnfpass_validation(){
        var  mx = 6;  //minlength
        var my = 12; //maxlength
        var staffpwd2 = $("#confirmPassword").val();
        var len2 = staffpwd2.length;
        if(len2 < mx ||len2 >my){
         swal({
          type:'warning',
          title:'oops!...',
          text:'Confirm Password should be between ' +mx+ ' and ' +my+ ' Characters or Digits',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("confirmPassword").value = "";
 }
 }
    </script>