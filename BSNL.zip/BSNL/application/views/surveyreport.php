<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.min.js"></script>


<style>
  .box {
	float: left;
	padding: 50px 0px;
}

.clearfix::after {
	clear: both;
	display: table;
}

.options {
	margin: 5px 0px 0px 0px;
	float: left;
}

.pagination {
	float: right;
}

.pagination a {
	color: black;
	float: left;
	padding: 8px 16px;
	text-decoration: none;
	transition: background-color .3s;
	border: 1px solid #ddd;
	margin: 0 4px;
}

.pagination a.activepage {
	background-color: #4CAF50;
	color: white;
	border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {
	background-color: #ddd;
}
.file {
  visibility: hidden;
  position: absolute;
}

.srch{
    border-bottom: none;
}

.logocls{
    width: 150px;
    height: 120px;
}
@media only screen and (max-width: 600px) {
  .curdte {
    float: unset !important;
    text-align: -webkit-center !important;
  }
  div#curdte1{
   text-align: -webkit-center;
  }
}
</style>
<script src="<?php echo base_url(); ?>api/surveyreport.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>
 <!--**********************************
            Content body start
        ***********************************-->
        <div class="ajax-loader">
            <img src="<?php echo base_url(); ?>assets/images/loader.gif" class="img-responsive" />
        </div>
        <div class="content-bodys">
            <div class="container-fluid" style="padding-top:0px;">
            <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="breadcrumb-range-picker">
                            <span><i class="icon-calender"></i></span>
                            <span class="ml-1">Home</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Survey Report</a></li>
                        </ol>
                    </div>
                </div>
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card" id="pincodename">
                            <!-- <div class="card-header">
                                <h4 class="card-title"></h4> -->
                                <!-- <button type="submit" class="btn btn-primary" id="listview"> Back to list
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Add"><i
                                            class="fa fa-undo color-muted addclr"></i> </a>
                                </span> 
                                </button> -->
                            <!-- </div> -->
                            <div class="card-body">
                                <div class="basic-form">
                                        <div class="form-row">
                                           <div class="form-group col-md-4">
                                                <label>Start Date</label>
                                                <input type="text" id="start_date" name="start_date"  class="form-control border-input" placeholder="Select Start date" autocomplete="off" onchange ="date_check();" required>
                                            </div>

                                            <div class="form-group col-md-4">
                                                <label>End Date</label>
                                                <input type="text" id="end_date" name="end_date"  class="form-control border-input" placeholder="Select End date" autocomplete="off" onchange ="date_check();" required>
                                            </div>
                                        </div>

                                         <div class="form-row">
                                             <!-- <div class="form-group col-md-4">
                                                <label>Zone Name</label>
                                                <select id="zone_name" name="zone_name" class="form-control select2" required></select>
                                            </div> -->

                                             <div class="form-group col-md-4">
                                                <label>Circle Name</label>
                                                <select id="circle_name" name="circle_name" class="form-control select2" required onChange="getssadata();"></select>
                                            </div>

                                             <div class="form-group col-md-4">
                                                <label>SSA Name</label>
                                                <select id="ssa_name" name="ssa_name" class="form-control select2" required></select>
                                            </div>
                                        </div>

                                         <!-- <div class="form-row">
                                             <div class="form-group col-md-4">
                                               <label>Survey Report Signoff*</label>
                                                    <select id="survey_rep" class="form-control select2" required>
                                                    <option>-- ALL --</option>
                                                    <option value='Yes'>Yes</option>
                                                    <option value='No'>No</option></select>
                                            </div>

                                             <div class="form-group col-md-4">
                                              <label>Report Upload Status*</label>
                                                <select id="rep_status" class="form-control select2" required>
                                                <option>-- ALL --</option>
                                                <option value='Yes'>Yes</option>
                                                <option value='No'>No</option>
                                                </select>
                                            </div>
                                        </div> -->

                                          <button id="search" class="btn btn-primary" onclick=searchList();>Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


                    
        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body" style="padding-top: 0rem !important;">
            <div class="container-fluid">
               
                <!-- row -->
                <div class="row">
                 <div class="col-12 exprt">
                     <a class="btn btn-primary" id="exportBtn1" style="margin-top: 15px;">Export to Excel</a>
                     <!-- <a class="btn btn-primary" id="pdfBtn1" style="margin-top: 15px;">Export to PDF</a> -->
                 </div>
                    <div class="col-12">
                        <div class="card" id="reportTab">
                            <div class="card-header">
                            <div class="col-md-12 col-sm-12">
                              <div class ="row" style="place-content: center;">
                                     <p class="curdte" id="datecurrent"></p>
                              </div>                          
                            </div>
                               
                        </div>
                                         
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border = 1px;">
                                        <thead>
                                        <tr>
                                        <th>Sl No</th>
                                        <th>Zone</th>
                                        <th>Circle</th>
                                        <th>SSA</th>
                                        <th>Site Type </th>
                                        <th>Survey Planned Date</th>
                                        <th>Survey Status</th>
                                        <th>Survey Completed Date</th>
                                        <th>Report Signoff</th>
                                        <th>Upload Status</th>
                                        <th>HFCL Remarks</th>
                                        <th>Bsnl Remarks</th>
                                        </tr>
                                        </thead>
                                        <tbody id="allusers">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function(){
         	var userid = window.localStorage.getItem("userid");
            if(userid == "" || userid == null || userid == undefined)
            {
                window.location="<?php echo base_url();?>"; 
            } else {
             $('.select2').select2();               
         	getcurrentdate();
            //getzonedata();
            getcircledata();
           // getssadata();
         }
        });

     $("#exportBtn1").click(function(){
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            var yyyy = today.getFullYear();

            today = dd + '-' + mm + '-' + yyyy;
           // console.log(today);

                var reportdt = $("#datecurrent").html();
                var filename = "Survey_Report_"+reportdt;

                TableToExcel.convert(document.getElementById("reportTab"), {
                    name: filename+".xlsx",
                    sheet: {
                    name: "Sheet1"
                    }
                });
        });

// $("#pdfBtn1").click(function(){

// var today = new Date();
// var dd = String(today.getDate()).padStart(2, '0');
// var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
// var yyyy = today.getFullYear();

// today = dd + '-' + mm + '-' + yyyy;
// console.log(today);

//     var filename = "Customer_Report_"+today;

//     var pdf = new jsPDF('l', 'pt', 'letter');
//     // source can be HTML-formatted string, or a reference
//     // to an actual DOM element from which the text will be scraped.
//     source = $('#reportTab')[0];

//     // we support special element handlers. Register them with jQuery-style 
//     // ID selector for either ID or node name. ("#iAmID", "div", "span" etc.)
//     // There is no support for any other type of selectors 
//     // (class, of compound) at this time.
//     specialElementHandlers = {
//         // element with id of "bypass" - jQuery style selector
//         '#bypassme': function (element, renderer) {
//             // true = "handled elsewhere, bypass text extraction"
//             return true
//         }
//     };
//     margins = {
//         top: 10,
//         bottom: 10,
//         left: 10,
//         width: 300
//     };
//     // all coords and widths are in jsPDF instance's declared units
//     // 'inches' in this case
//     pdf.fromHTML(
//         source, // HTML string or DOM elem ref.
//         margins.left, // x coord
//         margins.top, { // y coord
//             'width': margins.width, // max width of content on PDF
//             'elementHandlers': specialElementHandlers
//         },

//         function (dispose) {
//             // dispose: object with X, Y of the last line add to the PDF 
//             //          this allow the insertion of new lines after html
//             pdf.save(filename+'.pdf');
//         }, margins
//     );
// });
    
 $("#clearpage").click(function(){
		 clearpage();
});	


	function date_check(){
        var srtdte = $('#start_date').val();
        var enddte = $('#end_date').val();
    var todaydte = new Date();
	var dd = String(todaydte.getDate()).padStart(2, "0");
	var mm = String(todaydte.getMonth() + 1).padStart(2, "0"); //January is 0!
	var yyyy = todaydte.getFullYear();

	todaydte = dd + "-" + mm + "-" + yyyy;
   // console.log('---->todaydte',todaydte);

            if(srtdte > todaydte){ 
                  swal({
						type: "error",
						title: "Error...",
						text: "Start date must be less than or equal to today's date",
						allowOutsideClick: false,
						confirmButtonText: "OK"
						});
                    $("#start_date").val(todaydte);
            }else{
            if(srtdte > enddte){
                swal({
						type: "error",
						title: "Error...",
						text: "End date must be greater than start date",
						allowOutsideClick: false,
						confirmButtonText: "OK"
						});
                    $("#end_date").val(todaydte);          
                  } 
            }


            if(enddte > todaydte){  
                swal({
						type: "error",
						title: "Error...",
						text: "End date must be less than or equal to today's date",
						allowOutsideClick: false,
						confirmButtonText: "OK"
						});
                    $("#end_date").val(todaydte);
            }     
    }

    // $("#searchtxt").keyup(function(){
    //        searchlstbydate();
    // });

    function searchList(){ 
        SurveyReportList();
    }

</script>