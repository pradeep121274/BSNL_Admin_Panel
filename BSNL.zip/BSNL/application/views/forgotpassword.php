<script src="<?php echo base_url(); ?>api/forgotpassword.js"></script>
<script src="<?php echo base_url(); ?>api/centralApi.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
<link type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">

<!-- Sweet Alert -->
<link href="<?php echo base_url(); ?>assets/sweet-alert2/sweetalert2.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/sweet-alert2/sweetalert2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/pages/sweet-alert.init.js"></script>
<div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-10">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-6">
                                <div class="welcome-content">
                                    <div class="brand-logo" style="text-align: center;">
                                        <img src="<?php echo base_url();?>assets/images/bsnl_title.png" alt="logo" style="width: 200px; height: 200px;" />
                                    </div>
                                     <!-- <div class="brand-logo">
                                        <a href="index.html">Bsnl</a>
                                    </div>   -->
                                    <h3 class="welcome-title">Welcome to BSNL</h3>
                                    <!-- <div class="intro-social">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                        </ul>
                                    </div> -->
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="auth-form">
                                    <h4 class="text-center mb-4 txtcolor">Forgot Password?</h4>
                     <form action="<?php echo base_url();?>">                                        
                                        <div class="form-group">
                                            <label><strong class="txtcolor">Enter Email</strong></label>
                                            <input type="email" id="email" class="form-control" placeholder="hello@example.com" onblur="email_validation()" autocomplete="off">
                                        </div>
                                        <div class="text-center">
                                            <a class="btn btn-primary btn-block" id="submitButton" onclick=sendPassword(); style="padding-top: 13px;">Submit</a>
                                        </div>
                                        <div class="text-center" style="margin-top: 15px;">
                                            <a href="<?php echo base_url();?>">Back to login?</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>

        <script>
           

            var baseurl = "<?php echo base_url();?>";
                function sendPassword(){
                forgotPassword(baseurl);
           }
            
           $('#email').keypress(function (e){
                if(e.keyCode == 13 ) $('#submitButton').click();
            });
           

    function email_validation(){
            var  mx = 12;  //minlength
            var my = 60; //maxlength
            var mail =$("#email").val();
            var len = mail.length;
            if(len < mx ||len >my){
            swal({
                type:'warning',
                title:'oops!...',
                text:'Email should be between ' +mx+ ' and ' +my+ ' Characters or Digits',
                allowOutsideClick: false,
                confirmButtonText: "OK"
            });
                document.getElementById("email").value = "";
               } else {
                var mobno = $("#email").val();
		if (mobno != "") 
		{
				var CheckMobileNo = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
				if (!CheckMobileNo.test(mobno)) 
				{
					swal({
							type: 'error',
							title: 'Oops...',
							text: 'Invalid Email Address...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						})
						document.getElementById("email").value = "";
						//return false;
				}
				else
			{
				return true;
			} 
		}
        }
 }
       </script>