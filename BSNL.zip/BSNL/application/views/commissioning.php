<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style>
    .box {
        float: left;
        padding: 50px 0px;
    }

    .clearfix::after {
        clear: both;
        display: table;
    }

    .options {
        margin: 5px 0px 0px 0px;
        float: left;
    }

    .pagination {
        float: right;
    }

    .pagination a {
        color: black;
        float: left;
        padding: 8px 16px;
        text-decoration: none;
        transition: background-color .3s;
        border: 1px solid #ddd;
        margin: 0 4px;
    }

    .pagination a.activepage {
        background-color: #4CAF50;
        color: white;
        border: 1px solid #4CAF50;
    }

    .pagination a:hover:not(.active) {
        background-color: #ddd;
    }

    .file {
        visibility: hidden;
        position: absolute;
    }

    @media screen and (max-width: 480px) {

        a {
            font-size: 8px;
        }

        .btn {
            font-size: 9px;
        }
    }
</style>
<script src="<?php echo base_url(); ?>api/commissioning.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>
<!--**********************************
            Content body start
        ***********************************-->
<div class="ajax-loader">
    <img src="<?php echo base_url(); ?>assets/images/loader.gif" class="img-responsive" />
</div>
<div class="content-bodys">
    <div class="container-fluid" style="padding-top:0px;">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="breadcrumb-range-picker">
                    <span><i class="icon-calender"></i></span>
                    <span class="ml-1">Home</span>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Installation & Configuration List</a></li>
                </ol>
            </div>
        </div>

        <!-- row -->
        <div class="row">
            <div class="col-12">
                <div class="card" id="listhide">
                    <div class="card-header">
                        <h4 class="card-title">Installation & Configuration List</h4>
                        <button type="submit" class="btn btn-primary" id="txtshow"> Create Installation & Configuration 
                            <span>
                                <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Create Installation & Configuration "><i class="fa fa-plus-circle color-muted addclr"></i> </a>
                            </span>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border : 1;">
                                <thead>
                                    <tr>
                                        <th>Sl No</th>
                                        <th>SSA</th>
                                        <th>Site Type</th>
                                        <th>Region</th>
                                        <th>Circle</th>
                                        <th>Site Name</th>
                                        <th>Start Plan Date</th>
                                        <th>Installation Status</th>
                                        <th>Installation Date</th>
                                        <th>Config Completion Status</th>
                                        <th>Config Completion Date</th>
                                        <th>MPLS reachability and basic configuration</th>
                                        <th>Remarks</th>
                                        <th>Bsnl Remarks</th>
                                        <th class="action">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="allusers">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--**********************************
            Content body end
        ***********************************-->

  <!-- Start QuickView Remarks Modal Area -->
     <div class="modal fade productsQuickView" id="productsQuickView" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document" >
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><i class='fa fa-times'></i></span>
                    </button>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label style="font-size: 16px;font-weight: 600;">Remarks</label>
                            <textarea style="padding: 5px;" rows="5" cols="70" id="bsnlremarks" placeholder="Enter Remarks(if any)"></textarea>
                        </div>                                         
                    </div> 
                    <div class="form-row">
                        <input type="submit" id="remarks_submit" name="remarks_submit" value="Submit" class="btn btn-primary" onclick="submitRemarks();"/> 
                    </div> 
                </div>
            </div>
        </div>

        <!-- End QuickView Remarks Modal Area -->



<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body" style="padding-top: 0rem !important;">
    <div class="container-fluid">

        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card" id="pincodename">
                    <div class="card-header">
                        <h4 class="card-title">Installation & Configuration Form</h4>
                        <button type="submit" class="btn btn-primary" id="listview"> Back to list
                            <span>
                                <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Add"><i class="fa fa-undo color-muted addclr"></i> </a>
                            </span>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="basic-form">
                            <div class="form-row">
                                  <div class="form-group col-md-6">
                                    <label>SSA*</label>
                                    <select id="ssa_name" name="ssa_name"  class="form-control select2" required onChange="getallData();"></select> 
                                </div>
                                  <div class="form-group col-md-6">
                                    <label>Site Type*</label>
                                    <select id="site_type" class="form-control select2" required></select>
                                </div>
                            </div>

                            <div class="form-row">
                              <div class="form-group col-md-6">
                                    <label>Region*</label>
                                    <select id="region" name="region" class="form-control select2" required>
                                    </select> 
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Circle*</label>
                                    <select id="circle_name" name="circle_name"  class="form-control select2" required></select> 
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Site Name*</label>
                                    <input type="text" class="form-control" id="site_name" name="site_name" placeholder="Enter Site Name" value="" maxlength="30" onblur="sitenm_validation()" required autocomplete="off">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Start Plan Date*</label>
                                    <input type="text" class="form-control" id="rdate" name="rdate" placeholder="Select Installation Start Plan Date" value="" required>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Installation Status*</label>
                                    <select id="install_status" class="form-control select2" required>
                                        <option>-- Please Select --</option>
                                        <option value='Pending'>Pending</option>
                                        <option value='Completed'>Completed</option>
                                        <option value='In progress'>In progress</option>
                                        <option value='Hold'>Hold</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Installation Date*</label>
                                    <input type="text" class="form-control" id="vdate" name="vdate" placeholder="Select Installation Date" value="" required>
                                </div>
                                </div>

                                <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Config Completion Status*</label>
                                    <select id="commission_status" class="form-control select2" required>
                                        <option>-- Please Select --</option>
                                        <option value='Pending'>Pending</option>
                                        <option value='Completed'>Completed</option>
                                        <option value='In progress'>In progress</option>
                                        <option value='Hold'>Hold</option>
                                    </select>
                                </div>
                            
                            
                                <div class="form-group col-md-6">
                                    <label>Config Completion Date</label>
                                    <input type="text" class="form-control" id="vrdate" name="vrdate" placeholder="Select Config Completion Date" value="" required>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>MPLS reachability and basic configuration *</label>
                                    <select id="mpls_status" class="form-control select2" required>
                                        <option>-- Please Select --</option>
                                        <option value='Pending'>Pending</option>
                                        <option value='Completed'>Completed</option>
                                        <option value='In progress'>In progress</option>
                                        <option value='Hold'>Hold</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <label>Enter Remarks</label>
                                    <textarea rows="5" cols="170" id="remarks" onblur="remarks_validate()" placeholder="Enter Remarks(if Any)" required></textarea>
                                </div>
                            </div>
                            <input type="submit" id="commission_submit" name="commission_submit" value="Submit" class="btn btn-primary" />
                            <input type="hidden" name="commissionid" id="commissionid" />
                            <input type="reset" id="clearpage" name="Reset" class="btn btn-secondary" value="Clear">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
            Content body end
        ***********************************-->

<script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        var userid = window.localStorage.getItem("userid");
        if (userid == "" || userid == null || userid == undefined) {
            window.location = "<?php echo base_url(); ?>";
        } else {
            $("#pincodename").hide("");
             $('.select2').select2();
               getallzonedata();
               getallssadata();
               getcircledata();
               getallSiteTypedata();
               getallcommisiondata();
        }
    });


    $("#txtshow").click(function() {
        $("#pincodename").show("");
        $("#listhide").hide("");
    });

    $("#listview").click(function() {
        location.reload();
    });


    function sitenm_validation(){ 
         var  mx = 3;  //minlength
         var my = 30;
         var site_name = $("#site_name").val(); 
         var len = site_name.length;
          if(len < mx ||len >my){
      swal({
							type: 'warning',
							title: 'Oops...',
							text: 'Site Name should be between ' +mx+ ' and ' +my+ ' Characters,digits or Special Characters',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						});
			document.getElementById("site_name").value = "";
 }
}

function remarks_validate(){ 
         var  mx = 3;  //minlength
         var my = 5000;
         var remarks = $("#remarks").val(); 
         var len = remarks.length;
          if(len < mx ||len >my){
      swal({
							type: 'warning',
							title: 'Oops...',
							text: 'Remarks should be between ' +mx+ ' and ' +my+ ' Characters,digits or Special Characters',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						});
			document.getElementById("remarks").value = "";
 }
}

    $("#clearpage").click(function() {
        clearpge();
    });

    $("#commission_submit").click(function() {
        save_submit();
    });

        var roleid = window.localStorage.getItem("roleid"); 
    if(roleid=="1"){
        $("#txtshow").hide();
     }  
</script>