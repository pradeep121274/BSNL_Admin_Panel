<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style>
  .box {
	float: left;
	padding: 50px 0px;
}

.clearfix::after {
	clear: both;
	display: table;
}

.options {
	margin: 5px 0px 0px 0px;
	float: left;
}

.pagination {
	float: right;
}

.pagination a {
	color: black;
	float: left;
	padding: 8px 16px;
	text-decoration: none;
	transition: background-color .3s;
	border: 1px solid #ddd;
	margin: 0 4px;
}

.pagination a.activepage {
	background-color: #4CAF50;
	color: white;
	border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {
	background-color: #ddd;
}
.file {
  visibility: hidden;
  position: absolute;
}

@media screen and (max-width: 480px){

a {
  font-size: 8px;
}
.btn{
  font-size: 9px;
}
}
</style>
<script src="<?php echo base_url(); ?>api/central_location.js"></script>
<!-- Datatable -->
<script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>
 <!--**********************************
            Content body start
        ***********************************-->
        <div class="ajax-loader">
            <img src="<?php echo base_url(); ?>assets\images/loader.gif" class="img-responsive" />
        </div>
        <div class="content-bodys">
            <div class="container-fluid" style="padding-top:0px;">
            <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="breadcrumb-range-picker">
                            <span><i class="icon-calender"></i></span>
                            <span class="ml-1">Home</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Central Location List</a></li>
                        </ol>
                    </div>
                </div>
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-12 col-xxl-12">
                        <div class="card" id="pincodename">
                            <div class="card-header">
                                <h4 class="card-title">Central Location Form</h4>
                                <button type="submit" class="btn btn-primary" id="listview"> Back to list
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Add"><i
                                            class="fa fa-undo color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">

                                    <div class="form-row">
                                         <div class="form-group col-md-6">
                                                <label>SSA Name*</label>
                                                   <select id="ssa_name" name="ssa_name" class="form-control select2" required onChange="getallData();"></select>
                                            </div>
                                          <div class="form-group col-md-6">
                                                <label>Site Type*</label>
                                                   <select id="site_type" name="site_type" class="form-control select2" required></select>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Zone*</label>
                                              <select id="zone_name" name="zone_name" class="form-control select2" required></select> 
                                            </div>

                                          <div class="form-group col-md-6">
                                                <label>Circle Name*</label>
                                                <select id="circle_name" name="circle_name" class="form-control select2" required></select> 
                                            </div>
                                        </div>

                                     <div class="form-row">
                                         <div class="form-group col-md-6">
                                            <label>Site Name*</label>
                                             <input type="text" class="form-control" id="site_name" name="site_name" placeholder="Enter Site Name" value="" maxlength="30" onblur="sitenm_validation()" required>
                                            </div>
                                            </div>
                                            
                                     <div class="form-row">
                                        <div class="form-group col-md-6">
                                                <label>Consignee Details*</label>
                                                    <textarea rows="5" cols="80" id="consignee_details" onblur="consignee_validate()" placeholder="Enter Consignee Details" required></textarea>
                                            </div>
                                        </div>

                                         <input type="submit" id="centralloc_submit" name="centralloc_submit" value="Submit" class="btn btn-primary"/>  
                                            <input type="hidden" name="centralid" id="centralid" />
                                       <input type="reset" id="clearpage" name="Reset" class="btn btn-secondary" value="Clear">                              
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <!--**********************************
            Content body end
        ***********************************-->


                    
        

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body" style="padding-top: 0rem !important;">
            <div class="container-fluid">
               
                <!-- row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card" id="listhide">
                            <div class="card-header">
                                <h4 class="card-title">Central Location List</h4>
                                <button type="submit" class="btn btn-primary"  id="txtshow"> Create  Central Location
                                <span>
                                    <a href="javascript:void()" class="mr-4" data-toggle="tooltip" data-placement="top" title="Create Central Location"><i
                                            class="fa fa-plus-circle color-muted addclr"></i> </a>
                                </span> 
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-responsive-sm" id="example" class="display" style="min-width: 100%; border : 1;">
                                        <thead>
                                        <tr>
                                        <th>Sl No</th>
                                        <th>SSA Name</th>
                                        <th>Site Type</th>
                                        <th>Zone</th>
                                        <th>Circle Name</th>
                                        <th>Site Name</th>
                                         <th>Consignee Details</th>
                                        <th class="action">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody id="allusers">
                                        </tbody> 
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function(){
        var userid = window.localStorage.getItem("userid");
        if(userid == "" || userid == null || userid == undefined)
        {
            window.location="<?php echo base_url();?>"; 
        } 
        else {
            $("#pincodename").hide("");
            $('.select2').select2();
             getallzonedata();
             getcircledata();
             getssadata();
             getsitetypes();
             getAllCentrallocation();
        }
        });


        $("#txtshow").click(function () {        
                $("#pincodename").show("");         
                $("#listhide").hide(""); 
        });

        $("#listview").click(function () {  
            location.reload();       
        });

 function consignee_validate(){
     var  mx = 3;  
        var my = 3000;      
        var consignee_details =$("#consignee_details").val();
        var len = consignee_details.length;
        var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;

     if (consignee_details  != "") 
     {
      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Consignee Details should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("consignee_details").value = "";
    }
    else if(!Checkregex.test(consignee_details)){
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("consignee_details").value = "";
		           }else{
                       return true;
                   }
	          });					
    }
   }
 }

  function sitenm_validation(){
     var  mx = 3;  
        var my = 30;      
        var site_name =$("#site_name").val();
        var len = site_name.length;
        var Checkregex = /^([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|[a-zA-Z0-9\s]*$/;

     if (site_name  != "") 
     {
      if(len < mx ||len >my){
      swal({
          type:'warning',
          title:'oops!...',
          text:'Site Name should be between ' +mx+ ' and ' +my+ ' Characters, Digits or Special Characters',
          allowOutsideClick: false,
		  confirmButtonText: "OK"
      });
		document.getElementById("site_name").value = "";
    }
    else if(!Checkregex.test(site_name)){
						swal({
							type: 'error',
							title: 'Oops...',
							text: 'Accepts Only Alphabets, digits and Special Characters...!!!',
							allowOutsideClick: false,
							confirmButtonText: "OK"
						}).then((result) => {
		           if (result) { 
			     document.getElementById("site_name").value = "";
		           }else{
                       return true;
                   }
	          });					
    }
   }
 }

  
 $("#clearpage").click(function(){ 
		 clearpge();
});	

$("#centralloc_submit").click(function(){   
    save_submit();
		  });

</script>