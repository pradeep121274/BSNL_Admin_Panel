<script src="<?php echo base_url(); ?>api/profile.js"></script>
 
 
 <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-bodys">
            <div class="container-fluid" style="padding-top:0px;">
            <!-- <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="breadcrumb-range-picker">
                            <span><i class="icon-calender"></i></span>
                            <span class="ml-1">Home</span>
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)"></a>Home</li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">User Management</a></li>
                        </ol>
                    </div>
                </div> -->
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-4 col-xxl-4">
                    </div>
                    <div class="col-xl-4 col-xxl-4">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title" id="topmove">Edit Profile</h4>
                            </div>
                            <div class="card-body" >
                                <div class="basic-form" >
                                        <div class="form-row" >
                                            <input type="hidden" id="hiddensubtypeid" >
                                            <div class="form-group col-md-12" >
                                                <label>Name</label> 
                                                <input type="text" class="form-control" id="autoname" placeholder="Enter the Name" onkeyup="profileName(this.value)">
                                            </div>
                                        </div>
                                        <div class="form-row" >
                                            <div class="form-group col-md-12">
                                                <label>Email Id</label>
                                                <input type="email" class="form-control" id="autoemail" placeholder="Enter your Email Id">
                                            </div>
                                        </div>
                                        <div class="form-row" >
                                            <div class="form-group col-md-12">
                                                <label>Phone Number</label>
                                                <input type="text" class="form-control" id="automobile" >
                                            </div>
                                        </div>
                                        <!-- <input type="reset" class="btn btn-secondary" value="Clear" onclick="clearFields()">  -->
                                        <button class="btn btn-primary" onclick=updateUser();>Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-xxl-4">
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

<script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#namenoss").hide("");
            
        });


        $("#fields1").click(function () {        
                $("#namenoss").show("");        
           
    });

    $("#fields2").click(function () {        
                $("#namenoss").show("");        
           
    });

    $("#fields3").click(function () {        
                $("#namenoss").show("");        
           
    });


        $("#fields1").click( function() {
            $(window).scrollTop(0);
        });

        $("#fields2").click( function() {
            $(window).scrollTop(0);
        });

        $("#fields3").click( function() {
            $(window).scrollTop(0);
        });

    
    </script>

<script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
        <script>
            $(document).ready(function(){
            /* console.log("step1"); */
                /* var mobileno = "8217293722";
                 document.getElementById("automobile").value = mobileno;

                var name = "Anoop";
                document.getElementById("autoname").value = name;

                var email = "anoop@gmail.com";
                document.getElementById("autoemail").value = email;

                var pass = "*******";
                document.getElementById("autopass").value = pass; */
                var baseurl = "<?php echo base_url();?>";
                 editProfileData(baseurl);
                
            });

            function profileName(inputfname)
      {
          var alpha = /^[A-Za-z\s]+$/;
        if(inputfname != ""){
            if(inputfname.match(alpha))
          {
              return true;
          }else{
              alert('Please Enter Only Alphabets');
              document.getElementById("autoname").value = "";
              return false;
          }

        }  
      }

      $('#autoemail').blur(function () {
         var mobno = $("#autoemail").val();
 		if (mobno != "") {
 				var CheckMobileNo = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
 				    if (!CheckMobileNo.test(mobno)) {
						alert("Invalid Email Address");
 						$("#autoemail").focus();
 						document.getElementById("autoemail").value = "";
 						//return false;
 				}
 		}
  });


  $('#automobile').blur(function () {
        var pinno = $("#automobile").val();
            if (pinno != "") {
                    var CheckPinNo = /^[0-9_\s]+$/;
                    if (!CheckPinNo.test(pinno)) {
                            alert("It accepts only Numeric Value");
                            $("#automobile").focus();
                            document.getElementById("automobile").value = "";
                            //return false;
                    }
            }
        });


  $('#automobile').blur(function () {
         var mobno = $("#automobile").val();
 		if (mobno != "") {
 				var CheckMobileNo = /^[0]?[789]\d{9}$/;
 				if (!CheckMobileNo.test(mobno)) {
 						alert("Mobile number must be numeric and minimum and maximum 10 digit");
						$("#automobile").focus();
 						document.getElementById("automobile").value = "";
 						//return false;
 				}
		}
  }); 


  function clearFields() {
    document.getElementById("autoname").value=""
    document.getElementById("autoemail").value=""
    document.getElementById("automobile").value=""
}
  
        </script>
        