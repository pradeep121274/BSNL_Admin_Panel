<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="zxx">
<!--<![endif]-->
<head>
    <!-- <script type="text/javascript">
            window.history.forward();
    </script> -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>BSNL</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/jpg" sizes="16x16" href="<?php echo base_url(); ?>assets/images/bsnl_title.png">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/calender/calender.css">
    <link type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">

   <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!-- Material color picker -->
    <link href="<?php echo base_url(); ?>assets/vendor/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
    
    <script src="<?php echo base_url(); ?>api/centralApi.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>api/session_timer.js"></script>

    <!-- JS Grid -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/jsgrid/css/jsgrid.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/jsgrid/css/jsgrid-theme.min.css">

    <!-- sweet alert -->
    <link href="<?php echo base_url(); ?>assets/sweet-alert2/sweetalert2.css" rel="stylesheet" type="text/css">

    <script src="https://cdn.jsdelivr.net/gh/linways/table-to-excel@v1.0.4/dist/tableToExcel.js"></script>
</head>

<body>

   <!--*******************
        Preloader start
    ********************-->
    <div id="preloader"><div class="spinner"><div class="spinner-a"></div><div class="spinner-b"></div></div></div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo base_url();?>dashboard" class="brand-logo">
                <span class="logo-abbr"><img src="<?php echo base_url(); ?>assets/images/BSNL_logo.png" alt="" style="width: 50px;height: 50px;background: white;"></span>
                <span class="logo-compact">Artha</span>
                <span class="brand-title"> <img src="<?php echo base_url(); ?>assets/images/BSNL_logo.png" alt="" style="width: 80px;height: 80px;margin-left: 50px;background: white;"></span>
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="toggle-icon"><i class="icon-menu"></i></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
    <!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="header-left">
                        <div class="nav-item dropdown search_bar">
                            <div class="dropdown-menu">
                                <form class="form-inline">
                                    <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="collapse navbar-collapse justify-content-end">

                        <ul class="navbar-nav header-right">
                           
                            <li class="nav-item dropdown notification_dropdown">
                                <div class="dropdown-menu dropdown-menu-right">
                                    <div class="dropdown-header">
                                        <h5 class="notification_title">Notifications</h5>
                                    </div>
                                    <ul class="list-unstyled">
                                        <li class="media dropdown-item">
                                            <span class="text-primary"><i class="mdi mdi-chart-areaspline mr-3"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <div class="d-flex justify-content-between">
                                                        <h5>New order has been recieved</h5>
                                                    </div>
                                                    <p class="m-0">2 hours ago</p>
                                                </a>
                                                <i class="fa fa-angle-right"></i>
                                            </div>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="text-success"><i class="mdi mdi-chart-pie mr-3"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <div class="d-flex justify-content-between">
                                                        <h5>New customer is registered</h5>
                                                    </div>
                                                    <p class="m-0">3 hours ago</p>
                                                </a>
                                                <i class="fa fa-angle-right"></i>
                                            </div>
                                        </li>
                                        <li class="media dropdown-item">
                                            <span class="text-warning"><i class="mdi mdi-file-document mr-3"></i></span>
                                            <div class="media-body">
                                                <a href="#">
                                                    <div class="d-flex justify-content-between">
                                                        <h5>New Product has been uploaded</h5>
                                                    </div>
                                                    <p class="m-0">3 hours ago</p>
                                                </a>
                                                <i class="fa fa-angle-right"></i>
                                            </div>
                                        </li>
                                    </ul>
                                    <a class="all-notification" href="#">All Notifications</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <!-- <img id="defaultpreview"> -->
                                    <span id="user"></span>
                                </a>

                      

                                <div class="dropdown-menu dropdown-menu-right">    
                                   <a href="<?php echo base_url(); ?>changepassword" class="dropdown-item">
                                        <i class="mdi mdi-key"></i>
                                        <span>Change Password</span>
                                    </a>                              
                                    <a class="dropdown-item" onclick = "logout()">
                                        <i class="mdi mdi-power"></i>
                                        <span>Logout</span>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="quixnav scrllCss">
            <div class="quixnav-scroll">
                <ul class="metismenu" id="menu">
                   
                    <li><a href="<?php echo base_url();?>dashboard" aria-expanded="false"><i class="fa fa-home"></i><span class="nav-text">Dashboard</span></a></li>
                   
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-medkit"></i><span class="nav-text">Masters</span></a>
                        <ul aria-expanded="false">
                             <li><a href="<?php echo base_url();?>zone">Zone</a></li> 
                            <li><a href="<?php echo base_url();?>circle">Circle</a></li> 
                            <li><a href="<?php echo base_url();?>site_type">Site Type</a></li>
                            <li><a href="<?php echo base_url();?>ssa">SSA</a></li> 
                            <li><a href="<?php echo base_url();?>inventorymaster">Inventory</a></li>
                            <li><a href="<?php echo base_url();?>user_plane">User Plane Sites</a></li>
                            <li><a href="<?php echo base_url();?>central_location">Central location Sites</a></li>
                            <li><a href="<?php echo base_url();?>user_creation">User Creation</a></li>                            
                        </ul>
                    </li>

                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-user-circle"></i><span class="nav-text">Project Activities</span></a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo base_url();?>survey">Survey</a></li>
                              <li><a href="<?php echo base_url();?>material">Material Delivery</a></li> 
                              <li><a href="<?php echo base_url();?>inventory">Inventory Management</a></li>    
                              <li><a href="<?php echo base_url();?>commissioning">Installation & Configuration</a></li>  
                              <li><a href="<?php echo base_url();?>acceptance">Acceptance Test</a></li>    
                              <!-- <li><a href="<?php echo base_url();?>divisionreport">User Plane Sites</a></li>    
                              <li><a href="<?php echo base_url();?>driverreport">Central location Sites</a></li>                             -->
                        </ul>
                    </li>  
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-user-circle"></i><span class="nav-text">TICKETS</span></a>
                       <ul aria-expanded="false">
                            <li><a href="<?php echo base_url();?>label">Label</a></li>
                             <li><a href="<?php echo base_url();?>priority">Priority</a></li>
                             <li><a href="<?php echo base_url();?>department">Department</a></li> 
                             <li><a href="<?php echo base_url();?>status">Status</a></li>
                             <li><a href="<?php echo base_url();?>ticket">Create Ticket</a></li>                           
                       </ul>
                   </li>                    
                    <li>
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-book"></i><span class="nav-text">Reports</span></a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo base_url();?>surveyreport"><i class="fa fa-wpforms"></i> Survey Report</a></li>
                           <li><a href="<?php echo base_url();?>materialreport"><i class="fa fa-wpforms"></i> Material Delivery Report</a></li> 
                           <!-- <li><a href="<?php echo base_url();?>inventoryreport"><i class="fa fa-wpforms"></i> Inventory Report</a></li> -->
                           <li><a href="<?php echo base_url();?>commissioningreport"><i class="fa fa-wpforms"></i> Installation & Configuration Report</a></li>
                            <li><a href="<?php echo base_url();?>acceptancereport"><i class="fa fa-wpforms"></i> Acceptance Report</a></li>
                            <li><a href="<?php echo base_url();?>allstatusreport"><i class="fa fa-wpforms"></i> All Status Report</a></li>
                           <!-- <li><a href="<?php echo base_url();?>undeliveredmaterialreport"><i class="fa fa-wpforms"></i> Undelivered Material Report</a></li> -->
                        </ul>
                    </li> 
                    
                </ul>

                <ul class="metismenu" id="superadminmenu">
                      <!-- <li><a href="<?php echo base_url();?>dashboard" aria-expanded="false"><i class="fa fa-home"></i><span class="nav-text">Dashboard</span></a></li> -->
                        <!-- <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-user-circle"></i><span class="nav-text">Project Activities</span></a> -->
                        <ul aria-expanded="false">
                            <!-- <li><a href="<?php echo base_url();?>survey"> Survey</a></li> -->
                              <!-- <li><a href="<?php echo base_url();?>material">Material Delivery</a></li>  -->
                              <!-- <li><a href="<?php echo base_url();?>inventory">Inventory Management</a></li>     -->
                              <!-- <li><a href="<?php echo base_url();?>commissioning">Installation & Configuration</a></li>   -->
                              <!-- <li><a href="<?php echo base_url();?>acceptance">Acceptance Test</a></li>     -->
                        </ul>
                    </li> 
                    
                    <!-- <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="fa fa-book"></i><span class="nav-text">Reports</span></a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo base_url();?>surveyreport"><i class="fa fa-wpforms"></i> Survey Report</a></li>
                           <li><a href="<?php echo base_url();?>materialreport"><i class="fa fa-wpforms"></i> Material Delivery Report</a></li> 
                           <!-- <li><a href="<?php echo base_url();?>inventoryreport"><i class="fa fa-wpforms"></i> Inventory Report</a></li> -->
                           <!-- <li><a href="<?php echo base_url();?>commissioningreport"><i class="fa fa-wpforms"></i> Installation & Configuration Report</a></li>
                            <li><a href="<?php echo base_url();?>acceptancereport"><i class="fa fa-wpforms"></i> Acceptance Report</a></li>
                            <li><a href="<?php echo base_url();?>allstatusreport"><i class="fa fa-wpforms"></i> All Status Report</a></li> -->
                           <!-- <li><a href="<?php echo base_url();?>undeliveredmaterialreport"><i class="fa fa-wpforms"></i> Undelivered Material Report</a></li> -->
                        </ul>
                    </li>  
                    
                </ul>

            </div>
        </div> 
        <!--**********************************
            Sidebar end
        ***********************************-->

<?php echo $template['body'];?>
    
        <!--removeIf(production)-->
        
        <!--endRemoveIf(production)-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->
<!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p><!-- Copyright © --> Designed &amp; Developed by <a href="http://arthainfosystems.com/" target="_blank">Arthainfo Systems</a> 2022</p>
            </div>
        </div>
        <!--********************************** 
            Footer end
        ***********************************-->
    <!--**********************************
        Scripts
    ***********************************-->

    <!-- Required vendors -->
    
    <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <!-- Here is navigation script -->
    <script src="<?php echo base_url(); ?>assets/vendor/quixnav/quixnav.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/quixnav-init.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/custom.min.js"></script>
    <!--removeIf(production)-->
    <!-- Demo scripts -->
    <script src="<?php echo base_url(); ?>assets/js/styleSwitcher.js"></script>
    <!--endRemoveIf(production)-->

    <!-- Daterange picker library -->
    <script src="<?php echo base_url(); ?>assets/vendor/circle-progress/circle-progress.min.js"></script>

   <!-- Vectormap -->
    <script src="<?php echo base_url(); ?>assets/vendor/jqvmap/js/jquery.vmap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/jqvmap/js/jquery.vmap.world.js"></script>


    <!-- calender -->
    <script src="<?php echo base_url(); ?>assets/vendor/calender/calender.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/calender-init.js"></script>

    <!-- Chart Morris plugin files -->
    <script src="<?php echo base_url(); ?>assets/vendor/raphael/raphael.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/morris/morris.min.js"></script> 

    <script src="<?php echo base_url(); ?>assets/vendor/chart.js/Chart.bundle.min.js"></script>
    <!-- <script src="<?php echo base_url(); ?>assets/js/dashboard/dashboard-2.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/dashboard/dashboard-1.js"></script> -->


    <!-- momment js is must -->
    <script src="<?php echo base_url(); ?>assets/vendor/moment/moment.min.js"></script>
    
    <!-- Material color picker -->
    <script src="<?php echo base_url(); ?>assets/vendor/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
    <!-- Material color picker init -->
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/material-date-picker-init.js"></script>

 <!-- Datatable -->
    <script src="<?php echo base_url(); ?>assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/datatables.init.js"></script>



<!-- <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>-->
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
        
<!--<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script> -->

    <!-- Summernote -->
   <!--  <script src="<?php echo base_url(); ?>assets/vendor/summernote/js/summernote.min.js"></script> -->
    <!-- Summernote init -->
    <!-- <script src="<?php echo base_url(); ?>assets/js/plugins-init/summernote-init.js"></script> -->

    <!-- JS Grid -->
    <script src="<?php echo base_url(); ?>assets/vendor/jsgrid/js/jsgrid.min.js"></script>
    <!-- JS Grid Init -->
    <script src="<?php echo base_url(); ?>assets/js/plugins-init/jsgrid-init.js"></script>

    <!-- Sweet Alert -->
    <script src="<?php echo base_url(); ?>assets/sweet-alert2/sweetalert2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/pages/sweet-alert.init.js"></script>

    </body>
        <!--Google api's -->
    	 <!-- <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=(apikey)&callback=initMap">
    </script> -->
</html>

<script>
//     var baseurl;
//          baseurl = "<?php echo base_url();?>";
// // console.log("baseurl",baseurl);
//   $(document).ready(function(){
    
//     let userid = window.localStorage.getItem("userid");      // console.log("userid",userid);

//      if(userid == "" || userid == null || userid == undefined){
//       window.location=baseurl; 
//       } 

//     var username = window.localStorage.getItem("username");

//     var roleid = window.localStorage.getItem("roleid"); 
var baseurl = "<?php echo base_url();?>";

$(document).ready(function(){
    handleLoginPage('#userSignin', 'User 1');
    handleLoginPage('#userSignin', 'User 2');
    handleLoginPage('#userSignin', 'User 3');

    function handleLoginPage(formSelector, userIdentifier) {
        $(formSelector).submit(function(e){
            e.preventDefault();
            
            // Your login logic for the form
            var username = $(formSelector + ' .username').val();
            var password = $(formSelector + ' .password').val();

            // Example: Send login request to API
            $.ajax({
                url: baseurl + '/api/userSignin', // Replace with your API endpoint
                method: 'POST',
                data: {
                    username: username,
                    password: password
                },
                success: function(response) {
                    // Assuming the API returns user information
                    var userid = response.userid;
                    var roleid = response.roleid;

                    // Store user information in localStorage
                    window.localStorage.setItem("userid", userid);
                    window.localStorage.setItem("username", username);
                    window.localStorage.setItem("roleid", roleid);

                    console.log("Logged in as " + userIdentifier);
                },
                error: function(error) {
                    console.error("Login failed for " + userIdentifier);
                }
            });
        });
    }

    let userid = window.localStorage.getItem("userid");

    if (userid == "" || userid == null || userid == undefined) {
        console.log("Redirecting to login page due to missing userid");
        window.location.href = baseurl;
    } 

    var username = window.localStorage.getItem("username");
    var roleid = window.localStorage.getItem("roleid");

    // Log localStorage values for debugging
    console.log("userid:", userid);
    console.log("username:", username);
    console.log("roleid:", roleid);


   // console.log("user",username);
//    //var profileimg = localStorage.getItem("profileimg");
//    var roleid = window.localStorage.getItem("roleid");
//      console.log(roleid);

//      if(roleid =="5" || roleid == "6" || roleid == "7"){
//         $("#menu").show();
//         $("#drivermenu").hide();
//         $("#specialmenu").hide();
//      }

//       if(roleid=="4" || roleid=="8" || roleid=="9" || roleid == "10"){
//         $("#drivermenu").show();
//         $("#menu").hide();
//         $("#specialmenu").hide();

//      }

    if(roleid=="1"){
        $("#superadminmenu").show();
        $("#menu").hide();
     }

    if(roleid=="2"){
        $("#menu").show();
        $("#superadminmenu").hide();
     }

//     // var profileimage = "";
//     // if(profileimg == "" || profileimg == "null"){
//     //     profileimage = baseurl+"assets/images/users/4.png";
//     // }else{
//     //     profileimage = profileimg;
//     // }
    $("#user").html(username);
//   //document.getElementById("defaultpreview").src = profileimage;  
// //   session_timer(baseurl);
// }
    });

    function logout() {
    // Clear sessionStorage
    window.sessionStorage.removeItem("id");
    window.sessionStorage.clear();

    // Clear localStorage
    // window.localStorage.removeItem("userid"); // Uncomment this line if you want to remove a specific item
    window.localStorage.clear();

    // Redirect after a short delay (e.g., 100 milliseconds)
    setTimeout(function() {
        window.location = baseurl;
    }, 100);
}
</script>


