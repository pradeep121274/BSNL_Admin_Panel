<?php
defined ('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->library('email');
	}
	public function index()
	{  
		$this->load->view('index');
	}

	public function signup()
	{
		$this->load->view('signup');
	}

	public function forgotpassword()
	{
		$this->load->view('forgotpassword');
	}

	public function dashboard()
	{    
		$this->template->build('dashboard');
	}

	
	public function zone()
	{
		$this->template->build('zone');
	}

	public function circle()
	{
		$this->template->build('circle');
	}
	
	public function ssa()
	{
		$this->template->build('ssa');
	}

	public function inventoryMaster()
	{
		$this->template->build('inventorymaster');
	}

	public function site_type()
	{
		$this->template->build('site_type');
	}

	public function user_plane()
	{
		$this->template->build('user_plane');
	}

	public function user_creation()
	{
		$this->template->build('user_creation');
	}

	public function central_location()
	{
		$this->template->build('central_location');
	}

	public function survey()
	{
		$this->template->build('survey');
	}
	public function priority()
	{
		$this->template->build('priority');
	}
	public function status()
	{
		$this->template->build('status');// ticket
	}
	public function department()
	{
		$this->template->build('department');
	}
	public function ticket()
	{
		$this->template->build('ticket');
	}
	public function label()
	{
		$this->template->build('label');
	}
	public function material()
	{
		$this->template->build('material');
	}

	public function inventory()
	{
		$this->template->build('inventory');
	}

	public function commissioning()
	{
		$this->template->build('commissioning');
	}

	public function acceptance()
	{
		$this->template->build('acceptance');
	}
	
	public function surveyreport()
	{
		$this->template->build('surveyreport');
	}

	public function materialreport()
	{
		$this->template->build('materialreport');
	}

	public function inventoryreport()
	{
		$this->template->build('inventoryreport');
	}

	public function commissioningreport()
	{
		$this->template->build('commissioningreport');
	}

    public function acceptancereport()
	{
		$this->template->build('acceptancereport');
	}
	
    public function undeliveredmaterialreport()
	{
		$this->template->build('undeliveredmaterialreport');
	}

	public function changePassword()
	{
		$this->template->build('changePassword');
	}

	public function allstatusreport()
	{
		$this->template->build('allstatusreport');
	}
}


