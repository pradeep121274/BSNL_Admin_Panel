(function ($) {
  "use strict";

  // MAterial Date picker
  $("#mdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
  $("#publishdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "YYYY-MM-DD",
  });
  $("#mddate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
  $("#dispatchdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
  $("#timepicker").bootstrapMaterialDatePicker({
    format: "HH:mm",
    time: true,
    date: false,
  });
  $("#date-format").bootstrapMaterialDatePicker({
    format: "dddd DD MMMM YYYY - HH:mm",
  });

  $("#min-date").bootstrapMaterialDatePicker({
    format: "DD/MM/YYYY HH:mm",
    minDate: new Date(),
  });

  $("#start_date").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
   $("#end_date").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
  $("#ddate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
   $("#rdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
  $("#vdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  }); 
  $("#vrdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
   $("#dtdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  }); 
  $("#tripsdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "YYYY-MM-DD",
  });
    $("#start_time").bootstrapMaterialDatePicker({
    format: "HH:mm",
    time: true,
    date: false,
  });
    $("#end_time").bootstrapMaterialDatePicker({
    format: "HH:mm",
    time: true,
    date: false,
  });
    $("#atdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  }); 
  $("#actdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
    $("#finalatdate").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
    $("#partial_dt").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
    $("#full_dt").bootstrapMaterialDatePicker({
    weekStart: 0,
    time: false,
    format: "DD-MM-YYYY",
  });
})(jQuery);
