(function($){
    'use strict'

    //basic jsgrid table
    let clients = [
        { "Title": "Flow rate", "Value": "5L/MIN" },
        { "Title": "Power", "Value": "390W"}
    ];
   
    $("#jsGrid-basic").jsGrid({
        width: "100%",
        height: "auto",

        inserting: true,
        editing: true,
        sorting: true,
        paging: true,

        data: clients,

        fields: [
            { name: "Title", type: "text", width: 150, validate: "required" },
            { name: "Value", type: "text", width: 200 },
            { type: "control" }
        ]
    });

})(jQuery);

